public enum TerrainType {
    RIVER(0),
    SAND(3),
    GRASS(6),
    FOREST(12),  // AESTHETIC FIX: Ensure FOREST treats its physical base as flat for collision/shadows
    ROCK(25);

    public final int zHeight;
    TerrainType(int zHeight) {
        this.zHeight = zHeight;
    }
}