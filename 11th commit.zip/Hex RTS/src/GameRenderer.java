import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class GameRenderer {

    private static final int NUM_FRAMES = 8;
    private static final int NUM_VARIATIONS = 25;
    private static final int MAX_CACHE_SIZE = 5000;

    private final Map<Long, BufferedImage> spriteCache = new LinkedHashMap<Long, BufferedImage>(MAX_CACHE_SIZE + 1, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Long, BufferedImage> eldest) {
            return size() > MAX_CACHE_SIZE;
        }
    };

    public void renderDynamicEntities(Graphics g, List<Unit> units, SelectionManager selection) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawUnits(g2d, units);
        drawSelectionBox(g2d, selection);
    }

    public void drawSingleTile(Graphics2D g2d, HexTile tile, Point p, int globalFrame) {
        int z = tile.getZ();
        int variation = Math.abs(tile.q * 31 + tile.r * 17) % NUM_VARIATIONS;

        int coordinateNoise = Math.abs((tile.q * 127 + tile.r * 313) ^ (tile.q * tile.r));
        int frameIdx = (globalFrame + (coordinateNoise % NUM_FRAMES)) % NUM_FRAMES;

        long cacheKey = ((long) tile.terrain.ordinal() << 48) |
                (((long) z & 0xFFFF) << 32) |
                (((long) variation & 0xFFFF) << 16) |
                ((long) frameIdx & 0xFFFF);

        if (tile.isSparseForest) {
            cacheKey |= (1L << 60);
        }

        BufferedImage sprite;
        synchronized (spriteCache) {
            sprite = spriteCache.get(cacheKey);
        }

        if (sprite == null) {
            sprite = buildSprite(tile.terrain, z, variation, frameIdx, tile.isSparseForest);
            synchronized (spriteCache) {
                spriteCache.put(cacheKey, sprite);
            }
        }

        int spriteCX = CoordinateConverter.HEX_SIZE + 40;
        int spriteCY = sprite.getHeight() - CoordinateConverter.HEX_SIZE - 40;
        g2d.drawImage(sprite, p.x - spriteCX, p.y - spriteCY, null);
    }

    private BufferedImage buildSprite(TerrainType terrain, int z, int variation, int frameIdx, boolean isSparseForest) {
        int hexSize = CoordinateConverter.HEX_SIZE;

        int padding = 40;
        int width = hexSize * 2 + (padding * 2);
        int height = hexSize * 2 + Math.max(0, z) + (padding * 2);

        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int cx = width / 2;
        int cy = height - hexSize - padding;

        Color topColor, sideColor;

        switch (terrain) {
            case FOREST:
                topColor = new Color(85, 125, 35); sideColor = topColor; break;
            case ROCK:
                topColor = new Color(110, 110, 110); sideColor = topColor; break;
            case RIVER:
                topColor = new Color(65, 105, 225); sideColor = topColor; break;
            case SAND:
                topColor = new Color(237, 201, 175); sideColor = topColor; break;
            case GRASS:
            default:
                topColor = new Color(107, 142, 35); sideColor = topColor; break;
        }

        int[] tx = new int[6], ty = new int[6];
        int[] bx = new int[6], by = new int[6];

        for (int i = 0; i < 6; i++) {
            double a = Math.PI / 3 * i;
            int dx = (int)(hexSize * Math.cos(a));
            int dy = (int)(hexSize * Math.sin(a));
            tx[i] = cx + dx; ty[i] = cy + dy - Math.max(0, z);
            bx[i] = cx + dx; by[i] = cy + dy;
        }

        if (z > 0) {
            g.setColor(sideColor);
            int[] sqx = { tx[0], tx[1], tx[2], tx[3], bx[3], bx[2], bx[1], bx[0] };
            int[] sqy = { ty[0], ty[1], ty[2], ty[3], by[3], by[2], by[1], by[0] };
            g.fillPolygon(sqx, sqy, 8);
        }

        g.setColor(topColor);
        g.fillPolygon(tx, ty, 6);

        java.awt.Shape oldClip = g.getClip();
        Random seedRand = new Random(variation * 1000L);

        switch (terrain) {
            case GRASS:
                int grassCount = 15 + seedRand.nextInt(8);
                int swayOffset = (frameIdx % 4 < 2) ? 1 : -1;

                for (int i = 0; i < grassCount; i++) {
                    int gR = 115 + seedRand.nextInt(20), gG = 155 + seedRand.nextInt(20), gB = 35 + seedRand.nextInt(20);
                    g.setColor(new Color(gR, gG, gB));
                    int gx = cx + seedRand.nextInt(hexSize * 2) - hexSize;
                    int gy = (cy - Math.max(0, z)) + seedRand.nextInt(hexSize * 2) - hexSize;
                    g.fillPolygon(new int[]{ gx + swayOffset, gx - 1, gx + 1 }, new int[]{ gy - 4, gy, gy }, 3);
                }
                break;
            case FOREST:
                int canopyCount = 20 + seedRand.nextInt(15);
                if (isSparseForest) {
                    canopyCount = 3 + seedRand.nextInt(5);
                }

                Color[] flatGreens = {
                        new Color(40, 70, 25), new Color(55, 90, 30), new Color(70, 114, 35), new Color(85, 138, 40)
                };

                g.setColor(topColor);
                g.fillPolygon(tx, ty, 6);

                int maxRadius = Math.max(4, (int)(hexSize * 0.45));
                double canopyShiftY = hexSize * 0.10;

                int[] treeX = new int[6];
                int[] treeY = new int[6];

                for (int i = 0; i < canopyCount; i++) {
                    double angle = seedRand.nextDouble() * Math.PI * 2;
                    double distance = Math.sqrt(seedRand.nextDouble()) * (hexSize * 0.75);

                    double baseX = cx + Math.cos(angle) * distance;
                    double baseY = (cy - Math.max(0, z)) + Math.sin(angle) * distance - canopyShiftY;

                    double offsetX = 0;
                    if (seedRand.nextDouble() < 0.15) {
                        double swayAmplitude = 0.4 + (seedRand.nextDouble() * 0.2);
                        double phase = seedRand.nextDouble() * Math.PI * 2;
                        offsetX = swayAmplitude * Math.sin((frameIdx * Math.PI / 4) + phase);
                    }

                    int radius = Math.max(3, seedRand.nextInt(maxRadius + 1));

                    for (int n = 0; n < 6; n++) {
                        double a = Math.PI / 3 * n;
                        treeX[n] = (int) (baseX + offsetX + radius * Math.cos(a));
                        treeY[n] = (int) (baseY + radius * Math.sin(a));
                    }

                    Color baseColor = flatGreens[seedRand.nextInt(flatGreens.length)];
                    int alpha = 178 + seedRand.nextInt(78);

                    g.setColor(new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), alpha));
                    g.fillPolygon(treeX, treeY, 6);

                    g.setColor(new Color(0, 0, 0, 45));
                    g.setStroke(new BasicStroke(1.0f));
                    g.drawPolygon(treeX, treeY, 6);
                }
                break;

            case ROCK:
                int[] silX, silY;
                int silCount;
                if (z > 0) {
                    silX = new int[]{ tx[4], tx[5], tx[0], tx[1], tx[2], tx[3], bx[3], bx[2], bx[1], bx[0] };
                    silY = new int[]{ ty[4], ty[5], ty[0], ty[1], ty[2], ty[3], by[3], by[2], by[1], by[0] };
                    silCount = 10;
                } else {
                    silX = tx;
                    silY = ty;
                    silCount = 6;
                }
                g.setClip(new Polygon(silX, silY, silCount));

                int stoneLines = 140 + seedRand.nextInt(50);
                for (int i = 0; i < stoneLines; i++) {
                    int gray = 100 + seedRand.nextInt(55);
                    g.setColor(new Color(gray, gray, gray, 160));

                    int rx = cx - hexSize * 2 + seedRand.nextInt(hexSize * 4);
                    int ry = cy - z - hexSize + seedRand.nextInt(z + hexSize * 2 + 20);

                    int distFromCenter = Math.abs(rx - cx);
                    int rw;
                    if (distFromCenter > hexSize * 0.5) {
                        rw = 1 + seedRand.nextInt(2);
                    } else {
                        rw = 2 + seedRand.nextInt(3);
                    }

                    int rh = 12 + seedRand.nextInt(40);
                    g.fillRect(rx, ry, rw, rh);
                }

                if (z > 0) {
                    java.awt.Composite oldComposite = g.getComposite();

                    g.setColor(Color.WHITE);
                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.05f));
                    g.fillPolygon(tx, ty, 6);

                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.08f));
                    g.fillPolygon(new int[]{ tx[2], tx[3], bx[3], bx[2] }, new int[]{ ty[2], ty[3], by[3], by[2] }, 4);

                    g.setColor(Color.BLACK);

                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.12f));
                    g.fillPolygon(new int[]{ tx[1], tx[2], bx[2], bx[1] }, new int[]{ ty[1], ty[2], by[2], by[1] }, 4);

                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.25f));
                    g.fillPolygon(new int[]{ tx[0], tx[1], bx[1], bx[0] }, new int[]{ ty[0], ty[1], by[1], by[0] }, 4);

                    g.setComposite(oldComposite);

                    g.setColor(new Color(0, 0, 0, 40));
                    g.drawLine(tx[1], ty[1], bx[1], by[1]); g.drawLine(tx[2], ty[2], bx[2], by[2]);
                    g.drawLine(tx[0], ty[0], tx[1], ty[1]); g.drawLine(tx[1], ty[1], tx[2], ty[2]); g.drawLine(tx[2], ty[2], tx[3], ty[3]);
                }
                g.setClip(oldClip);
                break;

            case RIVER:
                g.setClip(new Polygon(tx, ty, 6));
                g.setColor(new Color(110, 180, 255));
                int animOffset = (frameIdx % NUM_FRAMES) * 3;
                int particleCount = 15 + seedRand.nextInt(10);
                for (int i = 0; i < particleCount; i++) {
                    int wy = (cy - Math.max(0, z)) - hexSize + seedRand.nextInt(hexSize * 2);
                    int wx = (cx - hexSize) + ((animOffset + (i * 15)) % (hexSize * 2));
                    g.fillPolygon(new int[]{ wx, wx + 4, wx + 8, wx + 4 }, new int[]{ wy, wy - 1, wy, wy + 1 }, 4);
                }
                g.setClip(oldClip);
                break;

            case SAND:
                g.setColor(new Color(245, 222, 200));
                int sandCount = 10 + seedRand.nextInt(8);
                for (int i = 0; i < sandCount; i++) {
                    int sx = cx + seedRand.nextInt(hexSize * 2) - hexSize;
                    int sy = (cy - Math.max(0, z)) + seedRand.nextInt(hexSize * 2) - hexSize;
                    g.fillPolygon(new int[]{ sx, sx - 2, sx, sx + 2 }, new int[]{ sy - 2, sy, sy + 2, sy }, 4);
                }
                break;
        }

        g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        if (z > 0) {
            g.setColor(sideColor);
            g.drawLine(tx[1], ty[1], bx[1], by[1]);
            g.drawLine(tx[2], ty[2], bx[2], by[2]);
            g.drawLine(bx[1], by[1], bx[2], by[2]);
            g.drawLine(bx[2], by[2], bx[3], by[3]);
        }

        g.setColor(topColor);
        g.drawPolygon(tx, ty, 6);

        if (terrain != TerrainType.RIVER) {
            g.setColor(terrain == TerrainType.FOREST ? new Color(20, 50, 15, 180) : new Color(0, 0, 0, 15));
            g.setStroke(new BasicStroke(1.0f));
            g.drawPolygon(tx, ty, 6);
        }

        g.dispose();
        return img;
    }

    private void drawUnits(Graphics g, List<Unit> units) {
        for (Unit u : units) {
            int sx = (int) u.x; int sy = (int) u.y;
            Point hexP = CoordinateConverter.pixelToHex(sx, sy);
            HexTile tile = GridManager.hexes.get(HexMath.key(hexP.x, hexP.y));
            int terrainZ = (tile != null) ? tile.getZ() : 0;

            if (u.isLeaping && u.leapZ > 0) {
                g.setColor(new Color(0, 0, 0, 80));
                int r = (int)(20 - (u.leapZ * 0.2));
                int shadowX = sx - (r / 2) + (int)(u.leapZ * 0.35);
                int shadowY = sy - terrainZ - (r / 2) + (int)(u.leapZ * 0.45);
                g.fillOval(shadowX, shadowY, r, r);
            }
            int renderY = sy - terrainZ - (int)u.leapZ;
            g.setColor(u.selected ? Color.YELLOW : (u.isHoldingPosition ? new Color(255, 140, 0) : Color.CYAN));
            g.fillOval(sx - 10, renderY - 10, 20, 20);
            g.setColor(Color.WHITE);
            g.drawString(u.type.name(), sx - 15, renderY - 10);
        }
    }

    private void drawSelectionBox(Graphics g, SelectionManager selection) {
        if (!selection.dragging) return;
        int x = Math.min(selection.dragStartX, selection.dragEndX);
        int y = Math.min(selection.dragStartY, selection.dragEndY);
        g.setColor(new Color(0, 255, 0, 80));
        g.fillRect(x, y, Math.abs(selection.dragStartX - selection.dragEndX), Math.abs(selection.dragStartY - selection.dragEndY));
    }
}