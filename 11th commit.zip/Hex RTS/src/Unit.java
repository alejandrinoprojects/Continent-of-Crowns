import java.awt.Point;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Set;
import java.util.concurrent.CompletableFuture; // NEW IMPORT

public class Unit {

    public int q, r;
    public double x, y;
    double segmentStartX, segmentStartY;
    public boolean selected = false;
    public UnitType type;

    public Order currentOrder = null;
    public boolean isHoldingPosition = false;
    public boolean atBestReachable = false;

    // NEW: Async Path Tracking fields
    public boolean isWaitingForAsyncPath = false;
    private CompletableFuture<Deque<Point>> pendingPathFuture = null;

    public Integer formationTargetQ = null;
    public Integer formationTargetR = null;

    public boolean useCurrentPosAsSegmentStart = false;
    Deque<Point> path = new ArrayDeque<>();
    int toQ, toR;
    public boolean movingSegment = false;
    double blockedTime = 0.0;

    public boolean isLeaping = false;
    public double leapProgress = 0.0;
    public double leapZ = 0.0;
    public double leapCooldown = 0.0;

    public Unit(int q, int r, UnitType type) {
        this.type = type;
        setHex(q, r);
    }

    public void prepareForQueuedOrder(Order order) {
        cancelPendingPath();
        this.currentOrder = order;
        this.isHoldingPosition = false;
        this.atBestReachable = false;

        path.clear();
        blockedTime = 0.0;
        if (!movingSegment) stopSegment();
    }

    // Safely discard obsolete background jobs
    private void cancelPendingPath() {
        if (pendingPathFuture != null) {
            pendingPathFuture.cancel(true);
            pendingPathFuture = null;
        }
        isWaitingForAsyncPath = false;
    }

    public void applyNewOrder(Order order) {
        cancelPendingPath();
        this.currentOrder = order;
        this.isHoldingPosition = false;
        this.atBestReachable = false;

        if (order.commandType == CommandType.HOLD_POSITION) {
            applyHoldPosition();
            return;
        }

        int targetQ = (formationTargetQ != null) ? formationTargetQ : order.targetQ;
        int targetR = (formationTargetR != null) ? formationTargetR : order.targetR;

        Unit blocker = GridManager.getUnitAt(targetQ, targetR);
        if (blocker != null && blocker != this && blocker.currentOrder == null) {
            Point free = PathFinder.findNearestFreeHex(targetQ, targetR, this);
            if (free != null) {
                targetQ = free.x;
                targetR = free.y;
                if (formationTargetQ != null) {
                    formationTargetQ = free.x;
                    formationTargetR = free.y;
                }
            }
        }

        path.clear();
        blockedTime = 0.0;

        int startQ = this.q;
        int startR = this.r;

        if (movingSegment) {
            startQ = toQ;
            startR = toR;
        } else {
            Point nearest = CoordinateConverter.pixelToHex((int) Math.round(x), (int) Math.round(y));
            startQ = nearest.x;
            startR = nearest.y;
            stopSegment();
            useCurrentPosAsSegmentStart = true;
        }

        // NEW: Submit task to ThreadPool instead of blocking the frame
        isWaitingForAsyncPath = true;
        pendingPathFuture = PathFinder.requestAsyncPath(startQ, startR, targetQ, targetR, this, null);
    }

    public void applyHoldPosition() {
        cancelPendingPath();
        this.currentOrder = null;
        this.isHoldingPosition = true;
        this.atBestReachable = false;
        this.formationTargetQ = null;
        this.formationTargetR = null;

        path.clear();
        stopSegment();
        blockedTime = 0.0;
        snapToCenter();
    }

    void setHex(int q, int r) {
        this.q = q;
        this.r = r;
        Point p = CoordinateConverter.hexToPixel(q, r);
        this.x = p.x;
        this.y = p.y;
        GridManager.markHex(q, r, this);
    }

    void snapToCenter() {
        Point p = CoordinateConverter.hexToPixel(q, r);
        this.x = p.x;
        this.y = p.y;
        this.leapZ = 0.0;
    }

    void stopSegment() {
        movingSegment = false;
        isLeaping = false;
        leapProgress = 0.0;
        leapZ = 0.0;
    }

    void startSegment(int nextQ, int nextR, boolean leaping) {
        toQ = nextQ;
        toR = nextR;
        movingSegment = true;
        isLeaping = leaping;
        leapProgress = 0.0;
        leapZ = 0.0;

        if (useCurrentPosAsSegmentStart) {
            segmentStartX = x;
            segmentStartY = y;
            useCurrentPosAsSegmentStart = false;
        } else {
            Point fc = CoordinateConverter.hexToPixel(q, r);
            segmentStartX = fc.x;
            segmentStartY = fc.y;
            x = fc.x;
            y = fc.y;
        }
    }

    public void updateMovement(double dt, Set<String> frameReserved) {
        if (leapCooldown > 0) leapCooldown -= dt;

        // NEW: Check if our background path thread finished computing
        if (isWaitingForAsyncPath && pendingPathFuture != null) {
            if (pendingPathFuture.isDone()) {
                try {
                    Deque<Point> newPath = pendingPathFuture.get();
                    if (newPath != null && !newPath.isEmpty()) {
                        path.clear();
                        for (Point p : newPath) {
                            if (!(p.x == this.q && p.y == this.r)) path.addLast(p);
                        }
                    } else {
                        atBestReachable = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                pendingPathFuture = null;
                isWaitingForAsyncPath = false;
            } else {
                // Not done yet. If we are currently sliding into a tile, finish sliding.
                // Otherwise, safely idle without locking the game.
                if (movingSegment) {
                    processPixelInterpolation(dt);
                    String destKey = HexMath.key(toQ, toR);
                    frameReserved.add(destKey);
                    GridManager.transitOccupied.add(destKey);
                }
                return;
            }
        }

        if (isHoldingPosition) {
            path.clear();
            currentOrder = null;
            atBestReachable = false;
            stopSegment();
            blockedTime = 0.0;
            return;
        }

        if (atBestReachable) {
            if (currentOrder == null) {
                stopSegment();
                snapToCenter();
                return;
            }
            recomputePath(null);
            if (path.isEmpty()) {
                stopSegment();
                snapToCenter();
                return;
            }
            atBestReachable = false;
        }

        if (currentOrder == null && path.isEmpty()) {
            stopSegment();
            snapToCenter();
            blockedTime = 0.0;
            return;
        }

        if (currentOrder != null && path.isEmpty()) {
            recomputePath(null);
            blockedTime = 0.0;
            if (atBestReachable && path.isEmpty()) {
                stopSegment();
                snapToCenter();
                return;
            }
        }

        if (path.isEmpty()) {
            stopSegment();
            snapToCenter();
            blockedTime = 0.0;
            return;
        }

        if (!movingSegment) {
            Point next = path.peekFirst();
            int nextQ = next.x;
            int nextR = next.y;
            String destKey = HexMath.key(nextQ, nextR);

            boolean isPlannedVault = (this.type == UnitType.CAVALRY && HexMath.hexDistance(this.q, this.r, nextQ, nextR) == 2);

            boolean occupiedByOther = GridManager.isHexOccupiedByOther(nextQ, nextR, this);
            boolean alreadyReserved = frameReserved.contains(destKey);
            boolean transitConflict = GridManager.transitOccupied.contains(destKey);

            if (isPlannedVault) {
                if (occupiedByOther || alreadyReserved || transitConflict || leapCooldown > 0) {
                    blockedTime += dt;
                    Unit blocker = GridManager.getUnitAt(nextQ, nextR);
                    boolean blockerIsActive = alreadyReserved || transitConflict || (blocker != null && blocker.currentOrder != null);

                    if (currentOrder != null && ((!blockerIsActive && blockedTime > 0.15) || (blockedTime > 0.5))) {
                        blockedTime = 0.0;
                        recomputePath(new Point(nextQ, nextR));
                        if (atBestReachable && path.isEmpty()) {
                            stopSegment();
                            snapToCenter();
                            return;
                        }
                    }
                    return;
                }

                blockedTime = 0.0;
                frameReserved.add(destKey);
                GridManager.transitOccupied.add(destKey);

                startSegment(nextQ, nextR, true);
                leapCooldown = 10.0;
                return;
            }

            if (occupiedByOther || alreadyReserved || transitConflict) {
                if (this.type == UnitType.CAVALRY && occupiedByOther && leapCooldown <= 0) {
                    int dq = nextQ - this.q;
                    int dr = nextR - this.r;

                    int landingQ = nextQ + dq;
                    int landingR = nextR + dr;
                    String landingKey = HexMath.key(landingQ, landingR);

                    int tQ = currentOrder != null ? currentOrder.targetQ : this.q;
                    int tR = currentOrder != null ? currentOrder.targetR : this.r;

                    if (!GridManager.isBlockedForPath(landingQ, landingR, this.q, this.r, tQ, tR)) {
                        boolean landingReserved = frameReserved.contains(landingKey) || GridManager.transitOccupied.contains(landingKey);

                        if (!landingReserved) {
                            blockedTime = 0.0;
                            frameReserved.add(landingKey);
                            GridManager.transitOccupied.add(landingKey);

                            path.pollFirst();
                            if (!path.isEmpty() && path.peekFirst().x == landingQ && path.peekFirst().y == landingR) {
                                path.pollFirst();
                            }

                            startSegment(landingQ, landingR, true);
                            leapCooldown = 10.0;
                            return;
                        }
                    }
                }

                blockedTime += dt;
                Unit blocker = GridManager.getUnitAt(nextQ, nextR);
                boolean blockerIsActive = alreadyReserved || transitConflict || (blocker != null && blocker.currentOrder != null);

                if (currentOrder != null && ((!blockerIsActive && blockedTime > 0.15) || (blockedTime > 0.5))) {
                    blockedTime = 0.0;
                    recomputePath(new Point(nextQ, nextR));
                    if (atBestReachable && path.isEmpty()) {
                        stopSegment();
                        snapToCenter();
                        return;
                    }
                }
                return;
            }

            blockedTime = 0.0;
            frameReserved.add(destKey);
            GridManager.transitOccupied.add(destKey);

            startSegment(nextQ, nextR, false);
        }

        if (movingSegment) {
            processPixelInterpolation(dt);
        }
    }

    private void processPixelInterpolation(double dt) {
        Point toC = CoordinateConverter.hexToPixel(toQ, toR);
        double targetX = toC.x;
        double targetY = toC.y;

        double dx = targetX - x;
        double dy = targetY - y;
        double dist = Math.sqrt(dx * dx + dy * dy);

        double speed = type.speed;

        if (formationTargetQ != null && path.size() > 1) {
            int geometricDistToGoal = HexMath.hexDistance(q, r, formationTargetQ, formationTargetR);
            if (path.size() > geometricDistToGoal + 1) {
                speed *= 1.20;
            }
        }

        if (isLeaping) {
            speed *= 1.35;
            double fullDist = Math.sqrt(Math.pow(toC.x - segmentStartX, 2) + Math.pow(toC.y - segmentStartY, 2));
            if (fullDist > 0.001) {
                leapProgress = 1.0 - (dist / fullDist);
                leapZ = Math.sin(leapProgress * Math.PI) * (CoordinateConverter.HEX_SIZE * 1.5);
            }
        }

        double pixelsPerSec = speed * (CoordinateConverter.HEX_SIZE * Math.sqrt(3));
        double step = pixelsPerSec * dt;

        if (dist <= step || dist < 1.0) {
            x = targetX;
            y = targetY;

            GridManager.transitOccupied.remove(HexMath.key(toQ, toR));

            if (GridManager.getUnitAt(q, r) == this) {
                GridManager.markHex(q, r, null);
            }
            GridManager.markHex(toQ, toR, this);

            q = toQ;
            r = toR;

            if (!path.isEmpty() && path.peekFirst().x == toQ && path.peekFirst().y == toR) {
                path.pollFirst();
            }

            stopSegment();

            int finalTargetQ = (formationTargetQ != null) ? formationTargetQ : (currentOrder != null ? currentOrder.targetQ : q);
            int finalTargetR = (formationTargetR != null) ? formationTargetR : (currentOrder != null ? currentOrder.targetR : r);

            if (q == finalTargetQ && r == finalTargetR) {
                currentOrder = null;
                formationTargetQ = null;
                formationTargetR = null;
                path.clear();
                snapToCenter();
                return;
            }

            if (currentOrder != null && path.isEmpty()) {
                recomputePath(null);
                if (path.isEmpty()) snapToCenter();
            } else if (currentOrder == null && path.isEmpty()) {
                snapToCenter();
            }
        } else {
            x += (dx / dist) * step;
            y += (dy / dist) * step;
        }
    }

    private void recomputePath(Point avoidedHex) {
        if (currentOrder == null) {
            atBestReachable = true;
            return;
        }

        int targetQ = (formationTargetQ != null) ? formationTargetQ : currentOrder.targetQ;
        int targetR = (formationTargetR != null) ? formationTargetR : currentOrder.targetR;

        Unit blocker = GridManager.getUnitAt(targetQ, targetR);
        if (blocker != null && blocker != this && blocker.currentOrder == null) {
            Point free = PathFinder.findNearestFreeHex(targetQ, targetR, this);
            if (free != null) {
                targetQ = free.x;
                targetR = free.y;
                if (formationTargetQ != null) {
                    formationTargetQ = free.x;
                    formationTargetR = free.y;
                }
            }
        }

        // NEW: Do not freeze the thread on recompute. Hand to the Executor pool!
        isWaitingForAsyncPath = true;
        pendingPathFuture = PathFinder.requestAsyncPath(this.q, this.r, targetQ, targetR, this, avoidedHex);
    }
}