import javax.swing.Timer;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
import java.util.HashMap;
import java.util.Map;
import java.awt.RenderingHints;

public class GamePanel extends JPanel {

    GameState currentState = GameState.MENU;
    CommandMode activeCommandMode = CommandMode.MOVE;

    int worldSizePercentage = 100;
    String seedInputString = "";

    int loadingProgress = 0;
    String loadingStatus = "Initializing...";

    final Rectangle playWorldBtn = new Rectangle(860, 420, 200, 50);
    final Rectangle playTesterBtn = new Rectangle(860, 500, 200, 50);
    final Rectangle quitBtn = new Rectangle(860, 580, 200, 50);

    final Rectangle sizeMinusBtn = new Rectangle(820, 360, 50, 40);
    final Rectangle sizePlusBtn = new Rectangle(1050, 360, 50, 40);

    final Rectangle startWorldBtn = new Rectangle(810, 600, 300, 45);
    final Rectangle settingsBackBtn = new Rectangle(810, 665, 300, 45);

    public final List<Unit> units = new ArrayList<>();
    public final Queue<Command> commandQueue = new LinkedList<>();

    // Permanent tracker to lock team assignments on spawn (true = Player, false = Enemy)
    public final Map<Unit, Boolean> unitTeams = new HashMap<>();

    final SelectionManager selectionManager = new SelectionManager();
    final MovementController movementController = new MovementController();
    final CameraManager cameraManager = new CameraManager();

    private final PauseManager pauseManager = new PauseManager();
    private final StatsManager playerStats = new StatsManager();
    private final CombatManager combatManager = new CombatManager();
    private TownHall playerTownHall;
    private TownHall enemyTownHall;
    private boolean gameOver = false;
    private boolean postGameFreePlay = false;

    public TownHall getPlayerTownHall() { return this.playerTownHall; }
    public TownHall getEnemyTownHall() { return this.enemyTownHall; }
    public PauseManager getPauseManager() { return this.pauseManager; }
    public StatsManager getPlayerStats() { return this.playerStats; }
    public boolean isGameOver() { return this.gameOver; }

    final RTSHUD hudManager;
    private final GameRenderer renderer = new GameRenderer();
    private final ChunkManager chunkManager = new ChunkManager();
    private final MenuRenderer menuRenderer;

    public static final int hexSize = CoordinateConverter.HEX_SIZE;
    public Stack<List<Unit>> selectionHistory = selectionManager.selectionHistory;
    List<Unit> selectedUnits = selectionManager.selectedUnits;

    int dragStartX, dragStartY, dragEndX, dragEndY;
    boolean dragging = false;
    boolean isMiddleDragging = false;

    private long lastTime = System.nanoTime();
    private static final double TARGET_FPS = 60.0;

    public GamePanel() {
        setBackground(Color.DARK_GRAY);
        setPreferredSize(new Dimension(1920, 1080));
        setFocusable(true);

        this.menuRenderer = new MenuRenderer(playWorldBtn, playTesterBtn, quitBtn);
        this.hudManager = new RTSHUD(this);

        GameInputHandler inputHandler = new GameInputHandler(this);

        addMouseListener(inputHandler);
        addMouseMotionListener(inputHandler);
        addMouseWheelListener(inputHandler);
        addKeyListener(inputHandler);

        CoordinateConverter.computeOrigin(1920, 1080);

        int timerMs = (int)(1000.0 / TARGET_FPS);
        new Timer(timerMs, e -> updateGame()).start();
    }

    private void updateLoading(int progress, String status) {
        SwingUtilities.invokeLater(() -> {
            this.loadingProgress = progress;
            this.loadingStatus = status;
            repaint();
        });
    }

    void enterWorldMode() {
        currentState = GameState.LOADING;
        activeCommandMode = CommandMode.MOVE;
        gameOver = false;
        postGameFreePlay = false;
        playerStats.reset();

        units.clear();
        unitTeams.clear();
        commandQueue.clear();
        selectionManager.selectedUnits.clear();
        selectionManager.selectionHistory.clear();

        int sizeVal = (int) (450 * (worldSizePercentage / 100.0));
        CoordinateConverter.MAP_COLS = sizeVal;
        CoordinateConverter.MAP_ROWS = sizeVal;
        CoordinateConverter.computeOrigin(getWidth(), getHeight());

        long finalSeed = seedInputString.isEmpty() ? new java.util.Random().nextLong() : Long.parseLong(seedInputString);

        updateLoading(5, "Clearing active simulation memory grids...");

        new Thread(() -> {
            try {
                Thread.sleep(50);
                updateLoading(15, "Generating procedural landmass from seed: " + finalSeed + "...");
                GridManager.generateMap(finalSeed);

                updateLoading(50, "Recalculating multi-threaded elevation shadow arrays...");
                GridManager.rebuildShadows();

                updateLoading(75, "Initializing dynamic chunk indexing structures...");
                chunkManager.buildChunks(renderer);

                updateLoading(90, "Baking high-performance static minimap overlay textures...");
                hudManager.bakeMinimap();

                updateLoading(98, "Assembling starting faction armies...");

                SwingUtilities.invokeLater(() -> {
                    List<HexTile> habitableGround = new ArrayList<>();
                    for (HexTile tile : GridManager.hexes.values()) {
                        boolean footprintIsClear = true;

                        for (int dq = -3; dq <= 3; dq++) {
                            for (int dr = Math.max(-3, -dq - 3); dr <= Math.min(3, -dq + 3); dr++) {
                                HexTile neighbor = GridManager.hexes.get(HexMath.key(tile.q + dq, tile.r + dr));
                                if (neighbor == null || (neighbor.terrain != TerrainType.GRASS && neighbor.terrain != TerrainType.SAND)) {
                                    footprintIsClear = false;
                                    break;
                                }
                            }
                            if (!footprintIsClear) break;
                        }

                        if (footprintIsClear) {
                            habitableGround.add(tile);
                        }
                    }

                    if (habitableGround.isEmpty()) {
                        for (HexTile tile : GridManager.hexes.values()) {
                            if (tile.terrain == TerrainType.GRASS || tile.terrain == TerrainType.SAND) {
                                habitableGround.add(tile);
                            }
                        }
                    }

                    java.util.Random rand = new java.util.Random();
                    int fallbackCenterQ = CoordinateConverter.MAP_COLS / 2;
                    int fallbackCenterR = (CoordinateConverter.MAP_ROWS / 2) - (fallbackCenterQ / 2);

                    HexTile playerSpawn = habitableGround.isEmpty() ?
                            new HexTile(fallbackCenterQ - 12, fallbackCenterR) :
                            habitableGround.get(rand.nextInt(habitableGround.size()));

                    HexTile enemySpawn = null;
                    int minDistanceThreshold = 45;

                    for (int attempt = 0; attempt < 500; attempt++) {
                        HexTile potential = habitableGround.get(rand.nextInt(habitableGround.size()));
                        if (HexMath.hexDistance(playerSpawn.q, playerSpawn.r, potential.q, potential.r) >= minDistanceThreshold) {
                            enemySpawn = potential;
                            break;
                        }
                    }

                    if (enemySpawn == null) {
                        enemySpawn = habitableGround.isEmpty() ?
                                new HexTile(fallbackCenterQ + 12, fallbackCenterR) :
                                habitableGround.get(rand.nextInt(habitableGround.size()));
                    }

                    playerTownHall = new TownHall(playerSpawn.q, playerSpawn.r, true);
                    enemyTownHall = new TownHall(enemySpawn.q, enemySpawn.r, false);

                    spawnInitialUnitsAround(playerTownHall.q, playerTownHall.r, true);
                    spawnInitialUnitsAround(enemyTownHall.q, enemyTownHall.r, false);

                    int screenCX = getWidth() / 2;
                    int screenCY = (getHeight() - RTSHUD.HUD_HEIGHT) / 2;
                    Point basePosPx = CoordinateConverter.hexToPixel(playerTownHall.q, playerTownHall.r);
                    cameraManager.offsetX = (int) (screenCX - (basePosPx.x * cameraManager.zoom));
                    cameraManager.offsetY = (int) (screenCY - (basePosPx.y * cameraManager.zoom));

                    currentState = GameState.PLAY_WORLD;
                    repaint();
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }).start();
    }

    void enterTesterMode() {
        currentState = GameState.LOADING;
        activeCommandMode = CommandMode.MOVE;
        gameOver = false;
        postGameFreePlay = false;
        playerStats.reset();

        units.clear();
        unitTeams.clear();
        commandQueue.clear();
        selectionManager.selectedUnits.clear();
        selectionHistory.clear();

        CoordinateConverter.MAP_COLS = 600;
        CoordinateConverter.MAP_ROWS = 600;
        CoordinateConverter.computeOrigin(getWidth(), getHeight());

        updateLoading(10, "Prepping building test sandbox...");

        new Thread(() -> {
            try {
                Thread.sleep(50);
                updateLoading(30, "Flattening full-scale uniform terrain matrix...");
                BuildTesterWorld.setup(units);

                updateLoading(60, "Initializing sandbox chunk frameworks...");
                chunkManager.buildChunks(renderer);

                updateLoading(85, "Baking sandbox minimap vectors...");
                hudManager.bakeMinimap();

                updateLoading(95, "Spawning builder squad...");

                SwingUtilities.invokeLater(() -> {
                    java.util.Random rand = new java.util.Random();
                    int maxCols = CoordinateConverter.MAP_COLS;
                    int maxRows = CoordinateConverter.MAP_ROWS;

                    int pQ = rand.nextInt(maxCols - 100) + 50;
                    int pR = rand.nextInt(maxRows - 100) + 50 - (pQ / 2);

                    int eQ = pQ, eR = pR;
                    while (HexMath.hexDistance(pQ, pR, eQ, eR) < 40) {
                        eQ = rand.nextInt(maxCols - 100) + 50;
                        eR = rand.nextInt(maxRows - 100) + 50 - (eQ / 2);
                    }

                    playerTownHall = new TownHall(pQ, pR, true);
                    enemyTownHall = new TownHall(eQ, eR, false);

                    spawnInitialUnitsAround(playerTownHall.q, playerTownHall.r, true);
                    spawnInitialUnitsAround(enemyTownHall.q, enemyTownHall.r, false);

                    int screenCX = getWidth() / 2;
                    int screenCY = (getHeight() - RTSHUD.HUD_HEIGHT) / 2;
                    Point basePosPx = CoordinateConverter.hexToPixel(playerTownHall.q, playerTownHall.r);
                    cameraManager.offsetX = (int) (screenCX - (basePosPx.x * cameraManager.zoom));
                    cameraManager.offsetY = (int) (screenCY - (basePosPx.y * cameraManager.zoom));

                    currentState = GameState.PLAY_TESTER;
                    repaint();
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }).start();
    }

    private void spawnInitialUnitsAround(int baseQ, int baseR, boolean isPlayerOwned) {
        UnitType[] types = UnitType.values();
        int idx = 0;

        for (HexTile tile : GridManager.hexes.values()) {
            if (tile.terrain == TerrainType.GRASS || tile.terrain == TerrainType.SAND) {
                if (HexMath.hexDistance(baseQ, baseR, tile.q, tile.r) <= 6 && HexMath.hexDistance(baseQ, baseR, tile.q, tile.r) > 1) {
                    UnitType t = types[idx % types.length];
                    Unit u = new Unit(tile.q, tile.r, t);
                    units.add(u);
                    unitTeams.put(u, isPlayerOwned);

                    idx++;
                    if (idx >= 20) break;
                }
            }
        }
    }

    void updateGame() {
        if (currentState == GameState.MENU || currentState == GameState.WORLD_SETTINGS || currentState == GameState.LOADING) return;
        if (pauseManager.isPaused() || gameOver) return;

        long now = System.nanoTime();
        double dt = Math.min((now - lastTime) / 1_000_000_000.0, 0.1);
        lastTime = now;

        movementController.updateSimulation(dt, units, commandQueue);
        combatManager.updateCombat(dt, units, playerTownHall, enemyTownHall, playerStats, unitTeams);

        if (!postGameFreePlay) {
            if (enemyTownHall != null && enemyTownHall.isDestroyed()) {
                gameOver = true;
                SwingUtilities.invokeLater(() -> triggerPostGameSelectionPopup("VICTORY! The enemy TownHall has fallen!"));
            } else if (playerTownHall != null && playerTownHall.isDestroyed()) {
                gameOver = true;
                SwingUtilities.invokeLater(() -> triggerPostGameSelectionPopup("DEFEAT! Your TownHall was destroyed!"));
            }
        }

        repaint();
    }

    private void triggerPostGameSelectionPopup(String outcomeMessage) {
        Object[] buttonChoices = {"Continue Playing", "Main Menu", "Quit Game"};

        int selectionResult = JOptionPane.showOptionDialog(
                this,
                outcomeMessage + "\nWhat would you like to do next?",
                "Match Concluded",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                buttonChoices,
                buttonChoices[0]
        );

        if (selectionResult == 0) {
            this.gameOver = false;
            this.postGameFreePlay = true;
        } else if (selectionResult == 1) {
            this.currentState = GameState.MENU;
            if (pauseManager.isPaused()) {
                pauseManager.togglePause();
            }
            repaint();
        } else if (selectionResult == 2 || selectionResult == JOptionPane.CLOSED_OPTION) {
            System.exit(0);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (currentState == GameState.MENU) {
            menuRenderer.drawMainMenu(g2d, getWidth(), getHeight());
            return;
        }

        if (currentState == GameState.WORLD_SETTINGS) {
            menuRenderer.drawWorldSettingsMenu(g2d, getWidth(), getHeight(), worldSizePercentage, seedInputString,
                    sizeMinusBtn, sizePlusBtn, startWorldBtn, settingsBackBtn);
            return;
        }

        if (currentState == GameState.LOADING) {
            menuRenderer.drawLoadingScreen(g2d, getWidth(), getHeight(), loadingProgress, loadingStatus);
            return;
        }

        // Keep SelectionManager fed with active coordinate data
        selectionManager.dragStartX = this.dragStartX;
        selectionManager.dragStartY = this.dragStartY;
        selectionManager.dragEndX = this.dragEndX;
        selectionManager.dragEndY = this.dragEndY;
        selectionManager.dragging = this.dragging;

        java.awt.geom.AffineTransform oldTransform = g2d.getTransform();

        g2d.scale(cameraManager.zoom, cameraManager.zoom);
        g2d.translate(cameraManager.offsetX, cameraManager.offsetY);

        chunkManager.renderChunks(g2d, cameraManager.offsetX, cameraManager.offsetY, getWidth(), getHeight(), cameraManager.zoom);

        synchronized (units) {
            for (Unit u : units) {
                boolean isPlayerUnit = unitTeams.getOrDefault(u, true);

                // 1. Colored Unit Token Rings
                g2d.setColor(isPlayerUnit ? new Color(0, 130, 255) : new Color(255, 45, 45));
                int tokenRadius = 15;
                g2d.fillOval((int) u.x - tokenRadius, (int) u.y - tokenRadius, tokenRadius * 2, tokenRadius * 2);

                g2d.setColor(u.selected ? Color.YELLOW : Color.BLACK);
                g2d.setStroke(new java.awt.BasicStroke(u.selected ? 3.0f : 1.5f));
                g2d.drawOval((int) u.x - tokenRadius, (int) u.y - tokenRadius, tokenRadius * 2, tokenRadius * 2);

                // 2. Health Bar (Drawn ABOVE the Unit Token)
                int currentHp = combatManager.getUnitHp(u);
                double hpPct = currentHp / 100.0;

                int barW = 30;
                int barH = 4;
                int barX = (int) u.x - (barW / 2);
                int barY = (int) u.y - 23;

                g2d.setColor(new Color(110, 25, 25));
                g2d.fillRect(barX, barY, barW, barH);

                g2d.setColor(new Color(40, 225, 75));
                g2d.fillRect(barX, barY, (int) (barW * hpPct), barH);

                g2d.setColor(Color.BLACK);
                g2d.setStroke(new java.awt.BasicStroke(1.0f));
                g2d.drawRect(barX, barY, barW, barH);

                // 3. Archetype Label (Drawn BELOW the Unit Token)
                g2d.setFont(new Font("SansSerif", Font.BOLD, 11));
                String labelText = u.type.name();
                FontMetrics fm = g2d.getFontMetrics();
                int labelX = (int) u.x - (fm.stringWidth(labelText) / 2);
                int labelY = (int) u.y + 27;

                g2d.setColor(new Color(0, 0, 0, 180));
                g2d.drawString(labelText, labelX + 1, labelY + 1);

                g2d.setColor(Color.WHITE);
                g2d.drawString(labelText, labelX, labelY);
            }
        }
        g2d.setStroke(new java.awt.BasicStroke(1.0f));

        if (playerTownHall != null) playerTownHall.draw(g2d);
        if (enemyTownHall != null) enemyTownHall.draw(g2d);

        // --- FIXED: RENDER SELECTION MARQUEE BOX IN WORLD SPACE BEFORE CAMERA RESET ---
        if (selectionManager.dragging) {
            int boxX = Math.min(selectionManager.dragStartX, selectionManager.dragEndX);
            int boxY = Math.min(selectionManager.dragStartY, selectionManager.dragEndY);
            int boxW = Math.abs(selectionManager.dragStartX - selectionManager.dragEndX);
            int boxH = Math.abs(selectionManager.dragStartY - selectionManager.dragEndY);

            g2d.setColor(new Color(255, 255, 0, 35));
            g2d.fillRect(boxX, boxY, boxW, boxH);

            g2d.setColor(Color.YELLOW);
            g2d.setStroke(new java.awt.BasicStroke(1.5f));
            g2d.drawRect(boxX, boxY, boxW, boxH);
            g2d.setStroke(new java.awt.BasicStroke(1.0f));
        }

        // Now revert the camera transform so the HUD doesn't pan around
        g2d.setTransform(oldTransform);

        hudManager.renderHUD(g2d, getWidth(), getHeight());

        pauseManager.drawPauseOverlay(g2d, getWidth(), getHeight(), playerStats);
    }

    int currentDestBoundsWidth() { return CoordinateConverter.getMapWidth() + 10; }
    int currentDestBoundsHeight() { return CoordinateConverter.getMapHeight() + 250; }

    public static Point hexToPixel(int q, int r) { return CoordinateConverter.hexToPixel(q, r); }
    public static Point pixelToHex(int x, int y) { return CoordinateConverter.pixelToHex(x, y); }
}