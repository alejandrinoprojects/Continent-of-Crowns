import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;

public class TownHall {
    public final int q;
    public final int r;
    public final boolean isPlayer; // true = Blue (Player), false = Red (Computer/CPU)

    public int maxHp = 2000;
    public int currentHp = 2000;

    public TownHall(int q, int r, boolean isPlayer) {
        this.q = q;
        this.r = r;
        this.isPlayer = isPlayer;

        // Register solid physical collision boundaries (Radius 3 hexes, Diameter 7)
        // By removing these coordinates from the map grid, pathfinders treat the footprint as impassable
        for (int dq = -3; dq <= 3; dq++) {
            for (int dr = Math.max(-3, -dq - 3); dr <= Math.min(3, -dq + 3); dr++) {
                GridManager.hexes.remove(HexMath.key(this.q + dq, this.r + dr));
            }
        }
    }

    /**
     * Deducts health from the TownHall building structure safely.
     */
    public void takeDamage(int amount) {
        currentHp = Math.max(0, currentHp - amount);
    }

    /**
     * Verifies if this structure's health pool has reached 0.
     */
    public boolean isDestroyed() {
        return currentHp <= 0;
    }

    /**
     * Renders a 3-hex radius placeholder layer flat onto the world terrain.
     */
    public void draw(Graphics2D g2d) {
        // Translate hex parameters into world pixel coordinates
        Point pixelPos = CoordinateConverter.hexToPixel(q, r);

        // Approximate pixel radius measurements to cleanly span a 3-hex radius area visually
        int visualRadius = (int) (CoordinateConverter.HEX_SIZE * 3.5);
        int diameter = visualRadius * 2;
        int x = pixelPos.x - visualRadius;
        int y = pixelPos.y - visualRadius;

        // Color coding depending on state ownership parameters
        Color baseColor = isPlayer ? new Color(0, 102, 204, 75) : new Color(204, 0, 0, 75);
        Color borderColor = isPlayer ? Color.BLUE : Color.RED;

        // Fill circular field footprint mapping
        g2d.setColor(baseColor);
        g2d.fillOval(x, y, diameter, diameter);

        // Render solid perimeter boundaries
        g2d.setStroke(new BasicStroke(3));
        g2d.setColor(borderColor);
        g2d.drawOval(x, y, diameter, diameter);
        g2d.setStroke(new BasicStroke(1)); // Revert stroke state parameters back to normal

        // Float raw baseline text strings tracking operational health states above the center
        g2d.setFont(new Font("SansSerif", Font.BOLD, 14));
        g2d.setColor(Color.WHITE);
        String hpText = (isPlayer ? "Your TownHall: " : "Enemy TownHall: ") + currentHp + "/" + maxHp;
        FontMetrics fm = g2d.getFontMetrics();
        g2d.drawString(hpText, pixelPos.x - (fm.stringWidth(hpText) / 2), pixelPos.y);
    }
}