import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class RTSHUD {

    public static final int HUD_HEIGHT = 200;
    public static final int MINIMAP_DIM = 360;

    private static final int GOLD_THICKNESS = 6;
    private static final int TOTAL_BORDER_OFFSET = GOLD_THICKNESS;

    public final Rectangle minimapBounds = new Rectangle();
    public final Rectangle commandCardBounds = new Rectangle();

    public final Rectangle btnW = new Rectangle();
    public final Rectangle btnA = new Rectangle();
    public final Rectangle btnS = new Rectangle();
    public final Rectangle btnD = new Rectangle();

    private final GamePanel panel;
    private BufferedImage minimapCache = null;

    private int minMapX = 0;
    private int maxMapX = 1;
    private int minMapY = 0;
    private int maxMapY = 1;

    public RTSHUD(GamePanel panel) {
        this.panel = panel;
    }

    public void updateLayoutBounds(int w, int h) {
        int hudY = h - HUD_HEIGHT;

        int totalMinimapSize = MINIMAP_DIM + (TOTAL_BORDER_OFFSET * 2);
        minimapBounds.setBounds(10, h - (totalMinimapSize + 10), totalMinimapSize, totalMinimapSize);

        int cmdX = w - 240;
        commandCardBounds.setBounds(cmdX, hudY + 10, 230, 180);

        int btnW_Dim = 100;
        int btnH_Dim = 75;

        btnW.setBounds(cmdX + 10, hudY + 20, btnW_Dim, btnH_Dim);
        btnA.setBounds(cmdX + 120, hudY + 20, btnW_Dim, btnH_Dim);
        btnS.setBounds(cmdX + 10, hudY + 105, btnW_Dim, btnH_Dim);
        btnD.setBounds(cmdX + 120, hudY + 105, btnW_Dim, btnH_Dim);
    }

    public void bakeMinimap() {
        minimapCache = new BufferedImage(MINIMAP_DIM, MINIMAP_DIM, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = minimapCache.createGraphics();

        this.minMapX = 0;
        this.maxMapX = CoordinateConverter.getMapWidth();
        this.minMapY = 0;
        this.maxMapY = CoordinateConverter.getMapHeight();

        double worldW = maxMapX - minMapX;
        double worldH = maxMapY - minMapY;

        double scaleX = (double) MINIMAP_DIM / worldW;
        double scaleY = (double) MINIMAP_DIM / worldH;

        int brushW = (int) Math.ceil(2.5 * GamePanel.hexSize * scaleX);
        int brushH = (int) Math.ceil(2.5 * GamePanel.hexSize * scaleY);

        if (brushW < 3) brushW = 3;
        if (brushH < 3) brushH = 3;

        g.setColor(new Color(50, 95, 210));
        g.fillRect(0, 0, MINIMAP_DIM, MINIMAP_DIM);

        for (HexTile tile : GridManager.hexes.values()) {
            if (tile.terrain == TerrainType.RIVER) continue;

            Point p = CoordinateConverter.hexToPixel(tile.q, tile.r);
            int mx = (int) ((p.x - minMapX) * scaleX);
            int my = (int) ((p.y - minMapY) * scaleY);

            if (mx < 0 || mx >= MINIMAP_DIM || my < 0 || my >= MINIMAP_DIM) continue;

            Color c;
            switch (tile.terrain) {
                case ROCK:   c = new Color(110, 110, 110); break;
                case FOREST: c = new Color(45, 80, 30); break;
                case SAND:   c = new Color(225, 195, 140); break;
                case GRASS:
                default:     c = new Color(95, 130, 35); break;
            }
            g.setColor(c);
            g.fillRect(mx - (brushW / 2), my - (brushH / 2), brushW, brushH);
        }
        g.dispose();
    }

    public void renderHUD(Graphics2D g2d, int w, int h) {
        int hudY = h - HUD_HEIGHT;
        updateLayoutBounds(w, h);

        // 1. DRAW HUD BACKDROP PANEL
        g2d.setColor(new Color(25, 28, 36));
        g2d.fillRect(0, hudY, w, HUD_HEIGHT);
        g2d.setColor(new Color(50, 55, 70));
        g2d.setStroke(new java.awt.BasicStroke(3.0f));
        g2d.drawLine(0, hudY, w, hudY);

        // 2. GOLD BORDER FRAME
        int mxOuter = minimapBounds.x;
        int myOuter = minimapBounds.y;
        int dimOuter = minimapBounds.width;

        g2d.setColor(new Color(212, 175, 55));
        g2d.fillRect(mxOuter, myOuter, dimOuter, dimOuter);

        g2d.setColor(new Color(15, 15, 20));
        int coreX = mxOuter + TOTAL_BORDER_OFFSET;
        int coreY = myOuter + TOTAL_BORDER_OFFSET;
        g2d.fillRect(coreX, coreY, MINIMAP_DIM, MINIMAP_DIM);

        if (minimapCache != null) {
            g2d.drawImage(minimapCache, coreX, coreY, null);
        }

        // 3. DRAW DYNAMIC LIVE ELEMENTS
        double worldW = maxMapX - minMapX;
        double worldH = maxMapY - minMapY;

        if (worldW > 0 && worldH > 0) {
            double scaleX = (double) MINIMAP_DIM / worldW;
            double scaleY = (double) MINIMAP_DIM / worldH;

            // Render Town Halls on minimap
            renderTownHallOnMinimap(g2d, panel.getPlayerTownHall(), scaleX, scaleY, coreX, coreY);
            renderTownHallOnMinimap(g2d, panel.getEnemyTownHall(), scaleX, scaleY, coreX, coreY);

            // Render live unit dots with permanent team color tracking
            for (Unit u : panel.units) {
                int dotX = coreX + (int) ((u.x - minMapX) * scaleX);
                int dotY = coreY + (int) ((u.y - minMapY) * scaleY);

                if (dotX >= coreX && dotX < coreX + MINIMAP_DIM && dotY >= coreY && dotY < coreY + MINIMAP_DIM) {
                    // Check master tracking pool map for the locked team flag assignment
                    boolean isPlayerUnit = panel.unitTeams.getOrDefault(u, true);

                    // Match the exact same team strategy dot colors used on the battlefield map pass
                    g2d.setColor(isPlayerUnit ? new Color(0, 130, 255) : new Color(255, 45, 45));

                    if (u.selected) {
                        g2d.fillRect(dotX - 3, dotY - 3, 6, 6);
                        g2d.setColor(Color.YELLOW); // Wrap selection box framework
                        g2d.drawRect(dotX - 3, dotY - 3, 6, 6);
                    } else {
                        g2d.fillRect(dotX - 2, dotY - 2, 4, 4);
                    }
                }
            }

            // Calculate camera viewport wireframe
            double viewW_World = panel.getWidth() / panel.cameraManager.zoom;
            double viewH_World = panel.getHeight() / panel.cameraManager.zoom;
            double camWorldX = -panel.cameraManager.offsetX;
            double camWorldY = -panel.cameraManager.offsetY;

            int vx = coreX + (int) ((camWorldX - minMapX) * scaleX);
            int vy = coreY + (int) ((camWorldY - minMapY) * scaleY);
            int vw = (int) (viewW_World * scaleX);
            int vh = (int) (viewH_World * scaleY);

            java.awt.Shape oldClip = g2d.getClip();
            g2d.clipRect(coreX, coreY, MINIMAP_DIM, MINIMAP_DIM);

            g2d.setColor(new Color(255, 255, 255, 200));
            g2d.setStroke(new java.awt.BasicStroke(2.0f));
            g2d.drawRect(vx, vy, vw, vh);

            g2d.setClip(oldClip);
        }

        g2d.setColor(new Color(30, 30, 30));
        g2d.setStroke(new java.awt.BasicStroke(1.0f));
        g2d.drawRect(mxOuter, myOuter, dimOuter, dimOuter);

        // 4. DRAW SELECTION SHELF AND COMMAND CARDS
        int shelfX = mxOuter + dimOuter + 20;
        int shelfW = commandCardBounds.x - shelfX - 20;
        renderSelectionShelf(g2d, shelfX, hudY + 15, shelfW, HUD_HEIGHT - 30);

        g2d.setColor(new Color(35, 40, 50));
        g2d.fill(commandCardBounds);
        g2d.setColor(Color.GRAY);
        g2d.draw(commandCardBounds);

        drawCommandButton(g2d, btnW, "MOVE (W)", panel.activeCommandMode == CommandMode.MOVE);
        drawCommandButton(g2d, btnA, "ATTACK (A)", panel.activeCommandMode == CommandMode.ATTACK);
        drawCommandButton(g2d, btnS, "HOLD (S)", panel.activeCommandMode == CommandMode.HOLD_POSITION);
        drawCommandButton(g2d, btnD, "STOP (D)", false);
    }

    private void renderTownHallOnMinimap(Graphics2D g2d, TownHall townHall, double scaleX, double scaleY, int coreX, int coreY) {
        if (townHall == null) return;

        Point worldPos = CoordinateConverter.hexToPixel(townHall.q, townHall.r);
        int thMx = coreX + (int) ((worldPos.x - minMapX) * scaleX);
        int thMy = coreY + (int) ((worldPos.y - minMapY) * scaleY);

        if (thMx >= coreX && thMx < coreX + MINIMAP_DIM && thMy >= coreY && thMy < coreY + MINIMAP_DIM) {
            g2d.setColor(townHall.isPlayer ? Color.BLUE : Color.RED);
            g2d.fillRect(thMx - 3, thMy - 3, 7, 7);
            g2d.setColor(Color.WHITE);
            g2d.drawRect(thMx - 3, thMy - 3, 7, 7);
        }
    }

    private void renderSelectionShelf(Graphics2D g2d, int startX, int startY, int maxW, int maxH) {
        if (panel.selectedUnits.isEmpty()) {
            g2d.setColor(Color.DARK_GRAY);
            g2d.setFont(new Font("SansSerif", Font.ITALIC, 16));
            g2d.drawString("No units currently selected.", startX + 20, startY + 80);
            return;
        }

        Map<UnitType, Integer> selectedCounts = new HashMap<>();
        for (Unit u : panel.selectedUnits) {
            selectedCounts.put(u.type, selectedCounts.getOrDefault(u.type, 0) + 1);
        }

        int cardX = startX;
        int cardWidth = 110;
        int cardHeight = 85;

        for (UnitType type : UnitType.values()) {
            boolean isPresentInSelection = selectedCounts.containsKey(type);

            if (isPresentInSelection) {
                g2d.setColor(new Color(55, 90, 45));
                g2d.fillRect(cardX, startY, cardWidth, cardHeight);
                g2d.setColor(new Color(125, 215, 95));
                g2d.drawRect(cardX, startY, cardWidth, cardHeight);
                g2d.setColor(Color.WHITE);
            } else {
                g2d.setColor(new Color(40, 45, 55));
                g2d.fillRect(cardX, startY, cardWidth, cardHeight);
                g2d.setColor(Color.DARK_GRAY);
                g2d.drawRect(cardX, startY, cardWidth, cardHeight);
                g2d.setColor(Color.GRAY);
            }

            g2d.setFont(new Font("SansSerif", Font.BOLD, 12));
            g2d.drawString(type.name(), cardX + 10, startY + 30);

            if (isPresentInSelection) {
                int count = selectedCounts.get(type);
                g2d.setFont(new Font("SansSerif", Font.BOLD, 16));
                g2d.setColor(new Color(145, 255, 115));
                g2d.drawString(String.valueOf(count), cardX + cardWidth - 25, startY + cardHeight - 12);
            }

            cardX += cardWidth + 15;
            if (cardX + cardWidth > startX + maxW) break;
        }
    }

    private void drawCommandButton(Graphics2D g2d, Rectangle r, String text, boolean isSelectedToggled) {
        if (isSelectedToggled) {
            g2d.setColor(new Color(115, 155, 65));
            g2d.fill(r);
            g2d.setColor(Color.WHITE);
        } else {
            g2d.setColor(new Color(50, 55, 65));
            g2d.fill(r);
            g2d.setColor(Color.LIGHT_GRAY);
        }
        g2d.draw(r);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 12));
        g2d.drawString(text, r.x + 15, r.y + 42);
    }

    public boolean checkHUDLeftClick(Point p) {
        if (minimapBounds.contains(p)) {
            processMinimapClick(p);
            return true;
        }

        if (btnW.contains(p)) {
            panel.activeCommandMode = CommandMode.MOVE;
            return true;
        }
        if (btnA.contains(p)) {
            panel.activeCommandMode = CommandMode.ATTACK;
            return true;
        }
        if (btnS.contains(p)) {
            panel.activeCommandMode = CommandMode.HOLD_POSITION;
            for (Unit u : panel.selectedUnits) {
                u.applyHoldPosition();
            }
            return true;
        }
        if (btnD.contains(p)) {
            for (Unit u : panel.selectedUnits) {
                u.applyHoldPosition();
            }
            return true;
        }

        return commandCardBounds.contains(p);
    }

    public void processMinimapClick(Point screenPoint) {
        int mx = screenPoint.x - (minimapBounds.x + TOTAL_BORDER_OFFSET);
        int my = screenPoint.y - (minimapBounds.y + TOTAL_BORDER_OFFSET);

        mx = Math.max(0, Math.min(mx, MINIMAP_DIM));
        my = Math.max(0, Math.min(my, MINIMAP_DIM));

        double pctX = (double) mx / MINIMAP_DIM;
        double pctY = (double) my / MINIMAP_DIM;

        double targetWorldX = minMapX + (pctX * (maxMapX - minMapX));
        double targetWorldY = minMapY + (pctY * (maxMapY - minMapY));

        panel.cameraManager.offsetX = (int) ((panel.getWidth() / (2.0 * panel.cameraManager.zoom)) - targetWorldX);
        panel.cameraManager.offsetY = (int) ((panel.getHeight() / (2.0 * panel.cameraManager.zoom)) - targetWorldY);
    }
}