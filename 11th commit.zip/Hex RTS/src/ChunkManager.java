import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChunkManager {
    public static final int CHUNK_SIZE = 1024;
    private static final int NUM_FRAMES = 8;

    private BufferedImage[][][] chunks;
    private List<HexTile>[][] chunkTileBuckets;
    private GameRenderer cachedRendererReference;
    private int cols;
    private int rows;

    private final Set<String> activeBakedChunks = ConcurrentHashMap.newKeySet();
    private final Set<String> chunksInQueue = ConcurrentHashMap.newKeySet();

    private final ExecutorService bakeExecutor = Executors.newFixedThreadPool(
            Math.max(1, Runtime.getRuntime().availableProcessors() - 1),
            runnable -> {
                Thread thread = new Thread(runnable);
                thread.setDaemon(true);
                thread.setName("ContinentalConquest-ChunkBaker");
                return thread;
            }
    );

    public void buildChunks(GameRenderer renderer) {
        this.cachedRendererReference = renderer;
        activeBakedChunks.clear();
        chunksInQueue.clear();

        int mapWidth = CoordinateConverter.getMapWidth();
        int mapHeight = CoordinateConverter.getMapHeight();

        cols = (int) Math.ceil((double) mapWidth / CHUNK_SIZE);
        rows = (int) Math.ceil((double) mapHeight / CHUNK_SIZE);

        chunks = new BufferedImage[cols][rows][NUM_FRAMES];
        chunkTileBuckets = new ArrayList[cols][rows];

        List<HexTile> allTiles = new ArrayList<>(GridManager.hexes.values());
        allTiles.sort((t1, t2) -> {
            int y1 = CoordinateConverter.getPixelY(t1.q, t1.r);
            int y2 = CoordinateConverter.getPixelY(t2.q, t2.r);
            if (y1 != y2) return Integer.compare(y1, y2);
            return Integer.compare(CoordinateConverter.getPixelX(t1.q, t1.r), CoordinateConverter.getPixelX(t2.q, t2.r));
        });

        for (HexTile tile : allTiles) {
            Point p = CoordinateConverter.hexToPixel(tile.q, tile.r);
            int maxZ = Math.max(0, tile.getZ());
            Rectangle tileBounds = new Rectangle(p.x - 120, p.y - maxZ - 120, maxZ + 240, maxZ + 240);

            int startCx = Math.max(0, tileBounds.x / CHUNK_SIZE);
            int endCx = Math.min(cols - 1, (tileBounds.x + tileBounds.width) / CHUNK_SIZE);
            int startCy = Math.max(0, tileBounds.y / CHUNK_SIZE);
            int endCy = Math.min(rows - 1, (tileBounds.y + tileBounds.height) / CHUNK_SIZE);

            for (int cx = startCx; cx <= endCx; cx++) {
                for (int cy = startCy; cy <= endCy; cy++) {
                    Rectangle chunkBounds = new Rectangle(cx * CHUNK_SIZE, cy * CHUNK_SIZE, CHUNK_SIZE, CHUNK_SIZE);

                    if (chunkBounds.intersects(tileBounds)) {
                        if (chunkTileBuckets[cx][cy] == null) {
                            chunkTileBuckets[cx][cy] = new ArrayList<>();
                        }
                        chunkTileBuckets[cx][cy].add(tile);
                    }
                }
            }
        }
    }

    private void submitBakeTaskAsync(final int cx, final int cy, final int frameIdx) {
        final String key = cx + "," + cy + "," + frameIdx;

        if (!chunksInQueue.add(key)) {
            return;
        }

        bakeExecutor.submit(() -> {
            try {
                List<HexTile> bucketTiles = chunkTileBuckets[cx][cy];
                if (bucketTiles == null || bucketTiles.isEmpty()) {
                    activeBakedChunks.add(key);
                    return;
                }

                List<HexTile> shadowCasters = new ArrayList<>(bucketTiles);
                if (cx > 0 && chunkTileBuckets[cx - 1][cy] != null) shadowCasters.addAll(chunkTileBuckets[cx - 1][cy]);
                if (cy > 0 && chunkTileBuckets[cx][cy - 1] != null) shadowCasters.addAll(chunkTileBuckets[cx][cy - 1]);
                if (cx > 0 && cy > 0 && chunkTileBuckets[cx - 1][cy - 1] != null) shadowCasters.addAll(chunkTileBuckets[cx - 1][cy - 1]);

                BufferedImage bImg = new BufferedImage(CHUNK_SIZE, CHUNK_SIZE, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = bImg.createGraphics();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int pixelOffsetX = cx * CHUNK_SIZE;
                int pixelOffsetY = cy * CHUNK_SIZE;
                g2d.translate(-pixelOffsetX, -pixelOffsetY);

                TreeSet<Integer> uniqueHeights = new TreeSet<>();
                for (HexTile tile : bucketTiles) {
                    uniqueHeights.add(tile.getZ());
                }

                int hexSize = CoordinateConverter.HEX_SIZE;

                for (int currentZ : uniqueHeights) {
                    for (HexTile tile : bucketTiles) {
                        if (tile.getZ() == currentZ) {
                            Point p = CoordinateConverter.hexToPixel(tile.q, tile.r);
                            cachedRendererReference.drawSingleTile(g2d, tile, p, frameIdx);
                        }
                    }

                    boolean hasHigherTiles = false;
                    for (HexTile t : shadowCasters) {
                        if (t.getZ() > currentZ) {
                            hasHigherTiles = true;
                            break;
                        }
                    }

                    if (hasHigherTiles) {
                        BufferedImage shadowLayer = new BufferedImage(CHUNK_SIZE, CHUNK_SIZE, BufferedImage.TYPE_INT_ARGB);
                        Graphics2D sg = shadowLayer.createGraphics();
                        sg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        sg.translate(-pixelOffsetX, -pixelOffsetY);
                        sg.setColor(new Color(0, 0, 0, 255));

                        for (HexTile higherTile : shadowCasters) {
                            if (higherTile.getZ() > currentZ) {
                                Point hp = CoordinateConverter.hexToPixel(higherTile.q, higherTile.r);
                                int dz = higherTile.getZ() - currentZ;

                                // PROPORTIONAL LENGTH: Taller mountains push the shadow tip further out
                                int offsetX = (int) (dz * 1.5);
                                int offsetY = (int) (dz * 1.0);

                                int[] bx = new int[6], by = new int[6];
                                int[] sx = new int[6], sy = new int[6];

                                for (int i = 0; i < 6; i++) {
                                    double a = Math.PI / 3 * i;
                                    // 1. Calculate the base polygon footprint (flat on the ground)
                                    bx[i] = hp.x + (int) (hexSize * Math.cos(a));
                                    by[i] = hp.y + (int) (hexSize * Math.sin(a));

                                    // 2. Shift that footprint out to find the tip of the shadow
                                    sx[i] = bx[i] + offsetX;
                                    sy[i] = by[i] + offsetY;
                                }

                                // 3. Connect the base footprint to the extended tip to create a solid 3D cast shape
                                Polygon shadowExtrusion = new Polygon();
                                shadowExtrusion.addPoint(bx[5], by[5]);
                                shadowExtrusion.addPoint(bx[4], by[4]);
                                shadowExtrusion.addPoint(bx[3], by[3]);
                                shadowExtrusion.addPoint(bx[2], by[2]);
                                shadowExtrusion.addPoint(sx[2], sy[2]);
                                shadowExtrusion.addPoint(sx[1], sy[1]);
                                shadowExtrusion.addPoint(sx[0], sy[0]);
                                shadowExtrusion.addPoint(sx[5], sy[5]);

                                sg.fillPolygon(shadowExtrusion);
                            }
                        }
                        sg.dispose();

                        for (HexTile tile : bucketTiles) {
                            if (tile.getZ() == currentZ) {
                                Point p = CoordinateConverter.hexToPixel(tile.q, tile.r);

                                int[] thx = new int[6], thy = new int[6];
                                int[] bhx = new int[6], bhy = new int[6];
                                for (int i = 0; i < 6; i++) {
                                    double a = Math.PI / 3 * i;
                                    int dx = (int)(hexSize * Math.cos(a));
                                    int dy = (int)(hexSize * Math.sin(a));
                                    thx[i] = p.x + dx; thy[i] = p.y + dy - currentZ;
                                    bhx[i] = p.x + dx; bhy[i] = p.y + dy;
                                }

                                Polygon fullTilePoly;
                                if (currentZ > 0) {
                                    int[] s3dX = new int[]{ thx[4], thx[5], thx[0], thx[1], thx[2], thx[3], bhx[3], bhx[2], bhx[1], bhx[0] };
                                    int[] s3dY = new int[]{ thy[4], thy[5], thy[0], thy[1], thy[2], thy[3], bhy[3], bhy[2], bhy[1], bhy[0] };
                                    fullTilePoly = new Polygon(s3dX, s3dY, 10);
                                } else {
                                    fullTilePoly = new Polygon(thx, thy, 6);
                                }

                                Shape oldClip = g2d.getClip();
                                g2d.clip(fullTilePoly);

                                java.awt.Composite oldComp = g2d.getComposite();
                                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.22f));

                                g2d.drawImage(shadowLayer, pixelOffsetX, pixelOffsetY, null);

                                g2d.setComposite(oldComp);
                                g2d.setClip(oldClip);
                            }
                        }
                    }
                }

                g2d.dispose();
                chunks[cx][cy][frameIdx] = bImg;
                activeBakedChunks.add(key);
            } catch (Exception ex) {
                ex.printStackTrace();
            } {
                chunksInQueue.remove(key);
            }
        });
    }

    public void renderChunks(Graphics2D g, int camX, int camY, int screenW, int screenH, double zoom) {
        int viewWorldX = -camX;
        int viewWorldY = -camY;
        int viewWorldW = (int) (screenW / zoom);
        int viewWorldH = (int) (screenH / zoom);

        int hexW = (int) (CoordinateConverter.HEX_SIZE * 1.5);
        int hexH = (int) (Math.sqrt(3) * CoordinateConverter.HEX_SIZE);

        int tolerancePaddingX = hexW * 5;
        int tolerancePaddingY = hexH * 5;

        int minVisibleX = viewWorldX - tolerancePaddingX;
        int minVisibleY = viewWorldY - tolerancePaddingY;
        int maxVisibleX = viewWorldX + viewWorldW + tolerancePaddingX;
        int maxVisibleY = viewWorldY + viewWorldH + tolerancePaddingY;

        int startCol = Math.max(0, minVisibleX / CHUNK_SIZE);
        int startRow = Math.max(0, minVisibleY / CHUNK_SIZE);
        int endCol = Math.min(cols - 1, maxVisibleX / CHUNK_SIZE);
        int endRow = Math.min(rows - 1, maxVisibleY / CHUNK_SIZE);

        int globalFrame = (int) ((System.currentTimeMillis() / 240) % NUM_FRAMES);

        for (int cx = startCol; cx <= endCol; cx++) {
            for (int cy = startRow; cy <= endRow; cy++) {
                BufferedImage toDraw = chunks[cx][cy][globalFrame];

                if (toDraw == null) {
                    submitBakeTaskAsync(cx, cy, globalFrame);

                    for (int f = 0; f < NUM_FRAMES; f++) {
                        if (chunks[cx][cy][f] != null) {
                            toDraw = chunks[cx][cy][f];
                            break;
                        }
                    }
                }

                if (toDraw != null) {
                    g.drawImage(toDraw, cx * CHUNK_SIZE, cy * CHUNK_SIZE, null);
                }
            }
        }

        int purgeStartCol = Math.max(0, startCol - 5);
        int purgeStartRow = Math.max(0, startRow - 5);
        int purgeEndCol = Math.min(cols - 1, endCol + 5);
        int purgeEndRow = Math.min(rows - 1, endRow + 5);

        activeBakedChunks.removeIf(key -> {
            String[] indices = key.split(",");
            int cx = Integer.parseInt(indices[0]);
            int cy = Integer.parseInt(indices[1]);
            int f = Integer.parseInt(indices[2]);

            if (cx < purgeStartCol || cx > purgeEndCol || cy < purgeStartRow || cy > purgeEndRow) {
                if (!chunksInQueue.contains(key)) {
                    if (chunks[cx][cy][f] != null) {
                        chunks[cx][cy][f].flush();
                        chunks[cx][cy][f] = null;
                    }
                    return true;
                }
            }
            return false;
        });
    }
}