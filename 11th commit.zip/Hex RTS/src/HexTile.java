import java.awt.geom.Area;
import java.util.ArrayList;
import java.util.List;

public class HexTile {
    public final int q, r;
    public TerrainType terrain = TerrainType.GRASS;
    public int customZ = -1;

    // NEW: Tells the renderer to draw fewer trees on this specific hex
    public boolean isSparseForest = false;

    public static class ShadowRecord {
        public final int cx, cy, z;
        public ShadowRecord(int cx, int cy, int z) {
            this.cx = cx;
            this.cy = cy;
            this.z = z;
        }
    }

    public final List<ShadowRecord> incomingShadows = new ArrayList<>();
    public Area compiledShadow = null;

    public HexTile(int q, int r) {
        this.q = q;
        this.r = r;
    }

    public int getZ() {
        return customZ >= 0 ? customZ : terrain.zHeight;
    }
}