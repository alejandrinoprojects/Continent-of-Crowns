import javax.swing.*;

public class AAGameMain {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Continent of Crowns");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new GamePanel());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}