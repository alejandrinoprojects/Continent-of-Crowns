import java.util.List;

/**
 * Utility class dedicated to constructing a clean, flat testing sandbox.
 * Updated to properly inform camera trackers about the map center.
 */
public class BuildTesterWorld {

    public static void setup(List<Unit> units) {
        GridManager.hexes.clear();
        GridManager.clearGridOccupancy();
        units.clear();

        int cols = CoordinateConverter.MAP_COLS;
        int rows = CoordinateConverter.MAP_ROWS;

        for (int q = 0; q < cols; q++) {
            int rOffset = q >> 1;
            for (int r = -rOffset; r < rows - rOffset; r++) {
                HexTile tile = new HexTile(q, r);
                tile.terrain = TerrainType.GRASS;
                tile.customZ = 0;
                GridManager.hexes.put(HexMath.key(q, r), tile);
            }
        }

        int centerQ = cols / 2;
        int centerR = (rows / 2) - (centerQ / 2);

        for (int i = 0; i < 5; i++) {
            int spawnQ = centerQ + (i - 2);
            int spawnR = centerR;

            Unit builder = new Unit(spawnQ, spawnR, UnitType.VILLAGER);
            units.add(builder);
            GridManager.markHex(spawnQ, spawnR, builder);
        }

        // NEW: Assign standard geometric middle to align camera offsets safely
        GridManager.landCenterPX = CoordinateConverter.getMapWidth() / 2;
        GridManager.landCenterPY = CoordinateConverter.getMapHeight() / 2;
    }
}