public enum CommandMode {
    MOVE,
    ATTACK,
    HOLD_POSITION
}