import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 * Handles flat-style visual rendering layout for menus and loading screens.
 */
public class MenuRenderer {

    private final Rectangle playWorldBtn;
    private final Rectangle playTesterBtn;
    private final Rectangle quitBtn;

    public MenuRenderer(Rectangle playWorldBtn, Rectangle playTesterBtn, Rectangle quitBtn) {
        this.playWorldBtn = playWorldBtn;
        this.playTesterBtn = playTesterBtn;
        this.quitBtn = quitBtn;
    }

    public void drawMainMenu(Graphics2D g2d, int width, int height) {
        g2d.setColor(new Color(30, 35, 45));
        g2d.fillRect(0, 0, width, height);

        g2d.setColor(new Color(107, 142, 35));
        g2d.setFont(new Font("SansSerif", Font.BOLD, 52));
        g2d.drawString("Continental Conquest", 660, 220);

        g2d.setFont(new Font("SansSerif", Font.PLAIN, 20));
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawString("Temporary Debug & Build Sandbox Environment Selection", 720, 270);

        drawMenuButton(g2d, playWorldBtn, "Play World", new Color(75, 110, 175));
        drawMenuButton(g2d, playTesterBtn, "Play Tester", new Color(85, 125, 35));
        drawMenuButton(g2d, quitBtn, "Quit", new Color(165, 55, 55));
    }

    /**
     * UPDATED: Renders the dynamic percentage adjustment row layout.
     */
    public void drawWorldSettingsMenu(Graphics2D g2d, int w, int h, int currentPercentage, String seedStr,
                                      Rectangle minusBtn, Rectangle plusBtn, Rectangle start, Rectangle back) {
        g2d.setColor(new Color(30, 35, 45));
        g2d.fillRect(0, 0, w, h);

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 36));
        g2d.drawString("World Generation Parameters", 710, 200);

        // --- SECTION 1: WORLD SIZE PERCENTAGE CHIPS ---
        g2d.setFont(new Font("SansSerif", Font.BOLD, 18));
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawString("ADJUST WORLD SIZE PERCENTAGE (25% - 500%):", 755, 320);

        drawMenuButton(g2d, minusBtn, "-", new Color(55, 60, 70));
        drawMenuButton(g2d, plusBtn, "+", new Color(55, 60, 70));

        // Draw the interactive percentage value string numbers centrally in the middle gap
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 26));
        String pctText = currentPercentage + "%";
        int textW = g2d.getFontMetrics().stringWidth(pctText);
        int middleX = minusBtn.x + minusBtn.width + (plusBtn.x - (minusBtn.x + minusBtn.width)) / 2;
        g2d.drawString(pctText, middleX - (textW / 2), minusBtn.y + 28);

        // Show estimated dimensions in hex tiles right underneath it
        g2d.setFont(new Font("SansSerif", Font.ITALIC, 14));
        g2d.setColor(Color.GRAY);
        int estTiles = (int) (450 * (currentPercentage / 100.0));
        g2d.drawString("Estimated Dimensions: " + estTiles + " x " + estTiles + " Tiles", 830, 425);

        // --- SECTION 2: SEED SELECTION INPUT BOX ---
        g2d.setFont(new Font("SansSerif", Font.BOLD, 18));
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawString("ENTER SEED (LEAVE BLANK FOR RANDOM):", 785, 480);

        g2d.setColor(new Color(20, 22, 28));
        g2d.fillRect(810, 510, 300, 45);
        g2d.setColor(Color.GRAY);
        g2d.drawRect(810, 510, 300, 45);

        g2d.setColor(Color.GREEN);
        g2d.setFont(new Font("Monospaced", Font.BOLD, 20));
        g2d.drawString(seedStr + (System.currentTimeMillis() % 1000 < 500 ? "_" : ""), 825, 540);

        // --- ACTION SYSTEM BUTTONS ---
        drawMenuButton(g2d, start, "GENERATE WORLD", new Color(75, 110, 175));
        drawMenuButton(g2d, back, "BACK", new Color(135, 55, 55));
    }

    public void drawLoadingScreen(Graphics2D g2d, int width, int height, int loadingProgress, String loadingStatus) {
        g2d.setColor(new Color(30, 35, 45));
        g2d.fillRect(0, 0, width, height);

        int barW = 600;
        int barH = 30;
        int barX = (width - barW) / 2;
        int barY = (height - barH) / 2;

        g2d.setColor(new Color(60, 65, 75));
        g2d.fillRect(barX, barY, barW, barH);
        g2d.setColor(Color.GRAY);
        g2d.drawRect(barX, barY, barW, barH);

        int fillWidth = (int) (barW * (loadingProgress / 100.0));
        g2d.setColor(new Color(107, 142, 35));
        g2d.fillRect(barX + 2, barY + 2, Math.max(0, fillWidth - 4), barH - 4);

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 24));
        g2d.drawString("LOADING TEST ENVIRONMENT...", barX, barY - 40);

        g2d.setFont(new Font("SansSerif", Font.PLAIN, 16));
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawString(loadingStatus + " (" + loadingProgress + "%)", barX, barY + barH + 30);
    }

    private void drawMenuButton(Graphics2D g2d, Rectangle r, String text, Color baseColor) {
        g2d.setColor(baseColor);
        g2d.fillRect(r.x, r.y, r.width, r.height);
        g2d.setColor(Color.WHITE);
        g2d.drawRect(r.x, r.y, r.width, r.height);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 14));
        int paddingX = (r.width - g2d.getFontMetrics().stringWidth(text)) / 2;
        g2d.drawString(text, r.x + paddingX, r.y + 24);
    }
}