import javax.swing.Timer;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
import java.util.concurrent.CompletableFuture;
import java.awt.RenderingHints;

public class GamePanel extends JPanel {

    GameState currentState = GameState.MENU;
    CommandMode activeCommandMode = CommandMode.MOVE;

    int worldSizePercentage = 100;
    String seedInputString = "";

    int loadingProgress = 0;
    String loadingStatus = "Initializing...";

    final Rectangle playWorldBtn    = new Rectangle(860, 420, 200, 50);
    final Rectangle playTesterBtn   = new Rectangle(860, 500, 200, 50);
    final Rectangle quitBtn         = new Rectangle(860, 580, 200, 50);

    final Rectangle sizeMinusBtn    = new Rectangle(820,  360,  50, 40);
    final Rectangle sizePlusBtn     = new Rectangle(1050, 360,  50, 40);

    final Rectangle startWorldBtn   = new Rectangle(810, 600, 300, 45);
    final Rectangle settingsBackBtn = new Rectangle(810, 665, 300, 45);

    public final List<Unit> units = new ArrayList<>();
    public final Queue<Command> commandQueue = new LinkedList<>();

    final SelectionManager   selectionManager    = new SelectionManager();
    final MovementController movementController  = new MovementController();
    final CameraManager      cameraManager       = new CameraManager();

    final RTSHUD       hudManager;
    private final GameRenderer  renderer     = new GameRenderer();
    private final ChunkManager  chunkManager = new ChunkManager();
    private final MenuRenderer  menuRenderer;

    public static final int hexSize = CoordinateConverter.HEX_SIZE;
    public Stack<List<Unit>> selectionHistory = selectionManager.selectionHistory;
    List<Unit> selectedUnits = selectionManager.selectedUnits;
    public Point townhallHex = null;
    int dragStartX, dragStartY, dragEndX, dragEndY;
    boolean dragging         = false;
    boolean isMiddleDragging = false;

    private long lastTime = System.nanoTime();
    private static final double TARGET_FPS = 60.0;

    public static final double DAY_NIGHT_CYCLE_SECONDS = 120;
    public double currentCycleTime = 0.0;
    public int    currentDay       = 1;
    public double totalSessionTime = 0.0;

    private Color activeNightOverlayColor = new Color(0, 0, 0, 0);

    private int lastWidth   = -1;
    private int lastHeight  = -1;
    private int lastTodStep = -1;

    private boolean chunkRebuildPending = false;
    private static final int TOWNHALL_PLAINS_RADIUS = 5;

    private final int[] lightHexX = new int[6];
    private final int[] lightHexY = new int[6];
    private final Color[] groundGlowColorCache = new Color[256];

    public GamePanel() {
        setBackground(Color.DARK_GRAY);
        setPreferredSize(new Dimension(1920, 1080));
        setFocusable(true);

        this.menuRenderer = new MenuRenderer(playWorldBtn, playTesterBtn, quitBtn);
        this.hudManager   = new RTSHUD(this);

        for (int i = 0; i < 256; i++) {
            groundGlowColorCache[i] = new Color(255, 230, 140, i);
        }

        GameInputHandler inputHandler = new GameInputHandler(this);
        addMouseListener(inputHandler);
        addMouseMotionListener(inputHandler);
        addMouseWheelListener(inputHandler);
        addKeyListener(inputHandler);

        CoordinateConverter.computeOrigin(1920, 1080);

        int timerMs = (int)(1000.0 / TARGET_FPS);
        new Timer(timerMs, e -> updateGame()).start();
    }

    private void updateLoading(int progress, String status) {
        SwingUtilities.invokeLater(() -> {
            this.loadingProgress = progress;
            this.loadingStatus   = status;
            repaint();
        });
    }

    private int getInitialTodStep() {
        float initialContinuousTime = 0.10f * 2.0f;
        float normalizedTime = initialContinuousTime / 2.0f;
        return Math.max(0, Math.min(ChunkManager.NUM_TOD_STEPS - 1, (int)(normalizedTime * ChunkManager.NUM_TOD_STEPS)));
    }

    private void spawnTownhall() {
        int centerQ = CoordinateConverter.MAP_COLS / 2;
        int centerR = (CoordinateConverter.MAP_ROWS / 2) - (centerQ / 2);

        List<HexTile> candidates = new ArrayList<>();
        for (HexTile t : GridManager.hexes.values()) {
            if (isFlatWalkable(t)) candidates.add(t);
        }

        candidates.sort((a, b) -> Integer.compare(
                hexDist(a.q, a.r, centerQ, centerR),
                hexDist(b.q, b.r, centerQ, centerR)));

        for (int tryRadius = TOWNHALL_PLAINS_RADIUS; tryRadius >= 2; tryRadius--) {
            for (HexTile center : candidates) {
                if (isOpenPlains(center, tryRadius)) {
                    townhallHex = new Point(center.q, center.r);
                    return;
                }
            }
        }

        if (!candidates.isEmpty()) {
            townhallHex = new Point(candidates.get(0).q, candidates.get(0).r);
        }
    }

    private boolean isOpenPlains(HexTile center, int radius) {
        int baseZ = center.getZ();
        for (int dq = -radius; dq <= radius; dq++) {
            for (int dr = -radius; dr <= radius; dr++) {
                if (hexDist(0, 0, dq, dr) > radius) continue;
                HexTile n = GridManager.hexes.get(HexMath.key(center.q + dq, center.r + dr));
                if (n == null || !isFlatWalkable(n) || n.getZ() != baseZ) return false;
            }
        }
        return true;
    }

    private boolean isFlatWalkable(HexTile t) {
        return t.terrain == TerrainType.GRASS || t.terrain == TerrainType.SAND;
    }

    private void spawnInitialUnits() {
        if (townhallHex == null) return;

        UnitType[] types = UnitType.values();
        int placed = 0;
        int targetCount = 20;

        HexTile townTile = GridManager.hexes.get(
                HexMath.key(townhallHex.x, townhallHex.y));
        int baseZ = (townTile != null) ? townTile.getZ() : 0;

        int ring = 2;
        while (placed < targetCount && ring <= 15) {
            List<Point> ringHexes = getHexRing(townhallHex.x, townhallHex.y, ring);
            for (Point hex : ringHexes) {
                if (placed >= targetCount) break;
                HexTile t = GridManager.hexes.get(HexMath.key(hex.x, hex.y));
                if (t != null && isFlatWalkable(t) && t.getZ() == baseZ) {
                    units.add(new Unit(hex.x, hex.y, types[placed % types.length]));
                    placed++;
                }
            }
            ring++;
        }
    }

    private static List<Point> getHexRing(int cq, int cr, int radius) {
        final int[][] DIRS = { {1,0},{1,-1},{0,-1},{-1,0},{-1,1},{0,1} };

        List<Point> ring = new ArrayList<>();
        int q = cq + DIRS[4][0] * radius;
        int r = cr + DIRS[4][1] * radius;

        for (int side = 0; side < 6; side++) {
            for (int step = 0; step < radius; step++) {
                ring.add(new Point(q, r));
                q += DIRS[side][0];
                r += DIRS[side][1];
            }
        }
        return ring;
    }

    private void centerCameraOnTownhall() {
        int screenCX = getWidth()  / 2;
        int screenCY = (getHeight() - RTSHUD.HUD_HEIGHT) / 2;

        if (townhallHex != null) {
            Point p = CoordinateConverter.hexToPixel(townhallHex.x, townhallHex.y);
            cameraManager.offsetX = (int)(screenCX - (p.x * cameraManager.zoom));
            cameraManager.offsetY = (int)(screenCY - (p.y * cameraManager.zoom));
        } else {
            cameraManager.offsetX = (int)(screenCX - (GridManager.landCenterPX * cameraManager.zoom));
            cameraManager.offsetY = (int)(screenCY - (GridManager.landCenterPY * cameraManager.zoom));
        }
    }

    private static int hexDist(int q1, int r1, int q2, int r2) {
        int dq = q2 - q1;
        int dr = r2 - r1;
        return (Math.abs(dq) + Math.abs(dr) + Math.abs(dq + dr)) / 2;
    }

    @Override
    public void invalidate() {
        super.invalidate();
        Dimension s = getSize();

        if (s.width > 0 && s.height > 0 && (s.width != lastWidth || s.height != lastHeight)) {
            lastWidth  = s.width;
            lastHeight = s.height;

            CoordinateConverter.computeOrigin(s.width, s.height);

            if (currentState == GameState.MENU || currentState == GameState.WORLD_SETTINGS) {
                cameraManager.centerOn(CoordinateConverter.getMapWidth(),
                        CoordinateConverter.getMapHeight(), s.width, s.height);
            } else if (currentState != GameState.LOADING && !GridManager.hexes.isEmpty()) {
                chunkRebuildPending = true;

                int screenCX = s.width  / 2;
                int screenCY = (s.height - RTSHUD.HUD_HEIGHT) / 2;
                cameraManager.offsetX = (int)(screenCX - (GridManager.landCenterPX * cameraManager.zoom));
                cameraManager.offsetY = (int)(screenCY - (GridManager.landCenterPY * cameraManager.zoom));
            }
        }
    }

    private Color interpolateColor(Color c1, Color c2, float ratio) {
        int r = (int)(c1.getRed()   + (c2.getRed()   - c1.getRed())   * ratio);
        int g = (int)(c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int)(c1.getBlue()  + (c2.getBlue()  - c1.getBlue())  * ratio);
        return new Color(r, g, b);
    }

    void updateGame() {
        if (currentState == GameState.MENU
                || currentState == GameState.WORLD_SETTINGS
                || currentState == GameState.LOADING) return;

        long now = System.nanoTime();
        double dt = Math.min((now - lastTime) / 1_000_000_000.0, 0.1);
        lastTime = now;

        movementController.updateSimulation(dt, units, commandQueue);
        totalSessionTime += dt;

        currentCycleTime += dt;
        if (currentCycleTime >= DAY_NIGHT_CYCLE_SECONDS) {
            currentCycleTime = 0.0;
            currentDay++;
            GridManager.currentDay = this.currentDay;
        }

        chunkManager.checkDailyRollover(this.currentDay);
        chunkManager.updateSubtlePurge();

        float cycleProgress = (float)(currentCycleTime / DAY_NIGHT_CYCLE_SECONDS);

        float continuousTime;
        if (cycleProgress < 0.50f) {
            continuousTime = cycleProgress * 2.0f;
        } else {
            continuousTime = 2.0f - (cycleProgress * 2.0f);
        }

        GridManager.setTimeOfDay(continuousTime);

        float normalizedTime = continuousTime / 2.0f;
        int currentTodStep = Math.max(0,
                Math.min(ChunkManager.NUM_TOD_STEPS - 1,
                        (int)(normalizedTime * ChunkManager.NUM_TOD_STEPS)));

        if (currentTodStep != lastTodStep) {
            lastTodStep = currentTodStep;
            final int capturedTodStep = currentTodStep;

            // FIX: Restored sequence gate hook. Chunk bakes wait until calculation callback signals completion
            CompletableFuture.runAsync(GridManager::calculateShadows).thenRun(() -> {
                chunkManager.setShadowsReadyForTod(capturedTodStep);
            });
        }

        Color twilightGlow = new Color(210, 90,  20);
        Color deepMidnight = new Color( 10, 15,  40);
        float maxDarkness  = 0.65f;

        float calculatedDarkness;
        Color calculatedColor;

        if (cycleProgress < 0.05f) {
            float ratio        = cycleProgress / 0.05f;
            calculatedDarkness = maxDarkness * (1.0f - ratio);
            calculatedColor    = interpolateColor(deepMidnight, twilightGlow, ratio);
        } else if (cycleProgress < 0.50f) {
            calculatedDarkness = 0.0f;
            calculatedColor    = new Color(0, 0, 0, 0);
        } else if (cycleProgress < 0.55f) {
            float ratio        = (cycleProgress - 0.50f) / 0.05f;
            calculatedDarkness = maxDarkness * ratio;
            calculatedColor    = interpolateColor(twilightGlow, deepMidnight, ratio);
        } else {
            calculatedDarkness = maxDarkness;
            calculatedColor    = deepMidnight;
        }

        int targetAlpha = (int)(calculatedDarkness * 255);
        activeNightOverlayColor = new Color(
                calculatedColor.getRed(),
                calculatedColor.getGreen(),
                calculatedColor.getBlue(),
                targetAlpha);

        repaint();
    }

    void enterWorldMode() {
        currentState      = GameState.LOADING;
        activeCommandMode = CommandMode.MOVE;

        renderer.clearSpriteCache();
        units.clear();
        commandQueue.clear();
        selectionManager.selectedUnits.clear();
        selectionManager.selectionHistory.clear();

        currentCycleTime = 0.05 * DAY_NIGHT_CYCLE_SECONDS;
        currentDay       = 1;
        GridManager.currentDay = 1;
        totalSessionTime = 0.0;
        activeNightOverlayColor = new Color(0, 0, 0, 0);
        lastTodStep = -1;

        GridManager.setTimeOfDay(0.10f);

        int sizeVal = (int)(450 * (worldSizePercentage / 100.0));
        CoordinateConverter.MAP_COLS = sizeVal;
        CoordinateConverter.MAP_ROWS = sizeVal;
        CoordinateConverter.computeOrigin(getWidth(), getHeight());

        long finalSeed = seedInputString.isEmpty()
                ? new java.util.Random().nextLong()
                : Long.parseLong(seedInputString);

        updateLoading(5, "Clearing active simulation memory grids...");

        new Thread(() -> {
            try {
                Thread.sleep(50);
                updateLoading(15, "Generating procedural landmass from seed: " + finalSeed + "...");
                GridManager.generateMap(finalSeed);

                updateLoading(30, "Calculating world map directional lighting and vector shadows...");
                GridManager.calculateShadows();

                updateLoading(45, "Calculating optimal starting coordinates for faction Town Hall...");
                spawnTownhall();

                updateLoading(60, "Initializing dynamic chunk indexing structures...");
                chunkManager.buildChunks(renderer);

                Point spawnPixel = null;
                if (townhallHex != null) {
                    spawnPixel = CoordinateConverter.hexToPixel(townhallHex.x, townhallHex.y);
                }

                int initialTod = getInitialTodStep();
                chunkManager.setShadowsReadyForTod(initialTod);

                updateLoading(75, "Pre-rendering local world view assets...");
                chunkManager.preBakeInitialMap(initialTod, spawnPixel);

                updateLoading(90, "Baking high-performance static minimap overlay textures...");
                hudManager.bakeMinimap();

                updateLoading(98, "Assembling starting faction armies...");

                SwingUtilities.invokeLater(() -> {
                    spawnInitialUnits();
                    centerCameraOnTownhall();

                    lastTime = System.nanoTime();
                    currentState = GameState.PLAY_WORLD;
                    repaint();
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }).start();
    }

    void enterTesterMode() {
        currentState      = GameState.LOADING;
        activeCommandMode = CommandMode.MOVE;

        renderer.clearSpriteCache();
        units.clear();
        commandQueue.clear();
        selectionManager.selectedUnits.clear();
        selectionManager.selectionHistory.clear();

        currentCycleTime = 0.05 * DAY_NIGHT_CYCLE_SECONDS;
        currentDay       = 1;
        GridManager.currentDay = 1;
        totalSessionTime = 0.0;
        activeNightOverlayColor = new Color(0, 0, 0, 0);
        lastTodStep = -1;

        GridManager.setTimeOfDay(0.10f);

        CoordinateConverter.MAP_COLS = 600;
        CoordinateConverter.MAP_ROWS = 600;
        CoordinateConverter.computeOrigin(getWidth(), getHeight());

        updateLoading(10, "Prepping building test sandbox...");

        new Thread(() -> {
            try {
                Thread.sleep(50);
                updateLoading(30, "Flattening full-scale uniform terrain matrix...");
                BuildTesterWorld.setup(units);

                GridManager.calculateShadows();

                updateLoading(50, "Initializing sandbox chunk frameworks...");
                chunkManager.buildChunks(renderer);

                int initialTod = getInitialTodStep();
                chunkManager.setShadowsReadyForTod(initialTod);

                Point sandboxCenterPixel = new Point((int)GridManager.landCenterPX, (int)GridManager.landCenterPY);

                updateLoading(70, "Pre-rendering sandbox viewport terrain segments...");
                chunkManager.preBakeInitialMap(initialTod, sandboxCenterPixel);

                updateLoading(85, "Baking sandbox minimap vectors...");
                hudManager.bakeMinimap();

                updateLoading(95, "Spawning builder squad...");

                SwingUtilities.invokeLater(() -> {
                    int screenCX = getWidth()  / 2;
                    int screenCY = (getHeight() - RTSHUD.HUD_HEIGHT) / 2;
                    cameraManager.offsetX = (int)(screenCX - (GridManager.landCenterPX * cameraManager.zoom));
                    cameraManager.offsetY = (int)(screenCY - (GridManager.landCenterPY * cameraManager.zoom));

                    lastTime = System.nanoTime();
                    currentState = GameState.PLAY_TESTER;
                    repaint();
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }).start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        if (currentState == GameState.MENU) {
            menuRenderer.drawMainMenu(g2d, getWidth(), getHeight());
            return;
        }
        if (currentState == GameState.WORLD_SETTINGS) {
            menuRenderer.drawWorldSettingsMenu(g2d, getWidth(), getHeight(),
                    worldSizePercentage, seedInputString,
                    sizeMinusBtn, sizePlusBtn, startWorldBtn, settingsBackBtn);
            return;
        }
        if (currentState == GameState.LOADING) {
            menuRenderer.drawLoadingScreen(g2d, getWidth(), getHeight(),
                    loadingProgress, loadingStatus);
            return;
        }

        if (chunkRebuildPending && !GridManager.hexes.isEmpty()) {
            chunkRebuildPending = false;
            chunkManager.buildChunks(renderer);
        }

        java.awt.geom.AffineTransform oldTransform = g2d.getTransform();

        g2d.scale(cameraManager.zoom, cameraManager.zoom);
        g2d.translate(cameraManager.offsetX, cameraManager.offsetY);

        selectionManager.dragStartX = this.dragStartX;
        selectionManager.dragStartY = this.dragStartY;
        selectionManager.dragEndX   = this.dragEndX;
        selectionManager.dragEndY   = this.dragEndY;
        selectionManager.dragging   = this.dragging;

        chunkManager.renderChunks(g2d,
                cameraManager.offsetX, cameraManager.offsetY,
                getWidth(), getHeight(), cameraManager.zoom);

        g2d.setTransform(oldTransform);
        if (activeNightOverlayColor.getAlpha() > 0) {
            g2d.setColor(activeNightOverlayColor);
            g2d.fillRect(0, 0, getWidth(), getHeight());

            g2d.scale(cameraManager.zoom, cameraManager.zoom);
            g2d.translate(cameraManager.offsetX, cameraManager.offsetY);

            if (townhallHex != null) {
                int nightAlpha = activeNightOverlayColor.getAlpha();

                for (int dq = -11; dq <= 11; dq++) {
                    for (int dr = Math.max(-11, -dq - 11);
                         dr <= Math.min(11, -dq + 11); dr++) {

                        int distance   = hexDist(0, 0, dq, dr);
                        int lightLevel = (distance <= 4) ? 7 : 7 - (distance - 4);

                        if (lightLevel > 0) {
                            int targetQ = townhallHex.x + dq;
                            int targetR = townhallHex.y + dr;
                            HexTile standingTile = GridManager.hexes.get(HexMath.key(targetQ, targetR));

                            if (standingTile != null) {
                                Point pos = CoordinateConverter.hexToPixel(targetQ, targetR);
                                int aGlow = (int)((lightLevel / 7.0f) * nightAlpha * 0.88f);
                                aGlow = Math.max(0, Math.min(255, aGlow));

                                g2d.setColor(groundGlowColorCache[aGlow]);
                                drawFlatGroundLightHex(g2d, pos.x, pos.y, standingTile.getZ(), hexSize);
                            }
                        }
                    }
                }
            }
            g2d.setTransform(oldTransform);
        }

        g2d.scale(cameraManager.zoom, cameraManager.zoom);
        g2d.translate(cameraManager.offsetX, cameraManager.offsetY);

        if (townhallHex != null) {
            HexTile centerTile = GridManager.hexes.get(HexMath.key(townhallHex.x, townhallHex.y));
            if (centerTile != null) {
                renderer.drawTownHall(g2d, townhallHex.x, townhallHex.y,
                        centerTile.getZ(), hexSize, new Color(40, 80, 180));
            }
        }

        renderer.renderDynamicEntities(g2d, units, selectionManager);

        g2d.setTransform(oldTransform);
        hudManager.renderHUD(g2d, getWidth(), getHeight());

        java.awt.Toolkit.getDefaultToolkit().sync();
    }

    private void drawFlatGroundLightHex(Graphics2D g, int x, int y, int z, int hexSize) {
        for (int i = 0; i < 6; i++) {
            double angle = Math.PI / 3 * i;
            lightHexX[i] = x + (int)(hexSize * Math.cos(angle));
            lightHexY[i] = y + (int)(hexSize * Math.sin(angle)) - z;
        }
        g.fillPolygon(lightHexX, lightHexY, 6);
    }

    int currentDestBoundsWidth()  { return CoordinateConverter.getMapWidth()  + 10; }
    int currentDestBoundsHeight() { return CoordinateConverter.getMapHeight() + 250; }

    public static Point hexToPixel(int q, int r) { return CoordinateConverter.hexToPixel(q, r); }
    public static Point pixelToHex(int x, int y) { return CoordinateConverter.pixelToHex(x, y); }
}