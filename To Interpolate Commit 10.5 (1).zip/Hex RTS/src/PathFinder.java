import java.awt.Point;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PathFinder {
    private static final int[][] DIRS = { {1,0},{1,-1},{0,-1},{-1,0},{-1,1},{0,1} };

    private static final ExecutorService pathExecutor = Executors.newFixedThreadPool(
            Math.max(2, Runtime.getRuntime().availableProcessors() - 1)
    );

    // OPTIMIZATION: Packs two 32-bit integers into a single 64-bit primitive long key.
    // This removes millions of string allocations ("q,r") within searching loops.
    private static long pack(int q, int r) {
        return ((long) q << 32) | (r & 0xFFFFFFFFL);
    }

    public static CompletableFuture<Deque<Point>> requestAsyncPath(int sQ, int sR, int tQ, int tR, Unit unit, Point avoidedHex) {
        return CompletableFuture.supplyAsync(() -> {
            Deque<Point> direct = computePathBetween(sQ, sR, tQ, tR, avoidedHex, unit);
            if (direct != null && !direct.isEmpty()) return direct;

            Point best = findBestReachableHex(sQ, sR, tQ, tR, unit);
            if (best == null || (best.x == sQ && best.y == sR)) return null;
            return computePathBetween(sQ, sR, best.x, best.y, avoidedHex, unit);
        }, pathExecutor);
    }

    public static Deque<Point> computePathBetween(int sQ, int sR, int tQ, int tR, Point avoidedHex, Unit unit) {
        if (sQ == tQ && sR == tR) return new ArrayDeque<>();

        Point startPx = CoordinateConverter.hexToPixel(sQ, sR);
        Point targetPx = CoordinateConverter.hexToPixel(tQ, tR);
        double dxGoal = targetPx.x - startPx.x;
        double dyGoal = targetPx.y - startPx.y;

        PriorityQueue<Node> openQueue = new PriorityQueue<>(Comparator.comparingInt((Node a) -> a.f)
                .thenComparingDouble(a -> a.lineDeviation)
                .thenComparingInt(a -> a.h).thenComparingInt(a -> a.q).thenComparingInt(a -> a.r));

        // OPTIMIZATION: Converted open/closed maps from Map<String, Node> to Map<Long, Node> via coordinates packing
        Map<Long, Node> openMap = new HashMap<>();
        Map<Long, Node> closed = new HashMap<>();

        int startH = HexMath.hexDistance(sQ, sR, tQ, tR);
        Node startNode = new Node(sQ, sR, 0, startH, startH, 0.0, null);

        openQueue.add(startNode);
        openMap.put(pack(sQ, sR), startNode);

        Node goal = null;
        int iterations = 0;

        while (!openQueue.isEmpty() && iterations < 2000) {
            iterations++;
            Node cur = openQueue.poll();
            long packedCurKey = pack(cur.q, cur.r);
            openMap.remove(packedCurKey);
            closed.put(packedCurKey, cur);

            if (cur.q == tQ && cur.r == tR) {
                goal = cur;
                break;
            }

            for (int[] d : DIRS) {
                int nq = cur.q + d[0];
                int nr = cur.r + d[1];

                if (avoidedHex != null && nq == avoidedHex.x && nr == avoidedHex.y) continue;

                if (GridManager.isBlockedForPath(nq, nr, sQ, sR, tQ, tR)) {
                    if (unit != null && unit.type == UnitType.CAVALRY) {
                        int landingQ = nq + d[0];
                        int landingR = nr + d[1];

                        if (avoidedHex != null && landingQ == avoidedHex.x && landingR == avoidedHex.y) continue;

                        if (!GridManager.isBlockedForPath(landingQ, landingR, sQ, sR, tQ, tR)) {
                            long packedLandingKey = pack(landingQ, landingR);
                            if (closed.containsKey(packedLandingKey)) continue;

                            int g = cur.g + 2;
                            int h = HexMath.hexDistance(landingQ, landingR, tQ, tR);
                            int f = g + h;

                            Point nodePx = CoordinateConverter.hexToPixel(landingQ, landingR);
                            double dxNode = nodePx.x - startPx.x;
                            double dyNode = nodePx.y - startPx.y;
                            double lineDeviation = Math.abs(dxNode * dyGoal - dxGoal * dyNode);

                            Node ex = openMap.get(packedLandingKey);
                            if (ex == null || g < ex.g) {
                                Node neighbor = new Node(landingQ, landingR, g, h, f, lineDeviation, cur);
                                if (ex != null) openQueue.remove(ex);
                                openQueue.add(neighbor);
                                openMap.put(packedLandingKey, neighbor);
                            }
                        }
                    }
                    continue;
                }

                long packedNeighborKey = pack(nq, nr);
                if (closed.containsKey(packedNeighborKey)) continue;

                int g = cur.g + 1;
                int h = HexMath.hexDistance(nq, nr, tQ, tR);
                int f = g + h;

                Point nodePx = CoordinateConverter.hexToPixel(nq, nr);
                double dxNode = nodePx.x - startPx.x;
                double dyNode = nodePx.y - startPx.y;
                double lineDeviation = Math.abs(dxNode * dyGoal - dxGoal * dyNode);

                Node ex = openMap.get(packedNeighborKey);
                if (ex == null || g < ex.g) {
                    Node neighbor = new Node(nq, nr, g, h, f, lineDeviation, cur);
                    if (ex != null) openQueue.remove(ex);
                    openQueue.add(neighbor);
                    openMap.put(packedNeighborKey, neighbor);
                }
            }
        }

        if (goal == null) return null;
        List<Point> rev = new ArrayList<>();
        for (Node c = goal; c != null; c = c.parent) rev.add(new Point(c.q, c.r));
        Collections.reverse(rev);
        return new ArrayDeque<>(rev);
    }

    public static Deque<Point> trySingleStepToward(int sQ, int sR, int tQ, int tR, Unit unit) {
        if (sQ == tQ && sR == tR) return null;

        int bestDirIndex = -1;
        boolean bestIsJump = false;
        int bestDist = Integer.MAX_VALUE;

        for (int i = 0; i < DIRS.length; i++) {
            int nq = sQ + DIRS[i][0];
            int nr = sR + DIRS[i][1];

            if (GridManager.isBlockedForPath(nq, nr, sQ, sR, tQ, tR)) {
                if (unit != null && unit.type == UnitType.CAVALRY) {
                    int lq = nq + DIRS[i][0];
                    int lr = nr + DIRS[i][1];
                    if (!GridManager.isBlockedForPath(lq, lr, sQ, sR, tQ, tR)) {
                        int d = HexMath.hexDistance(lq, lr, tQ, tR);
                        if (d < bestDist) {
                            bestDist = d;
                            bestDirIndex = i;
                            bestIsJump = true;
                        }
                    }
                }
                continue;
            }

            int d = HexMath.hexDistance(nq, nr, tQ, tR);
            if (d < bestDist) {
                bestDist = d;
                bestDirIndex = i;
                bestIsJump = false;
            }
        }
        if (bestDirIndex == -1) return null;

        Deque<Point> result = new ArrayDeque<>();
        result.addLast(new Point(sQ, sR));
        if (bestIsJump) {
            result.addLast(new Point(sQ + DIRS[bestDirIndex][0] * 2, sR + DIRS[bestDirIndex][1] * 2));
        } else {
            result.addLast(new Point(sQ + DIRS[bestDirIndex][0], sR + DIRS[bestDirIndex][1]));
        }
        return result;
    }

    public static Point findBestReachableHex(int sQ, int sR, int tQ, int tR, Unit unit) {
        Queue<Point> q = new ArrayDeque<>();

        // OPTIMIZATION: Converted internal BFS tracker from Set<String> to Set<Long> primitive arrays
        Set<Long> vis = new HashSet<>();
        q.add(new Point(sQ, sR));
        vis.add(pack(sQ, sR));

        Point best = new Point(sQ, sR);
        int bestD = HexMath.hexDistance(sQ, sR, tQ, tR);

        int bfsLimit = 0;
        while (!q.isEmpty() && bfsLimit < 2500) {
            bfsLimit++;
            Point p = q.poll();
            int d = HexMath.hexDistance(p.x, p.y, tQ, tR);
            if (d < bestD) {
                bestD = d;
                best = p;
            }
            for (int[] dir : DIRS) {
                int nq = p.x + dir[0];
                int nr = p.y + dir[1];

                if (GridManager.isOutOfBounds(nq, nr)) continue;

                // OPTIMIZATION: Primitive containment check avoids evaluating strings for already visited nodes
                long packedNeighborKey = pack(nq, nr);
                if (vis.contains(packedNeighborKey)) continue;

                // String conversion is isolated down here, only instantiated for completely unvisited tiles
                String k = HexMath.key(nq, nr);
                if (GridManager.isHexOccupiedByOther(nq, nr, unit) || GridManager.transitOccupied.contains(k)) {
                    if (unit != null && unit.type == UnitType.CAVALRY) {
                        int lq = nq + dir[0];
                        int lr = nr + dir[1];
                        if (!GridManager.isOutOfBounds(lq, lr)) {
                            long packedLandingKey = pack(lq, lr);
                            String lk = HexMath.key(lq, lr);
                            if (!vis.contains(packedLandingKey) && !GridManager.isHexOccupiedByOther(lq, lr, unit) && !GridManager.transitOccupied.contains(lk)) {
                                vis.add(packedLandingKey);
                                q.add(new Point(lq, lr));
                            }
                        }
                    }
                    continue;
                }
                vis.add(packedNeighborKey);
                q.add(new Point(nq, nr));
            }
        }
        return best;
    }

    public static Point findNearestFreeHex(int sQ, int sR, Unit exclude) {
        Queue<Point> q = new ArrayDeque<>();

        // OPTIMIZATION: Converted track maps from Set<String> to Set<Long>
        Set<Long> vis = new HashSet<>();
        q.add(new Point(sQ, sR));
        vis.add(pack(sQ, sR));

        while (!q.isEmpty()) {
            Point p = q.poll();
            if (!GridManager.isHexOccupiedByOther(p.x, p.y, exclude) && !GridManager.transitOccupied.contains(HexMath.key(p.x, p.y))) {
                return p;
            }
            for (int[] d : DIRS) {
                int nq = p.x + d[0];
                int nr = p.y + d[1];
                if (GridManager.isOutOfBounds(nq, nr)) continue;

                long packedNeighborKey = pack(nq, nr);
                if (!vis.contains(packedNeighborKey)) {
                    vis.add(packedNeighborKey);
                    q.add(new Point(nq, nr));
                }
            }
        }
        return null;
    }

    private static class Node {
        int q, r, g, h, f;
        double lineDeviation;
        Node parent;
        Node(int q, int r, int g, int h, int f, double lineDeviation, Node p) {
            this.q = q; this.r = r; this.g = g; this.h = h; this.f = f;
            this.lineDeviation = lineDeviation; this.parent = p;
        }
    }
}