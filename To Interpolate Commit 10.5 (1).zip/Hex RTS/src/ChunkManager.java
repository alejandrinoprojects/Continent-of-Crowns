import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ChunkManager {
    public static final int CHUNK_SIZE = 512;
    private static final int NUM_FRAMES = 8;
    public static final int NUM_TOD_STEPS = 20;

    private static final GraphicsConfiguration GFX_CONFIG =
            GraphicsEnvironment.getLocalGraphicsEnvironment()
                    .getDefaultScreenDevice()
                    .getDefaultConfiguration();

    private final ConcurrentHashMap<Long, BufferedImage> sparseChunkCache = new ConcurrentHashMap<>();
    private final ConcurrentLinkedQueue<Long> allocatedChunkRegistry = new ConcurrentLinkedQueue<>();
    private final AtomicInteger allocatedCount = new AtomicInteger(0);

    private static final int MAX_CACHED_SLICES = 350;

    private List<HexTile>[][] chunkTileBuckets;
    private GameRenderer cachedRendererReference;
    private int cols;
    private int rows;

    private final Set<String> chunksInQueue = ConcurrentHashMap.newKeySet();
    private int lastProcessedDay = 1;

    // FIX: Restored volatile tracking gate to ensure threads don't bake stale vectors
    private volatile int shadowsReadyForTod = -1;

    private volatile int activeStartCol = -1;
    private volatile int activeEndCol = -1;
    private volatile int activeStartRow = -1;
    private volatile int activeEndRow = -1;

    private final ExecutorService bakeExecutor = Executors.newFixedThreadPool(
            Math.max(1, Runtime.getRuntime().availableProcessors() - 1),
            runnable -> {
                Thread thread = new Thread(runnable);
                thread.setDaemon(true);
                thread.setName("ContinentalConquest-ChunkBaker");
                return thread;
            }
    );

    private static long packChunkKey(int cx, int cy, int tod, int frame) {
        return ((long) cx << 48) | ((long) (cy & 0xFFFF) << 32) | ((long) (tod & 0xFFFF) << 16) | (frame & 0xFFFF);
    }

    public void setShadowsReadyForTod(int todIndex) {
        this.shadowsReadyForTod = todIndex;
    }

    @SuppressWarnings("unchecked")
    public void buildChunks(GameRenderer renderer) {
        this.cachedRendererReference = renderer;
        chunksInQueue.clear();
        this.lastProcessedDay = 1;
        this.shadowsReadyForTod = -1;

        for (BufferedImage img : sparseChunkCache.values()) {
            if (img != null) img.flush();
        }
        sparseChunkCache.clear();
        allocatedChunkRegistry.clear();
        allocatedCount.set(0);

        int mapWidth = CoordinateConverter.getMapWidth();
        int mapHeight = CoordinateConverter.getMapHeight();

        cols = (int) Math.ceil((double) mapWidth / CHUNK_SIZE);
        rows = (int) Math.ceil((double) mapHeight / CHUNK_SIZE);

        chunkTileBuckets = new ArrayList[cols][rows];

        List<HexTile> allTiles = new ArrayList<>(GridManager.hexes.values());
        allTiles.sort((t1, t2) -> {
            int y1 = CoordinateConverter.getPixelY(t1.q, t1.r);
            int y2 = CoordinateConverter.getPixelY(t2.q, t2.r);
            if (y1 != y2) return Integer.compare(y1, y2);
            return Integer.compare(CoordinateConverter.getPixelX(t1.q, t1.r), CoordinateConverter.getPixelX(t2.q, t2.r));
        });

        for (HexTile tile : allTiles) {
            Point p = CoordinateConverter.hexToPixel(tile.q, tile.r);
            int maxZ = Math.max(0, tile.getZ());
            Rectangle tileBounds = new Rectangle(p.x - 120, p.y - maxZ - 120, maxZ + 240, maxZ + 240);

            int startCx = Math.max(0, tileBounds.x / CHUNK_SIZE);
            int endCx = Math.min(cols - 1, (tileBounds.x + tileBounds.width) / CHUNK_SIZE);
            int startCy = Math.max(0, tileBounds.y / CHUNK_SIZE);
            int endCy = Math.min(rows - 1, (tileBounds.y + tileBounds.height) / CHUNK_SIZE);

            for (int cx = startCx; cx <= endCx; cx++) {
                for (int cy = startCy; cy <= endCy; cy++) {
                    Rectangle chunkBounds = new Rectangle(cx * CHUNK_SIZE, cy * CHUNK_SIZE, CHUNK_SIZE, CHUNK_SIZE);

                    if (chunkBounds.intersects(tileBounds)) {
                        if (chunkTileBuckets[cx][cy] == null) {
                            chunkTileBuckets[cx][cy] = new ArrayList<>();
                        }
                        chunkTileBuckets[cx][cy].add(tile);
                    }
                }
            }
        }
    }

    public void preBakeInitialMap(int startTod, Point centerPixelPoint) {
        int centerCx = cols / 2;
        int centerCy = rows / 2;

        if (centerPixelPoint != null) {
            centerCx = Math.max(0, centerPixelPoint.x / CHUNK_SIZE);
            centerCy = Math.max(0, centerPixelPoint.y / CHUNK_SIZE);
        }

        System.out.println("[ChunkManager] Pre-baking localized starting area around chunk (" + centerCx + "," + centerCy + ") for TOD step: " + startTod);

        int radius = 3;
        int startCx = Math.max(0, centerCx - radius);
        int endCx = Math.min(cols - 1, centerCx + radius);
        int startCy = Math.max(0, centerCy - radius);
        int endCy = Math.min(rows - 1, centerCy + radius);

        for (int cx = startCx; cx <= endCx; cx++) {
            for (int cy = startCy; cy <= endCy; cy++) {
                submitBakeTaskAsync(cx, cy, startTod);
            }
        }

        while (!chunksInQueue.isEmpty()) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        System.out.println("[ChunkManager] Localized viewport pre-bake complete.");
    }

    public void checkDailyRollover(int currentDay) {
        if (currentDay != lastProcessedDay) {
            lastProcessedDay = currentDay;
            allocatedChunkRegistry.clear();
            allocatedCount.set(0);
        }
    }

    public void updateSubtlePurge() {
        // Discarded to maintain fallback streaming capabilities
    }

    private void submitBakeTaskAsync(final int cx, final int cy, final int todIndex) {
        final String key = cx + "," + cy + "," + todIndex;

        if (!chunksInQueue.add(key)) {
            return;
        }

        bakeExecutor.submit(() -> {
            try {
                if (isTaskObsolete(cx, cy)) {
                    return;
                }

                List<HexTile> bucketTiles = chunkTileBuckets[cx][cy];
                if (bucketTiles == null || bucketTiles.isEmpty()) {
                    return;
                }

                TreeSet<Integer> uniqueHeights = new TreeSet<>();
                for (HexTile tile : bucketTiles) {
                    uniqueHeights.add(tile.getZ());
                }

                BufferedImage[] bakedFrames = new BufferedImage[NUM_FRAMES];

                for (int f = 0; f < NUM_FRAMES; f++) {
                    if (isTaskObsolete(cx, cy)) {
                        cleanArraySurfaces(bakedFrames);
                        return;
                    }

                    BufferedImage bImg = GFX_CONFIG.createCompatibleImage(CHUNK_SIZE, CHUNK_SIZE, Transparency.TRANSLUCENT);
                    Graphics2D g2d = bImg.createGraphics();
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    int pixelOffsetX = cx * CHUNK_SIZE;
                    int pixelOffsetY = cy * CHUNK_SIZE;
                    g2d.translate(-pixelOffsetX, -pixelOffsetY);

                    for (int currentZ : uniqueHeights) {
                        for (HexTile tile : bucketTiles) {
                            if (tile.getZ() == currentZ) {
                                Point p = CoordinateConverter.hexToPixel(tile.q, tile.r);
                                cachedRendererReference.drawSingleTile(g2d, tile, p, f);
                            }
                        }
                    }
                    g2d.dispose();
                    bakedFrames[f] = bImg;
                }

                if (isTaskObsolete(cx, cy)) {
                    cleanArraySurfaces(bakedFrames);
                } else {
                    boolean isOverwrite = false;
                    for (int f = 0; f < NUM_FRAMES; f++) {
                        long packedKey = packChunkKey(cx, cy, todIndex, f);
                        BufferedImage oldImg = sparseChunkCache.put(packedKey, bakedFrames[f]);
                        if (oldImg != null) {
                            oldImg.flush();
                            isOverwrite = true;
                        }
                    }

                    if (!isOverwrite) {
                        long sliceTrackingKey = ((long) cx << 32) | ((long) cy << 16) | (todIndex & 0xFFFF);
                        allocatedChunkRegistry.add(sliceTrackingKey);

                        if (allocatedCount.incrementAndGet() > MAX_CACHED_SLICES) {
                            evictOldestCacheSlices();
                        }
                    }
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                chunksInQueue.remove(key);
            }
        });
    }

    private void evictOldestCacheSlices() {
        int protectionThreshold = 0;

        while (allocatedCount.get() > MAX_CACHED_SLICES && protectionThreshold < 15) {
            protectionThreshold++;
            Long oldKey = allocatedChunkRegistry.poll();
            if (oldKey == null) {
                allocatedCount.set(allocatedChunkRegistry.size());
                break;
            }

            int oldCx = (int) (oldKey >> 32);
            int oldCy = (int) ((oldKey >> 16) & 0xFFFF);
            int oldTod = (int) (oldKey & 0xFFFF);

            if (isChunkVisible(oldCx, oldCy)) {
                allocatedChunkRegistry.add(oldKey);
            } else {
                boolean cleared = false;
                for (int f = 0; f < NUM_FRAMES; f++) {
                    long packedKey = packChunkKey(oldCx, oldCy, oldTod, f);
                    BufferedImage img = sparseChunkCache.remove(packedKey);
                    if (img != null) {
                        img.flush();
                        cleared = true;
                    }
                }
                if (cleared) {
                    allocatedCount.decrementAndGet();
                }
            }
        }
    }

    private boolean isChunkVisible(int cx, int cy) {
        if (activeStartCol == -1) return true;
        return (cx >= activeStartCol && cx <= activeEndCol &&
                cy >= activeStartRow && cy <= activeEndRow);
    }

    private boolean isTaskObsolete(int cx, int cy) {
        if (activeStartCol == -1) return false;

        int bufferRange = 3;
        return (cx < activeStartCol - bufferRange || cx > activeEndCol + bufferRange ||
                cy < activeStartRow - bufferRange || cy > activeEndRow + bufferRange);
    }

    private void cleanArraySurfaces(BufferedImage[] frames) {
        for (BufferedImage img : frames) {
            if (img != null) img.flush();
        }
    }

    public void renderChunks(Graphics2D g, int camX, int camY, int screenW, int screenH, double zoom) {
        int viewWorldX = -camX;
        int viewWorldY = -camY;
        int viewWorldW = (int) (screenW / zoom);
        int viewWorldH = (int) (screenH / zoom);

        int tolerance = 1;
        int startCol = Math.max(0, (viewWorldX / CHUNK_SIZE) - tolerance);
        int startRow = Math.max(0, (viewWorldY / CHUNK_SIZE) - tolerance);
        int endCol = Math.min(cols - 1, ((viewWorldX + viewWorldW) / CHUNK_SIZE) + 1 + tolerance);
        int endRow = Math.min(rows - 1, ((viewWorldY + viewWorldH) / CHUNK_SIZE) + 1 + tolerance);

        this.activeStartCol = startCol;
        this.activeEndCol = endCol;
        this.activeStartRow = startRow;
        this.activeEndRow = endRow;

        int globalFrame = (int) ((System.currentTimeMillis() / 240) % NUM_FRAMES);

        float normalizedTime = GridManager.timeOfDay / 2.0f;
        int currentTod = Math.max(0, Math.min(NUM_TOD_STEPS - 1, (int)(normalizedTime * NUM_TOD_STEPS)));

        for (int cx = startCol; cx <= endCol; cx++) {
            for (int cy = startRow; cy <= endRow; cy++) {

                long activePackedKey = packChunkKey(cx, cy, currentTod, globalFrame);
                BufferedImage toDraw = sparseChunkCache.get(activePackedKey);

                if (toDraw == null) {
                    // FIX: Only trigger textures to bake if vectors are completely stabilized
                    if (shadowsReadyForTod == currentTod) {
                        submitBakeTaskAsync(cx, cy, currentTod);
                    }

                    // Look up nearby time frames if the current frame is still baking
                    for (int offset = 1; offset < NUM_TOD_STEPS; offset++) {
                        int lowerCheck = (currentTod - offset + NUM_TOD_STEPS) % NUM_TOD_STEPS;
                        long packedLower = packChunkKey(cx, cy, lowerCheck, globalFrame);
                        BufferedImage imgCheck = sparseChunkCache.get(packedLower);
                        if (imgCheck != null) {
                            toDraw = imgCheck;
                            break;
                        }

                        int upperCheck = (currentTod + offset) % NUM_TOD_STEPS;
                        long packedUpper = packChunkKey(cx, cy, upperCheck, globalFrame);
                        BufferedImage imgCheckUpper = sparseChunkCache.get(packedUpper);
                        if (imgCheckUpper != null) {
                            toDraw = imgCheckUpper;
                            break;
                        }
                    }
                }

                if (toDraw != null) {
                    g.drawImage(toDraw, cx * CHUNK_SIZE, cy * CHUNK_SIZE, null);
                }
            }
        }
    }
}