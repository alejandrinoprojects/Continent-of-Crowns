import java.awt.Point;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class MovementController {

    private static final int[][] AXIS_STEPS = {
            {1, 0},   // Native Axis 0
            {0, 1},   // Native Axis 1
            {1, -1}   // Native Axis 2
    };

    private static final double[] AXIS_ANGLES = {
            Math.PI / 6.0,       // 30 deg
            Math.PI / 2.0,       // 90 deg
            -Math.PI / 6.0       // -30 deg
    };

    public void updateSimulation(double dt, List<Unit> units, Queue<Command> commandQueue) {
        if (!commandQueue.isEmpty()) commandQueue.poll().execute();
        GridManager.allUnits = units;

        GridManager.clearGridOccupancy();
        for (Unit u : units) GridManager.markHex(u.q, u.r, u);

        GridManager.transitOccupied.clear();
        for (Unit u : units) {
            if (u.movingSegment) {
                GridManager.transitOccupied.add(HexMath.key(u.toQ, u.toR));
            }
        }

        List<Unit> movingUnits = new ArrayList<>(units);
        movingUnits.sort((u1, u2) -> {
            if (u1.currentOrder == null && u2.currentOrder == null) return 0;
            if (u1.currentOrder == null) return 1;
            if (u2.currentOrder == null) return -1;
            int targetQ1 = (u1.formationTargetQ != null) ? u1.formationTargetQ : u1.currentOrder.targetQ;
            int targetR1 = (u1.formationTargetR != null) ? u1.formationTargetR : u1.currentOrder.targetR;
            int targetQ2 = (u2.formationTargetQ != null) ? u2.formationTargetQ : u2.currentOrder.targetQ;
            int targetR2 = (u2.formationTargetR != null) ? u2.formationTargetR : u2.currentOrder.targetR;
            int dist1 = HexMath.hexDistance(u1.q, u1.r, targetQ1, targetR1);
            int dist2 = HexMath.hexDistance(u2.q, u2.r, targetQ2, targetR2);
            return Integer.compare(dist1, dist2);
        });

        Set<String> frameReserved = new HashSet<>();
        for (Unit u : movingUnits) {
            u.updateMovement(dt, frameReserved);
        }
    }

    public void issueGroupMove(List<Unit> selectedUnits, int destQ, int destR, CommandType cmd) {
        if (selectedUnits == null || selectedUnits.isEmpty()) return;

        if (selectedUnits.size() == 1) {
            Unit u = selectedUnits.get(0);
            u.formationTargetQ = null;
            u.formationTargetR = null;
            u.applyNewOrder(new Order(cmd, destQ, destR));
            return;
        }

        // --- 1. DETERMINE APPROACH VECTOR ---
        double cx = 0, cy = 0;
        for (Unit u : selectedUnits) {
            cx += u.x;
            cy += u.y;
        }
        cx /= selectedUnits.size();
        cy /= selectedUnits.size();

        Point destPx = CoordinateConverter.hexToPixel(destQ, destR);
        double dx = destPx.x - cx;
        double dy = destPx.y - cy;

        double approachAngle = Math.atan2(dy, dx);
        double idealPerpAngle = approachAngle + (Math.PI / 2.0);

        int bestAxisIndex = 0;
        double minAngleDiff = Double.MAX_VALUE;

        for (int i = 0; i < AXIS_ANGLES.length; i++) {
            double diffForward = getAngleDifference(idealPerpAngle, AXIS_ANGLES[i]);
            double diffBackward = getAngleDifference(idealPerpAngle, AXIS_ANGLES[i] + Math.PI);
            double minLocalDiff = Math.min(diffForward, diffBackward);

            if (minLocalDiff < minAngleDiff) {
                minAngleDiff = minLocalDiff;
                bestAxisIndex = i;
            }
        }

        int rankStepQ = AXIS_STEPS[bestAxisIndex][0];
        int rankStepR = AXIS_STEPS[bestAxisIndex][1];

        int[][] allDirs = { {1,0}, {1,-1}, {0,-1}, {-1,0}, {-1,1}, {0,1} };
        int bestFileDirIndex = 0;
        double maxDot = -Double.MAX_VALUE;

        for (int i = 0; i < allDirs.length; i++) {
            Point neighborPx = CoordinateConverter.hexToPixel(destQ + allDirs[i][0], destR + allDirs[i][1]);
            double ndx = neighborPx.x - destPx.x;
            double ndy = neighborPx.y - destPx.y;
            double len = Math.sqrt(ndx * ndx + ndy * ndy);
            double dot = ((ndx / len) * (-dx)) + ((ndy / len) * (-dy));
            if (dot > maxDot) {
                maxDot = dot;
                bestFileDirIndex = i;
            }
        }

        int fileStepQ = allDirs[bestFileDirIndex][0];
        int fileStepR = allDirs[bestFileDirIndex][1];

        // --- 2. GENERATE CONTIGUOUS SLOTS ALONG NATIVE AXES ---
        List<Point> targetSlots = new ArrayList<>();
        Set<String> assignedKeys = new HashSet<>();

        int totalUnits = selectedUnits.size();
        int maxUnitsPerRank = Math.min(7, Math.max(3, (int) Math.ceil(Math.sqrt(totalUnits) * 1.3)));
        int currentFileRank = 0;

        while (targetSlots.size() < totalUnits && currentFileRank < 15) {
            int rankAnchorQ = destQ + (currentFileRank * fileStepQ);
            int rankAnchorR = destR + (currentFileRank * fileStepR);
            int neededInThisRank = Math.min(maxUnitsPerRank, totalUnits - targetSlots.size());

            for (int i = 0; i < neededInThisRank; i++) {
                int offset = (i % 2 == 0) ? (i / 2) : -((i + 1) / 2);
                int slotQ = rankAnchorQ + (offset * rankStepQ);
                int slotR = rankAnchorR + (offset * rankStepR);

                if (!GridManager.isOutOfBounds(slotQ, slotR)) {
                    String key = HexMath.key(slotQ, slotR);
                    if (!assignedKeys.contains(key)) {
                        assignedKeys.add(key);
                        targetSlots.add(new Point(slotQ, slotR));
                        if (targetSlots.size() == totalUnits) break;
                    }
                }
            }
            currentFileRank++;
        }

        // --- FIXED FALLBACK BFS EXPANSION ---
        if (targetSlots.size() < totalUnits) {
            Queue<Point> queue = new ArrayDeque<>();
            // THE FIX: Track enqueued keys instantly to completely block duplication loops
            Set<String> enqueuedKeys = new HashSet<>(assignedKeys);

            queue.add(new Point(destQ, destR));
            enqueuedKeys.add(HexMath.key(destQ, destR));

            while (!queue.isEmpty() && targetSlots.size() < totalUnits) {
                Point curr = queue.poll();
                String key = HexMath.key(curr.x, curr.y);

                if (!assignedKeys.contains(key) && !GridManager.isOutOfBounds(curr.x, curr.y)) {
                    assignedKeys.add(key);
                    targetSlots.add(curr);
                }

                for (int[] d : allDirs) {
                    int nq = curr.x + d[0];
                    int nr = curr.y + d[1];

                    if (!GridManager.isOutOfBounds(nq, nr)) {
                        String nk = HexMath.key(nq, nr);
                        if (!enqueuedKeys.contains(nk)) {
                            enqueuedKeys.add(nk); // Flag immediately upon enqueueing
                            queue.add(new Point(nq, nr));
                        }
                    }
                }
            }
        }

        // --- 3. PARALLEL PROJECTION PAIRING ---
        Point rankStepPx = CoordinateConverter.hexToPixel(destQ + rankStepQ, destR + rankStepR);
        double rankVisualX = rankStepPx.x - destPx.x;
        double rankVisualY = rankStepPx.y - destPx.y;
        double rLen = Math.sqrt(rankVisualX * rankVisualX + rankVisualY * rankVisualY);
        double normRankX = rankVisualX / rLen;
        double normRankY = rankVisualY / rLen;

        List<Unit> unitsToAssign = new ArrayList<>(selectedUnits);
        unitsToAssign.sort(Comparator.comparingDouble(u -> (u.x * normRankX + u.y * normRankY)));

        targetSlots.sort(Comparator.comparingDouble(slot -> {
            Point spx = CoordinateConverter.hexToPixel(slot.x, slot.y);
            return (spx.x * normRankX + spx.y * normRankY);
        }));

        for (int i = 0; i < unitsToAssign.size(); i++) {
            Unit u = unitsToAssign.get(i);
            Point slot = targetSlots.get(i);
            u.formationTargetQ = slot.x;
            u.formationTargetR = slot.y;
            u.applyNewOrder(new Order(cmd, destQ, destR));
        }
    }

    private double getAngleDifference(double angle1, double angle2) {
        double diff = Math.abs(angle1 - angle2) % (Math.PI * 2);
        return diff > Math.PI ? (Math.PI * 2) - diff : diff;
    }
}