import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.Area;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.IntStream;

public class GridManager {
    public static final Map<String, HexTile> hexes = new ConcurrentHashMap<>();
    private static final Map<String, Unit> gridOccupied = new ConcurrentHashMap<>();

    public static final Set<String> transitOccupied = Collections.synchronizedSet(new HashSet<>());
    public static List<Unit> allUnits;

    public static int landCenterPX = 0;
    public static int landCenterPY = 0;

    public static float timeOfDay = 0.0f;
    public static int currentDay = 1;

    public static final Map<HexTile, Integer> rockDistToGrass = new ConcurrentHashMap<>();

    private static final int[][] DIRS = { {1,0},{1,-1},{0,-1},{-1,0},{-1,1},{0,1} };

    public static void setTimeOfDay(float time) {
        timeOfDay = Math.max(0.0f, Math.min(2.0f, time));
    }

    public static void generateMap(long seed) {
        hexes.clear();
        rockDistToGrass.clear();
        int cols = CoordinateConverter.MAP_COLS;
        int rows = CoordinateConverter.MAP_ROWS;

        double scaleF = 1.0;

        Random rand = new Random(seed);
        Perlin2D elevationNoise = new Perlin2D(rand.nextLong());
        Perlin2D featureNoise = new Perlin2D(rand.nextLong());

        double centerX = CoordinateConverter.getMapWidth() / 2.0;
        double centerY = CoordinateConverter.getMapHeight() / 2.0;

        double sizeRatio = (double) cols / 450.0;

        double dynamicCoeff = 0.34 + (Math.log10(sizeRatio) * 0.12);
        dynamicCoeff = Math.max(0.30, Math.min(0.55, dynamicCoeff));
        double maxRadius = Math.min(CoordinateConverter.getMapWidth(), CoordinateConverter.getMapHeight()) * dynamicCoeff;

        IntStream.range(0, cols).parallel().forEach(q -> {
            int rOffset = q >> 1;
            for (int r = -rOffset; r < rows - rOffset; r++) {
                HexTile tile = new HexTile(q, r);
                Point p = CoordinateConverter.hexToPixel(q, r);

                double dx = p.x - centerX;
                double dy = p.y - centerY;
                double distance = Math.sqrt(dx * dx + dy * dy);

                double mask = Math.max(0.0, 1.0 - (distance / maxRadius));
                double falloffPower = Math.max(0.5, 1.1 - (sizeRatio * 0.1));
                mask = Math.pow(mask, falloffPower);

                double n1 = elevationNoise.noise(q * 0.014 * scaleF, r * 0.014 * scaleF);
                double n2 = elevationNoise.noise(q * 0.05 * scaleF,  r * 0.05 * scaleF)  * 0.35;
                double n3 = elevationNoise.noise(q * 0.15 * scaleF,  r * 0.15 * scaleF)  * 0.12;
                double rawNoise = (n1 + n2 + n3) / 1.47;

                double finalHeight = (rawNoise * 0.28) + (mask * 0.72);

                if (finalHeight < 0.20) {
                    tile.terrain = TerrainType.RIVER;
                } else {
                    tile.terrain = TerrainType.GRASS;
                }
                tile.customZ = -1;
                hexes.put(HexMath.key(q, r), tile);
            }
        });

        for (int smoothPass = 0; smoothPass < 3; smoothPass++) {
            List<HexTile> toOcean = Collections.synchronizedList(new ArrayList<>());
            List<HexTile> toLand = Collections.synchronizedList(new ArrayList<>());

            hexes.values().parallelStream().forEach(t -> {
                int waterNeighbors = 0;
                for (int[] d : DIRS) {
                    HexTile n = hexes.get(HexMath.key(t.q + d[0], t.r + d[1]));
                    if (n == null || n.terrain == TerrainType.RIVER) {
                        waterNeighbors++;
                    }
                }
                if (t.terrain == TerrainType.GRASS && waterNeighbors >= 5) {
                    toOcean.add(t);
                } else if (t.terrain == TerrainType.RIVER && waterNeighbors <= 1) {
                    toLand.add(t);
                }
            });

            toOcean.parallelStream().forEach(t -> t.terrain = TerrainType.RIVER);
            toLand.parallelStream().forEach(t -> t.terrain = TerrainType.GRASS);
        }

        int centerQ = cols / 2;
        int centerR = (rows / 2) - (centerQ >> 1);
        HexTile anchorSeed = hexes.get(HexMath.key(centerQ, centerR));

        if (anchorSeed == null || anchorSeed.terrain == TerrainType.RIVER) {
            for (int radius = 1; radius < 100; radius++) {
                boolean found = false;
                for (int[] d : DIRS) {
                    HexTile check = hexes.get(HexMath.key(centerQ + d[0]*radius, centerR + d[1]*radius));
                    if (check != null && check.terrain == TerrainType.GRASS) {
                        anchorSeed = check; found = true; break;
                    }
                }
                if (found) break;
            }
        }

        Set<HexTile> connectedContinent = new HashSet<>();
        if (anchorSeed != null) {
            Queue<HexTile> cQueue = new LinkedList<>();
            cQueue.add(anchorSeed);
            connectedContinent.add(anchorSeed);

            while (!cQueue.isEmpty()) {
                HexTile curr = cQueue.poll();
                for (int[] d : DIRS) {
                    HexTile n = hexes.get(HexMath.key(curr.q + d[0], curr.r + d[1]));
                    if (n != null && n.terrain == TerrainType.GRASS && !connectedContinent.contains(n)) {
                        connectedContinent.add(n); cQueue.add(n);
                    }
                }
            }
        }

        hexes.values().parallelStream().forEach(tile -> {
            if (tile.terrain == TerrainType.GRASS && !connectedContinent.contains(tile)) {
                tile.terrain = TerrainType.RIVER;
            }
        });

        hexes.values().parallelStream().forEach(tile -> {
            if (tile.terrain != TerrainType.RIVER) {
                Point p = CoordinateConverter.hexToPixel(tile.q, tile.r);

                double f1 = featureNoise.noise(p.x * 0.0005 * scaleF, p.y * 0.0005 * scaleF);
                double f2 = featureNoise.noise(p.x * 0.002 * scaleF,  p.y * 0.002 * scaleF) * 0.3;
                double finalFeature = (f1 + f2) / 1.3;

                boolean deepInland = true;
                for (int[] d : DIRS) {
                    HexTile n = hexes.get(HexMath.key(tile.q + d[0], tile.r + d[1]));
                    if (n == null || n.terrain == TerrainType.RIVER) { deepInland = false; break; }
                }

                if (deepInland && finalFeature > 0.55) {
                    tile.terrain = TerrainType.ROCK;
                } else if (deepInland) {
                    if (finalFeature < -0.45) {
                        tile.terrain = TerrainType.FOREST;
                    }
                    else if (finalFeature >= -0.45 && finalFeature < 0.15) {
                        double tRange = 0.15 - (-0.45);
                        double densityFactor = (0.15 - finalFeature) / tRange;
                        double scatterChance = Math.pow(densityFactor, 2.0) * 0.65;

                        if (java.util.concurrent.ThreadLocalRandom.current().nextDouble() < scatterChance) {
                            tile.terrain = TerrainType.FOREST;
                        }
                    }
                }
            }
        });

        int relativeMountainThreshold = Math.max(10, (cols * rows) / 12000);
        pruneClusters(TerrainType.ROCK, relativeMountainThreshold, TerrainType.GRASS);

        for (int smoothPass = 0; smoothPass < 2; smoothPass++) {
            List<HexTile> toGrass = Collections.synchronizedList(new ArrayList<>());
            List<HexTile> toRock = Collections.synchronizedList(new ArrayList<>());

            hexes.values().parallelStream().forEach(t -> {
                if (t.terrain == TerrainType.ROCK || t.terrain == TerrainType.GRASS || t.terrain == TerrainType.FOREST) {
                    int rockNeighbors = 0;
                    for (int[] d : DIRS) {
                        HexTile n = hexes.get(HexMath.key(t.q + d[0], t.r + d[1]));
                        if (n != null && n.terrain == TerrainType.ROCK) rockNeighbors++;
                    }
                    if (t.terrain == TerrainType.ROCK && rockNeighbors <= 2) {
                        toGrass.add(t);
                    } else if (t.terrain != TerrainType.ROCK && rockNeighbors >= 5) {
                        toRock.add(t);
                    }
                }
            });

            toGrass.parallelStream().forEach(t -> t.terrain = TerrainType.GRASS);
            toRock.parallelStream().forEach(t -> t.terrain = TerrainType.ROCK);
        }

        int forestPathCount = (cols * rows) / 6000;
        List<HexTile> forestNodes = Collections.synchronizedList(new ArrayList<>());

        hexes.values().parallelStream().forEach(t -> {
            if (t.terrain == TerrainType.FOREST) forestNodes.add(t);
        });

        for (int i = 0; i < forestPathCount; i++) {
            if (forestNodes.isEmpty()) break;
            HexTile startNode = forestNodes.remove(rand.nextInt(forestNodes.size()));
            Point pixelPos = CoordinateConverter.hexToPixel(startNode.q, startNode.r);
            double baseAngle = rand.nextDouble() * Math.PI * 2;

            traceForestPath(pixelPos.x, pixelPos.y, baseAngle, rand, scaleF);
        }

        Map<HexTile, Integer> rockLevels = new ConcurrentHashMap<>();
        hexes.values().parallelStream().forEach(tile -> {
            if (tile.terrain == TerrainType.ROCK) rockLevels.put(tile, 1);
        });

        boolean changed = true;
        int currentLevel = 1;
        while (changed) {
            changed = false;
            List<HexTile> toPromote = Collections.synchronizedList(new ArrayList<>());

            final int lvl = currentLevel;

            rockLevels.entrySet().parallelStream().forEach(entry -> {
                if (entry.getValue() == lvl) {
                    HexTile tile = entry.getKey();
                    int requiredNeighbors = 6;
                    int variance = Math.abs(tile.q * 17 + tile.r * 31) % 100;
                    if (variance < 20) requiredNeighbors = 4;
                    else if (variance < 60) requiredNeighbors = 5;

                    int neighborCount = 0;
                    for (int[] d : DIRS) {
                        HexTile n = hexes.get(HexMath.key(tile.q + d[0], tile.r + d[1]));
                        if (n != null && n.terrain == TerrainType.ROCK && rockLevels.getOrDefault(n, 0) >= lvl) {
                            neighborCount++;
                        }
                    }

                    if (neighborCount >= requiredNeighbors) toPromote.add(tile);
                }
            });

            if (!toPromote.isEmpty()) {
                changed = true;
                currentLevel++;

                final int nextLvl = currentLevel;
                toPromote.parallelStream().forEach(t -> rockLevels.put(t, nextLvl));
            }
        }

        rockLevels.entrySet().parallelStream().forEach(entry -> {
            entry.getKey().customZ = 20 + ((entry.getValue() - 1) * 10);
        });

        Set<HexTile> oceanTiles = ConcurrentHashMap.newKeySet();
        Queue<HexTile> oQueue = new LinkedList<>();
        HexTile oceanOrigin = hexes.get(HexMath.key(0, 0));

        if (oceanOrigin != null && oceanOrigin.terrain == TerrainType.RIVER) {
            oQueue.add(oceanOrigin); oceanTiles.add(oceanOrigin);
            while (!oQueue.isEmpty()) {
                HexTile curr = oQueue.poll();
                for (int[] d : DIRS) {
                    HexTile n = hexes.get(HexMath.key(curr.q + d[0], curr.r + d[1]));
                    if (n != null && n.terrain == TerrainType.RIVER && !oceanTiles.contains(n)) {
                        oceanTiles.add(n); oQueue.add(n);
                    }
                }
            }
        }

        List<HexTile> shoreLaunchingNodes = Collections.synchronizedList(new ArrayList<>());
        hexes.values().parallelStream().forEach(t -> {
            if (t.terrain == TerrainType.GRASS) {
                for (int[] d : DIRS) {
                    HexTile n = hexes.get(HexMath.key(t.q + d[0], t.r + d[1]));
                    if (n != null && n.terrain == TerrainType.RIVER && oceanTiles.contains(n)) {
                        shoreLaunchingNodes.add(t); break;
                    }
                }
            }
        });

        int transContinentalRiverCount = 2;
        Set<HexTile> masterRiverTiles = ConcurrentHashMap.newKeySet();
        Set<HexTile> masterBridgesSet = ConcurrentHashMap.newKeySet();
        Set<HexTile> globalBlockedSet = ConcurrentHashMap.newKeySet();

        for (int i = 0; i < transContinentalRiverCount; i++) {
            if (shoreLaunchingNodes.isEmpty()) break;
            HexTile startNode = shoreLaunchingNodes.remove(rand.nextInt(shoreLaunchingNodes.size()));
            Point pixelPos = CoordinateConverter.hexToPixel(startNode.q, startNode.r);

            double baseAngle = Math.atan2(centerY - pixelPos.y, centerX - pixelPos.x);
            baseAngle += (rand.nextDouble() - 0.5) * 0.3;

            int[] forkCounter = new int[]{0};
            Set<HexTile> currentSystemTiles = new HashSet<>();
            Map<HexTile, Integer> centerLineSteps = new HashMap<>();

            traceContinuousRiver(pixelPos.x, pixelPos.y, baseAngle, oceanTiles, currentSystemTiles, globalBlockedSet, masterBridgesSet, rand, 0, forkCounter, scaleF, centerLineSteps);

            masterRiverTiles.addAll(currentSystemTiles);
            globalBlockedSet.addAll(currentSystemTiles);
        }

        masterRiverTiles.removeAll(masterBridgesSet);

        masterBridgesSet.parallelStream().forEach(bt -> {
            if (bt.terrain == TerrainType.ROCK) {
                bt.terrain = TerrainType.GRASS;
                bt.customZ = -1;
            }
        });

        masterRiverTiles.parallelStream().forEach(rt -> {
            rt.terrain = TerrainType.RIVER;
            rt.customZ = -1;
        });

        List<HexTile> initialShores = Collections.synchronizedList(new ArrayList<>());
        hexes.values().parallelStream().forEach(t -> {
            if (t.terrain == TerrainType.GRASS || t.terrain == TerrainType.FOREST) {
                boolean touchesAnyWater = false;
                for (int[] d : DIRS) {
                    HexTile n = hexes.get(HexMath.key(t.q + d[0], t.r + d[1]));
                    if (n != null && n.terrain == TerrainType.RIVER) {
                        touchesAnyWater = true; break;
                    }
                }
                if (touchesAnyWater) initialShores.add(t);
            }
        });

        Map<HexTile, Integer> remainingSandDepth = new ConcurrentHashMap<>();
        Queue<HexTile> bQueue = new LinkedList<>();

        for (HexTile shore : initialShores) {
            boolean touchesOcean = false;
            for (int[] d : DIRS) {
                HexTile n = hexes.get(HexMath.key(shore.q + d[0], shore.r + d[1]));
                if (n != null && n.terrain == TerrainType.RIVER && oceanTiles.contains(n)) {
                    touchesOcean = true; break;
                }
            }

            int targetThickness;
            if (masterBridgesSet.contains(shore)) {
                targetThickness = 1 + rand.nextInt(3);
            } else {
                targetThickness = touchesOcean ? (1 + rand.nextInt(5)) : rand.nextInt(4);
            }

            if (targetThickness > 0) {
                if (!remainingSandDepth.containsKey(shore) || targetThickness > remainingSandDepth.get(shore)) {
                    remainingSandDepth.put(shore, targetThickness);
                    bQueue.add(shore);
                }
            }
        }

        while (!bQueue.isEmpty()) {
            HexTile curr = bQueue.poll();
            int currentAllowance = remainingSandDepth.get(curr);

            if (currentAllowance <= 1) continue;

            for (int[] d : DIRS) {
                HexTile n = hexes.get(HexMath.key(curr.q + d[0], curr.r + d[1]));
                if (n != null && (n.terrain == TerrainType.GRASS || n.terrain == TerrainType.FOREST)) {
                    int nextAllowance = currentAllowance - 1;

                    if (nextAllowance == 1 && rand.nextDouble() < 0.45) {
                        nextAllowance = 0;
                    }

                    if (nextAllowance > 0) {
                        if (!remainingSandDepth.containsKey(n) || nextAllowance > remainingSandDepth.get(n)) {
                            remainingSandDepth.put(n, nextAllowance);
                            bQueue.add(n);
                        }
                    }
                }
            }
        }

        remainingSandDepth.keySet().parallelStream().forEach(t -> {
            t.terrain = TerrainType.SAND;
            t.customZ = -1;
        });

        pruneClusters(TerrainType.SAND, 3, TerrainType.GRASS);

        int minQ = Integer.MAX_VALUE;
        int maxQ = Integer.MIN_VALUE;
        int minH = Integer.MAX_VALUE;
        int maxH = Integer.MIN_VALUE;

        for (HexTile tile : hexes.values()) {
            if (tile.terrain != TerrainType.RIVER || !oceanTiles.contains(tile)) {
                int h = tile.r + (tile.q >> 1);
                if (tile.q < minQ) minQ = tile.q;
                if (tile.q > maxQ) maxQ = tile.q;
                if (h < minH) minH = h;
                if (h > maxH) maxH = h;
            }
        }

        int startQ = minQ - 10;
        int endQ = maxQ + 10;
        int startH = minH - 10;
        int endH = maxH + 14;

        if (startQ % 2 != 0) {
            startQ--;
        }

        Map<String, HexTile> prunedHexes = new ConcurrentHashMap<>();
        int newCols = (endQ - startQ) + 1;
        int newRows = (endH - startH) + 1;

        for (int nq = 0; nq < newCols; nq++) {
            for (int nh = 0; nh < newRows; nh++) {
                int oldQ = startQ + nq;
                int oldH = startH + nh;
                int oldR = oldH - (oldQ >> 1);

                int newQ = nq;
                int newR = nh - (nq >> 1);

                HexTile oldTile = hexes.get(HexMath.key(oldQ, oldR));
                HexTile newTile = new HexTile(newQ, newR);

                if (oldTile != null) {
                    newTile.terrain = oldTile.terrain;
                    newTile.customZ = oldTile.customZ;
                    newTile.isSparseForest = oldTile.isSparseForest;
                } else {
                    newTile.terrain = TerrainType.RIVER;
                    newTile.customZ = -1;
                }

                prunedHexes.put(HexMath.key(newQ, newR), newTile);
            }
        }

        hexes.clear();
        hexes.putAll(prunedHexes);

        CoordinateConverter.MAP_COLS = newCols;
        CoordinateConverter.MAP_ROWS = newRows;

        Queue<HexTile> distQueue = new LinkedList<>();
        for (HexTile t : hexes.values()) {
            if (t.terrain != TerrainType.ROCK) {
                rockDistToGrass.put(t, 0);
                distQueue.add(t);
            }
        }

        while (!distQueue.isEmpty()) {
            HexTile curr = distQueue.poll();
            int currentDist = rockDistToGrass.get(curr);

            for (int[] d : DIRS) {
                HexTile n = hexes.get(HexMath.key(curr.q + d[0], curr.r + d[1]));
                if (n != null && n.terrain == TerrainType.ROCK && !rockDistToGrass.containsKey(n)) {
                    rockDistToGrass.put(n, currentDist + 1);
                    distQueue.add(n);
                }
            }
        }

        calculateShadows();

        long totalX = 0, totalY = 0;
        int landCount = 0;
        for (HexTile t : hexes.values()) {
            if (t.terrain != TerrainType.RIVER) {
                Point p = CoordinateConverter.hexToPixel(t.q, t.r);
                totalX += p.x;
                totalY += p.y;
                landCount++;
            }
        }
        if (landCount > 0) {
            landCenterPX = (int)(totalX / landCount);
            landCenterPY = (int)(totalY / landCount);
        } else {
            landCenterPX = CoordinateConverter.getMapWidth() / 2;
            landCenterPY = CoordinateConverter.getMapHeight() / 2;
        }
    }

    public static void calculateShadows() {
        // FIX 1: Capture snapshot of global timeline immediately to stop internal mismatches mid-pass
        final float stableTimeOfDay = timeOfDay;

        hexes.values().parallelStream().forEach(t -> {
            t.incomingShadows.clear();
        });

        double sunVecX = -1.3 + (stableTimeOfDay * 2.6);
        double sunVecY = -0.9 + (stableTimeOfDay * 1.8);

        hexes.values().parallelStream().forEach(caster -> {
            int cz = caster.getZ();
            if (cz > 0 && (caster.terrain == TerrainType.ROCK || caster.terrain == TerrainType.FOREST)) {

                int dist = rockDistToGrass.getOrDefault(caster, 1);
                double multiplier = dist * 1.5;

                int searchRadius = Math.max(2, (int) Math.ceil(((double) cz / CoordinateConverter.HEX_SIZE) * multiplier) + 4);
                searchRadius = Math.min(45, searchRadius);

                Point cp = CoordinateConverter.hexToPixel(caster.q, caster.r);

                for (int dq = -searchRadius; dq <= searchRadius; dq++) {
                    for (int dr = -searchRadius; dr <= searchRadius; dr++) {
                        HexTile receiver = hexes.get(HexMath.key(caster.q + dq, caster.r + dr));

                        if (receiver != null && receiver.getZ() < cz && receiver.terrain != TerrainType.ROCK) {
                            Point rp = CoordinateConverter.hexToPixel(receiver.q, receiver.r);

                            if (sunVecY > 0 && rp.y < cp.y - 20) continue;
                            if (sunVecY < 0 && rp.y > cp.y + 20) continue;
                            if (sunVecX > 0 && rp.x < cp.x - 20) continue;
                            if (sunVecX < 0 && rp.x > cp.x + 20) continue;

                            int deltaZ = cz - receiver.getZ();
                            int scaledDeltaZ = (int) (deltaZ * multiplier);

                            Polygon shadowPoly = generateShadowFootprintPolygon(cp.x, cp.y, cz, scaledDeltaZ, sunVecX, sunVecY);
                            Rectangle shadowBounds = shadowPoly.getBounds();
                            Rectangle recApprox = new Rectangle(
                                    rp.x - 35, rp.y - receiver.getZ() - 35,
                                    70, receiver.getZ() + 70);

                            if (shadowBounds.intersects(recApprox)) {
                                synchronized (receiver.incomingShadows) {
                                    receiver.incomingShadows.add(new HexTile.ShadowRecord(cp.x, cp.y, scaledDeltaZ, cz));
                                }
                            }
                        }
                    }
                }
            }
        });

        // FIX 2: Pass immutable timeline snapshot directly down to geometry compilers
        rebuildShadows(stableTimeOfDay);
    }

    private static void traceContinuousRiver(double startX, double startY, double baseAngle, Set<HexTile> oceanTiles, Set<HexTile> currentSystemTiles, Set<HexTile> blockedTiles, Set<HexTile> masterBridgesSet, Random rand, int branchDepth, int[] forkCounter, double scaleF, Map<HexTile, Integer> centerLineSteps) {
        double curX = startX;
        double curY = startY;
        double angle = baseAngle;
        int step = 0;

        int maxSteps = (int)(Math.min(CoordinateConverter.MAP_COLS, CoordinateConverter.MAP_ROWS) * 0.75);
        Perlin2D riverWobble = new Perlin2D(rand.nextLong());

        int stepsSinceLastBridge = 0;
        int activeBridgeSteps = 0;
        int currentBridgeThickness = 0;

        boolean justFinishedBridge = false;
        int postBridgeCount = 0;

        while (step < maxSteps) {
            double wobble = 0.8 * Math.sin(step * 0.04) + riverWobble.noise(curX * 0.004 * scaleF, curY * 0.004 * scaleF) * 1.2;
            angle = baseAngle + wobble;

            curX += Math.cos(angle) * 38.0;
            curY += Math.sin(angle) * 38.0;

            Point hCoord = CoordinateConverter.pixelToHex((int)curX, (int)curY);
            HexTile tile = hexes.get(HexMath.key(hCoord.x, hCoord.y));

            if (tile == null) break;
            if (blockedTiles.contains(tile)) break;

            if (centerLineSteps.containsKey(tile)) {
                if (Math.abs(centerLineSteps.get(tile) - step) > 20) break;
            }

            centerLineSteps.put(tile, step);

            if (activeBridgeSteps > 0) {
                paintBridgeBrush(tile, currentBridgeThickness, masterBridgesSet);
                activeBridgeSteps--;
                if (activeBridgeSteps == 0) {
                    stepsSinceLastBridge = 0;
                    justFinishedBridge = true;
                    postBridgeCount = 0;
                }
            } else {
                stepsSinceLastBridge++;

                int activeWidth = 5 - (int)(((double)step / maxSteps) * 4.0);
                int bridgeInterval = maxSteps / 5;

                boolean bridgeComingSoon = (step > 30 && step < maxSteps - 35 && stepsSinceLastBridge > bridgeInterval - 8);

                if (justFinishedBridge) {
                    postBridgeCount++;
                    if (postBridgeCount > 8) justFinishedBridge = false;
                }

                if (bridgeComingSoon || justFinishedBridge) {
                    activeWidth = 1;
                }

                if (step > 30 && step < maxSteps - 35 && stepsSinceLastBridge > bridgeInterval) {
                    currentBridgeThickness = 5 + rand.nextInt(5);
                    activeBridgeSteps = currentBridgeThickness;
                    paintBridgeBrush(tile, currentBridgeThickness, masterBridgesSet);
                    activeBridgeSteps--;
                } else {
                    activeWidth = Math.max(1, Math.min(5, activeWidth));
                    paintRiverBrush(tile, activeWidth, currentSystemTiles);
                }
            }

            if (branchDepth < 2 && step > 80 && step < maxSteps - 60 && forkCounter[0] < 2 && rand.nextDouble() < 0.004) {
                forkCounter[0]++;
                double forkAngle = baseAngle + (rand.nextBoolean() ? 0.42 : -0.42);

                Map<HexTile, Integer> forkCenterLines = new HashMap<>(centerLineSteps);
                traceContinuousRiver(curX, curY, forkAngle, oceanTiles, currentSystemTiles, blockedTiles, masterBridgesSet, rand, branchDepth + 1, forkCounter, scaleF, forkCenterLines);
            }

            if (step > 60 && tile.terrain == TerrainType.RIVER && oceanTiles.contains(tile)) break;
            step++;
        }
    }

    private static void paintBridgeBrush(HexTile center, int thickness, Set<HexTile> masterBridgesSet) {
        if (center == null) return;
        int radius = (thickness - 1) / 2;

        Queue<HexTile> queue = new LinkedList<>();
        Set<HexTile> visited = new HashSet<>();

        queue.add(center);
        visited.add(center);
        masterBridgesSet.add(center);

        int currentRadius = 1;
        while (!queue.isEmpty() && currentRadius <= radius) {
            int layerSize = queue.size();
            for (int i = 0; i < layerSize; i++) {
                HexTile cell = queue.poll();
                for (int[] d : DIRS) {
                    HexTile n = hexes.get(HexMath.key(cell.q + d[0], cell.r + d[1]));
                    if (n != null && !visited.contains(n)) {
                        visited.add(n); masterBridgesSet.add(n); queue.add(n);
                    }
                }
            }
            currentRadius++;
        }
    }

    private static void paintRiverBrush(HexTile center, int width, Set<HexTile> currentSystemTiles) {
        if (center == null) return;
        currentSystemTiles.add(center);

        if (width > 1) {
            for (int[] d : DIRS) {
                HexTile n = hexes.get(HexMath.key(center.q + d[0], center.r + d[1]));
                if (n != null) currentSystemTiles.add(n);
            }
        }
        if (width > 3) {
            for (int[] d : DIRS) {
                HexTile firstRing = hexes.get(HexMath.key(center.q + d[0], center.r + d[1]));
                if (firstRing != null) {
                    for (int[] d2 : DIRS) {
                        HexTile n2 = hexes.get(HexMath.key(firstRing.q + d2[0], firstRing.r + d2[1]));
                        if (n2 != null) currentSystemTiles.add(n2);
                    }
                }
            }
        }
    }

    private static void traceForestPath(double startX, double startY, double baseAngle, Random rand, double scaleF) {
        double curX = startX;
        double curY = startY;
        double angle = baseAngle;
        int step = 0;

        int maxSteps = 30 + rand.nextInt(50);

        Perlin2D pathWobble = new Perlin2D(rand.nextLong());
        Perlin2D thicknessNoise = new Perlin2D(rand.nextLong());

        while (step < maxSteps) {
            double wobble = pathWobble.noise(curX * 0.015 * scaleF, curY * 0.015 * scaleF) * 2.0;
            angle = baseAngle + wobble;

            curX += Math.cos(angle) * 35.0;
            curY += Math.sin(angle) * 35.0;

            Point hCoord = CoordinateConverter.pixelToHex((int)curX, (int)curY);
            HexTile tile = hexes.get(HexMath.key(hCoord.x, hCoord.y));

            if (tile == null) break;

            double tNoise = thicknessNoise.noise(curX * 0.02 * scaleF, curY * 0.02 * scaleF);
            int currentWidth = 1 + (int) Math.round((tNoise + 1.0) * 1.5);
            currentWidth = Math.max(1, Math.min(3, currentWidth));

            paintForestPathBrush(tile, currentWidth, rand);
            step++;
        }
    }

    private static void paintForestPathBrush(HexTile center, int width, Random rand) {
        if (center == null) return;

        if (center.terrain == TerrainType.FOREST) {
            center.terrain = TerrainType.GRASS;
            center.isSparseForest = false;
        }

        if (width >= 2) {
            for (int[] d : DIRS) {
                HexTile n = hexes.get(HexMath.key(center.q + d[0], center.r + d[1]));
                if (n != null && n.terrain == TerrainType.FOREST) {
                    if (rand.nextDouble() < 0.60) {
                        n.terrain = TerrainType.GRASS;
                    } else {
                        n.isSparseForest = true;
                    }
                }
            }
        }

        if (width >= 3) {
            for (int[] d : DIRS) {
                HexTile firstRing = hexes.get(HexMath.key(center.q + d[0], center.r + d[1]));
                if (firstRing != null) {
                    for (int[] d2 : DIRS) {
                        HexTile n2 = hexes.get(HexMath.key(firstRing.q + d2[0], firstRing.r + d2[1]));
                        if (n2 != null && n2.terrain == TerrainType.FOREST) {
                            if (rand.nextDouble() < 0.20) {
                                n2.terrain = TerrainType.GRASS;
                            } else if (rand.nextDouble() < 0.70) {
                                n2.isSparseForest = true;
                            }
                        }
                    }
                }
            }
        }
    }

    private static void pruneClusters(TerrainType targetType, int minSize, TerrainType replacementType) {
        Set<HexTile> visited = new HashSet<>();
        List<HexTile> toReplace = Collections.synchronizedList(new ArrayList<>());

        hexes.values().parallelStream().forEach(tile -> {
            if (tile.terrain == targetType && !visited.contains(tile)) {
                List<HexTile> cluster = new ArrayList<>();
                Queue<HexTile> queue = new LinkedList<>();

                synchronized (visited) {
                    if (visited.contains(tile)) return;
                    visited.add(tile);
                }
                queue.add(tile);

                while (!queue.isEmpty()) {
                    HexTile curr = queue.poll();
                    cluster.add(curr);
                    for (int[] d : DIRS) {
                        HexTile n = hexes.get(HexMath.key(curr.q + d[0], curr.r + d[1]));
                        if (n != null && n.terrain == targetType) {
                            synchronized (visited) {
                                if (!visited.contains(n)) {
                                    visited.add(n); queue.add(n);
                                }
                            }
                        }
                    }
                }
                if (cluster.size() < minSize) toReplace.addAll(cluster);
            }
        });

        toReplace.parallelStream().forEach(t -> {
            t.terrain = replacementType;
            t.customZ = -1;
        });
    }

    public static void rebuildShadows(float stableTimeOfDay) {
        hexes.values().parallelStream().forEach(t -> {
            if (!t.incomingShadows.isEmpty()) {
                Area union = new Area();
                synchronized (t.incomingShadows) {
                    // FIX 3: Rebuild utilizes stableTimeOfDay value directly to avoid tearing artifacts
                    double sunVecX = -1.3 + (stableTimeOfDay * 2.6);
                    double sunVecY = -0.9 + (stableTimeOfDay * 1.8);
                    for (HexTile.ShadowRecord shadow : t.incomingShadows) {
                        union.add(new Area(generateShadowFootprintPolygon(
                                shadow.cx, shadow.cy, shadow.casterZ, shadow.z, sunVecX, sunVecY)));
                    }
                }
                Point p = CoordinateConverter.hexToPixel(t.q, t.r);
                Area tileArea = new Area(get3DHexPolygon(p.x, p.y, t.getZ()));
                union.intersect(tileArea);
                t.compiledShadow = union;
            } else {
                t.compiledShadow = null;
            }
        });
    }

    private static Polygon get3DHexPolygon(int cx, int cy, int z) {
        int baseSize = CoordinateConverter.HEX_SIZE;
        int topSize = baseSize;

        if (z > 25) {
            int tiers = (z - 25) / 15;
            topSize = Math.max(12, topSize - (tiers * 5));
        }

        int[] tx = new int[6], ty = new int[6], bx = new int[6], by = new int[6];
        for (int i = 0; i < 6; i++) {
            double a = Math.PI / 3 * i;
            tx[i] = cx + (int)(topSize * Math.cos(a));
            ty[i] = cy + (int)(topSize * Math.sin(a)) - z;
            bx[i] = cx + (int)(baseSize * Math.cos(a));
            by[i] = cy + (int)(baseSize * Math.sin(a));
        }

        Polygon p = new Polygon();
        if (z > 0) {
            int[] sqx = { tx[0], tx[5], tx[4], tx[3], bx[3], bx[2], bx[1], bx[0] };
            int[] sqy = { ty[0], ty[5], ty[4], ty[3], by[3], by[2], by[1], by[0] };
            for (int i = 0; i < 8; i++) p.addPoint(sqx[i], sqy[i]);
        } else {
            for (int i = 0; i < 6; i++) p.addPoint(tx[i], ty[i]);
        }
        return p;
    }

    private static Polygon generateShadowFootprintPolygon(int cx, int cy, int casterZ, int deltaZ, double sunVecX, double sunVecY) {
        int shadowOffsetX = (int)(deltaZ * sunVecX);
        int shadowOffsetY = (int)(deltaZ * sunVecY);

        int baseSize = CoordinateConverter.HEX_SIZE;
        int projectionSize = baseSize;

        Point[] cloud = new Point[12];

        for (int i = 0; i < 6; i++) {
            double a = Math.PI / 3 * i;
            cloud[i] = new Point(
                    cx + (int)(baseSize * Math.cos(a)),
                    cy + (int)(baseSize * Math.sin(a))
            );
            cloud[i+6] = new Point(
                    cx + (int)(projectionSize * Math.cos(a)) + shadowOffsetX,
                    cy + (int)(projectionSize * Math.sin(a)) + shadowOffsetY
            );
        }

        return buildConvexHull(cloud);
    }

    private static Polygon buildConvexHull(Point[] points) {
        int n = points.length;
        int l = 0;
        for (int i = 1; i < n; i++) {
            if (points[i].x < points[l].x) l = i;
        }

        List<Point> hull = new ArrayList<>();
        int p = l, q;
        do {
            hull.add(points[p]);
            q = (p + 1) % n;
            for (int i = 0; i < n; i++) {
                int val = (points[i].y - points[p].y) * (points[q].x - points[i].x) -
                        (points[i].x - points[p].x) * (points[q].y - points[i].y);
                if (val < 0) {
                    q = i;
                }
            }
            p = q;
        } while (p != l);

        Polygon poly = new Polygon();
        for (Point pt : hull) poly.addPoint(pt.x, pt.y);
        return poly;
    }

    private static class Perlin2D {
        private final int[] p = new int[512];
        public Perlin2D(long seed) {
            Random r = new Random(seed);
            List<Integer> list = new ArrayList<>();
            for (int i = 0; i < 256; i++) list.add(i);
            Collections.shuffle(list, r);
            for (int i = 0; i < 256; i++) {
                p[i] = list.get(i);
                p[256 + i] = list.get(i);
            }
        }
        public double noise(double x, double y) {
            int X = (int) Math.floor(x) & 255;
            int Y = (int) Math.floor(y) & 255;
            x -= Math.floor(x); y -= Math.floor(y);
            double u = fade(x); double v = fade(y);
            int A = p[X] + Y; int B = p[X + 1] + Y;
            return lerp(v, lerp(u, grad(p[A], x, y), grad(p[B], x - 1, y)),
                    lerp(u, grad(p[A + 1], x, y - 1), grad(p[B + 1], x - 1, y - 1)));
        }
        private double fade(double t) { return t * t * t * (t * (t * 6 - 15) + 10); }
        private double lerp(double t, double a, double b) { return a + t * (b - a); }
        private double grad(int hash, double x, double y) {
            int h = hash & 7;
            double u = h < 4 ? x : y; double v = h < 4 ? y : x;
            return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? 2.0 * v : -2.0 * v);
        }
    }

    public static void clearGridOccupancy() { gridOccupied.clear(); }
    public static void markHex(int q, int r, Unit u) {
        String key = HexMath.key(q, r);
        if (u == null) gridOccupied.remove(key);
        else gridOccupied.put(key, u);
    }
    public static Unit getUnitAt(int q, int r) { return gridOccupied.get(HexMath.key(q, r)); }
    public static boolean isHexOccupied(int q, int r) { return getUnitAt(q, r) != null; }
    public static boolean isHexOccupiedByOther(int q, int r, Unit self) {
        Unit u = getUnitAt(q, r); return u != null && u != self;
    }
    public static boolean isOutOfBounds(int q, int r) { return !hexes.containsKey(HexMath.key(q, r)); }
    public static boolean isBlockedForPath(int q, int r, int sQ, int sR, int tQ, int tR) {
        if (isOutOfBounds(q, r)) return true;
        HexTile tile = hexes.get(HexMath.key(q, r));
        if (tile != null && (tile.terrain == TerrainType.RIVER || tile.terrain == TerrainType.ROCK || tile.terrain == TerrainType.FOREST)) return true;
        if ((q == sQ && r == sR) || (q == tQ && r == tR)) return false;
        Unit u = getUnitAt(q, r); return u != null && u.currentOrder == null;
    }
}