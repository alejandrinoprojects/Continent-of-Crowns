import java.awt.geom.Area;
import java.util.ArrayList;
import java.util.List;

public class HexTile {
    public final int q, r;
    public TerrainType terrain = TerrainType.GRASS;
    public int customZ = -1;

    // NEW: Tells the renderer to draw fewer trees on this specific hex
    public boolean isSparseForest = false;

    // Replace your existing ShadowRecord inside HexTile.java with this:
    public static class ShadowRecord {
        public int cx;
        public int cy;
        public int z;         // This is the deltaZ (height difference used for shadow length)
        public int casterZ;   // This is the absolute height of the mountain (used for shadow width)

        public ShadowRecord(int cx, int cy, int z, int casterZ) {
            this.cx = cx;
            this.cy = cy;
            this.z = z;
            this.casterZ = casterZ;
        }
    }

    public final List<ShadowRecord> incomingShadows = new ArrayList<>();
    public Area compiledShadow = null;

    public HexTile(int q, int r) {
        this.q = q;
        this.r = r;
    }

    public int getZ() {
        return customZ >= 0 ? customZ : terrain.zHeight;
    }
}