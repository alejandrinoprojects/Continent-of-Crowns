import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Transparency;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class GameRenderer {

    private static final int NUM_FRAMES     = 8;
    private static final int NUM_VARIATIONS = 25;
    private static final int MAX_CACHE_SIZE = 800;

    private static final GraphicsConfiguration GFX_CONFIG =
            GraphicsEnvironment.getLocalGraphicsEnvironment()
                    .getDefaultScreenDevice()
                    .getDefaultConfiguration();

    // OPTIMIZATION: ThreadLocal reuse scrappads to prevent array allocations inside loops
    private static final ThreadLocal<int[]> SCRATCH_X6 = ThreadLocal.withInitial(() -> new int[6]);
    private static final ThreadLocal<int[]> SCRATCH_Y6 = ThreadLocal.withInitial(() -> new int[6]);
    private static final ThreadLocal<int[]> SCRATCH_X8 = ThreadLocal.withInitial(() -> new int[8]);
    private static final ThreadLocal<int[]> SCRATCH_Y8 = ThreadLocal.withInitial(() -> new int[8]);

    // OPTIMIZATION: Static color definitions to avoid object instantiation on the rendering thread
    private static final Color COLOR_UNIT_SHADOW   = new Color(0, 0, 0, 80);
    private static final Color COLOR_UNIT_HOLDING  = new Color(255, 140, 0);
    private static final Color COLOR_UNIT_SELECTED = Color.YELLOW;
    private static final Color COLOR_UNIT_DEFAULT  = Color.CYAN;
    private static final Color COLOR_TEXT_WHITE    = Color.WHITE;
    private static final Color COLOR_SELECTION_BG  = new Color(0, 255, 0, 80);
    private static final Color COLOR_SELECTION_BRD = Color.GREEN;

    // --- DAY/NIGHT DIRECTIONAL SLOPE TRACKERS ---
    private float lastTimeOfDay = -1f;
    private boolean isNight = false;

    // --- LAZY-LOADED TOWNHALL IMAGE CACHE ---
    private BufferedImage cachedTownHallDay   = null;
    private BufferedImage cachedTownHallNight = null;
    private Point lastTownHallHex            = null;
    private int lastCachedHexSize            = -1;
    private int cachedImgCX                  = 0;
    private int cachedImgCY                  = 0;

    private final Map<Long, BufferedImage> spriteCache =
            new LinkedHashMap<Long, BufferedImage>(MAX_CACHE_SIZE + 1, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<Long, BufferedImage> eldest) {
                    if (size() > MAX_CACHE_SIZE) {
                        if (eldest.getValue() != null) eldest.getValue().flush();
                        return true;
                    }
                    return false;
                }
            };

    public void clearSpriteCache() {
        synchronized (spriteCache) {
            for (BufferedImage img : spriteCache.values()) {
                if (img != null) img.flush();
            }
            spriteCache.clear();
        }
        // Invalidate the pre-baked town hall assets as well
        invalidateTownHallCache();
    }

    private void invalidateTownHallCache() {
        if (cachedTownHallDay != null) { cachedTownHallDay.flush(); cachedTownHallDay = null; }
        if (cachedTownHallNight != null) { cachedTownHallNight.flush(); cachedTownHallNight = null; }
        lastTownHallHex = null;
        lastCachedHexSize = -1;
    }

    public void renderDynamicEntities(Graphics g, List<Unit> units, SelectionManager selection) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawUnits(g2d, units);
        drawSelectionBox(g2d, selection);
    }

    public void drawSingleTile(Graphics2D g2d, HexTile tile, Point p, int globalFrame) {
        int z         = tile.getZ();
        int variation = Math.abs(tile.q * 31 + tile.r * 17) % NUM_VARIATIONS;

        int coordinateNoise = Math.abs((tile.q * 127 + tile.r * 313) ^ (tile.q * tile.r));
        int frameIdx = (globalFrame + (coordinateNoise % NUM_FRAMES)) % NUM_FRAMES;

        long cacheKey = ((long) tile.terrain.ordinal() << 48)
                | (((long) z & 0xFFFF) << 32)
                | (((long) variation & 0xFFFF) << 16)
                | ((long) frameIdx & 0xFFFF);

        if (tile.isSparseForest) cacheKey |= (1L << 60);

        BufferedImage sprite;
        synchronized (spriteCache) {
            sprite = spriteCache.get(cacheKey);
        }

        if (sprite == null) {
            sprite = buildSprite(tile.terrain, z, variation, frameIdx, tile.isSparseForest);
            synchronized (spriteCache) {
                BufferedImage existing = spriteCache.get(cacheKey);
                if (existing != null) {
                    sprite.flush();
                    sprite = existing;
                } else {
                    spriteCache.put(cacheKey, sprite);
                }
            }
        }

        int spriteCX = CoordinateConverter.HEX_SIZE + 40;
        int spriteCY = sprite.getHeight() - CoordinateConverter.HEX_SIZE - 40;
        g2d.drawImage(sprite, p.x - spriteCX, p.y - spriteCY, null);

        if (tile.compiledShadow != null) {
            Composite oldComp = g2d.getComposite();
            g2d.setColor(Color.BLACK);
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.35f));
            g2d.fill(tile.compiledShadow);
            g2d.setComposite(oldComp);
        }
    }

    private BufferedImage buildSprite(TerrainType terrain, int z, int variation,
                                      int frameIdx, boolean isSparseForest) {
        int hexSize = CoordinateConverter.HEX_SIZE;
        int padding = 40;
        int width   = hexSize * 2 + (padding * 2);
        int height  = hexSize * 2 + Math.max(0, z) + (padding * 2);

        BufferedImage img = GFX_CONFIG.createCompatibleImage(width, height, Transparency.TRANSLUCENT);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int cx = width  / 2;
        int cy = height - hexSize - padding;

        Color topColor, sideColor;
        switch (terrain) {
            case FOREST: topColor = new Color( 85, 125,  35); sideColor = topColor; break;
            case ROCK:   topColor = new Color( 65,  65,  65); sideColor = topColor; break;
            case RIVER:  topColor = new Color( 65, 105, 225); sideColor = topColor; break;
            case SAND:   topColor = new Color(237, 201, 175); sideColor = topColor; break;
            case GRASS:
            default:     topColor = new Color(107, 142,  35); sideColor = topColor; break;
        }

        int[] tx = SCRATCH_X6.get();
        int[] ty = SCRATCH_Y6.get();
        int[] bx = new int[6];
        int[] by = new int[6];
        for (int i = 0; i < 6; i++) {
            double a  = Math.PI / 3 * i;
            int dx    = (int)(hexSize * Math.cos(a));
            int dy    = (int)(hexSize * Math.sin(a));
            tx[i] = cx + dx; ty[i] = cy + dy - Math.max(0, z);
            bx[i] = cx + dx; by[i] = cy + dy;
        }

        if (z > 0) {
            g.setColor(sideColor);
            int[] sqx = SCRATCH_X8.get();
            int[] sqy = SCRATCH_Y8.get();
            sqx[0] = tx[0]; sqx[1] = tx[1]; sqx[2] = tx[2]; sqx[3] = tx[3];
            sqx[4] = bx[3]; sqx[5] = bx[2]; sqx[6] = bx[1]; sqx[7] = bx[0];
            sqy[0] = ty[0]; sqy[1] = ty[1]; sqy[2] = ty[2]; sqy[3] = ty[3];
            sqy[4] = by[3]; sqy[5] = by[2]; sqy[6] = by[1]; sqy[7] = by[0];
            g.fillPolygon(sqx, sqy, 8);
        }

        g.setColor(topColor);
        g.fillPolygon(tx, ty, 6);

        Shape oldClip = g.getClip();
        Random seedRand = new Random(variation * 1000L);

        switch (terrain) {
            case GRASS: {
                int grassCount = 15 + seedRand.nextInt(8);
                int swayOffset = (frameIdx % 4 < 2) ? 1 : -1;
                int[] gxScratch = new int[3];
                int[] gyScratch = new int[3];
                for (int i = 0; i < grassCount; i++) {
                    int gR = 115 + seedRand.nextInt(20);
                    int gG = 155 + seedRand.nextInt(20);
                    int gB =  35 + seedRand.nextInt(20);
                    g.setColor(new Color(gR, gG, gB));
                    int gx = cx + seedRand.nextInt(hexSize * 2) - hexSize;
                    int gy = (cy - Math.max(0, z)) + seedRand.nextInt(hexSize * 2) - hexSize;
                    gxScratch[0] = gx + swayOffset; gxScratch[1] = gx - 1; gxScratch[2] = gx + 1;
                    gyScratch[0] = gy - 4;          gyScratch[1] = gy;     gyScratch[2] = gy;
                    g.fillPolygon(gxScratch, gyScratch, 3);
                }
                if (seedRand.nextDouble() < 0.25) {
                    g.setColor(new Color(255, 255, 255, 30));
                    int windX = cx - hexSize + (int)(((float)frameIdx / NUM_FRAMES) * (hexSize * 2.5));
                    int windY = (cy - Math.max(0, z)) + seedRand.nextInt(hexSize) - (hexSize / 2);
                    g.fillRect(windX,      windY,     12, 2);
                    g.fillRect(windX + 16, windY - 2,  8, 2);
                    g.fillRect(windX + 28, windY - 4,  6, 2);
                }
                break;
            }
            case FOREST: {
                int canopyCount = isSparseForest ? (3 + seedRand.nextInt(5)) : (20 + seedRand.nextInt(15));
                Color[] flatGreens = {
                        new Color( 40,  70, 25),
                        new Color( 55,  90, 30),
                        new Color( 70, 114, 35),
                        new Color( 85, 138, 40)
                };
                g.setColor(topColor);
                g.fillPolygon(tx, ty, 6);

                int    maxRadius    = Math.max(4, (int)(hexSize * 0.45));
                double canopyShiftY = hexSize * 0.10;
                int[]  treeX = new int[6], treeY = new int[6];

                for (int i = 0; i < canopyCount; i++) {
                    double angle = seedRand.nextDouble() * Math.PI * 2;
                    double distance = Math.sqrt(seedRand.nextDouble()) * (hexSize * 0.75);
                    double baseX    = cx + Math.cos(angle) * distance;
                    double baseY    = (cy - Math.max(0, z)) + Math.sin(angle) * distance - canopyShiftY;
                    double offsetX  = 0;
                    if (seedRand.nextDouble() < 0.15) {
                        double swayAmp = 0.4 + (seedRand.nextDouble() * 0.2);
                        double phase   = seedRand.nextDouble() * Math.PI * 2;
                        offsetX = swayAmp * Math.sin((frameIdx * Math.PI / 4) + phase);
                    }
                    int radius = Math.max(3, seedRand.nextInt(maxRadius + 1));
                    for (int n = 0; n < 6; n++) {
                        double a   = Math.PI / 3 * n;
                        treeX[n]   = (int)(baseX + offsetX + radius * Math.cos(a));
                        treeY[n]   = (int)(baseY              + radius * Math.sin(a));
                    }
                    Color baseColor = flatGreens[seedRand.nextInt(flatGreens.length)];
                    int alpha = 178 + seedRand.nextInt(78);
                    g.setColor(new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), alpha));
                    g.fillPolygon(treeX, treeY, 6);
                    g.setColor(new Color(0, 0, 0, 45));
                    g.setStroke(new BasicStroke(1.0f));
                    g.drawPolygon(treeX, treeY, 6);
                }
                break;
            }
            case ROCK: {
                int[] silX = new int[10], silY = new int[10];
                int   silCount;
                if (z > 0) {
                    silX[0] = tx[4]; silX[1] = tx[5]; silX[2] = tx[0]; silX[3] = tx[1]; silX[4] = tx[2]; silX[5] = tx[3];
                    silX[6] = bx[3]; silX[7] = bx[2]; silX[8] = bx[1]; silX[9] = bx[0];
                    silY[0] = ty[4]; silY[1] = ty[5]; silY[2] = ty[0]; silY[3] = ty[1]; silY[4] = ty[2]; silY[5] = ty[3];
                    silY[6] = by[3]; silY[7] = by[2]; silY[8] = by[1]; silY[9] = by[0];
                    silCount = 10;
                } else {
                    System.arraycopy(tx, 0, silX, 0, 6);
                    System.arraycopy(ty, 0, silY, 0, 6);
                    silCount = 6;
                }

                if (z > 0) {
                    Composite oldComposite = g.getComposite();
                    g.setColor(Color.BLACK);
                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.35f));
                    g.fillPolygon(new int[]{ tx[2],tx[3],bx[3],bx[2] }, new int[]{ ty[2],ty[3],by[3],by[2] }, 4);
                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.20f));
                    g.fillPolygon(new int[]{ tx[1],tx[2],bx[2],bx[1] }, new int[]{ ty[1],ty[2],by[2],by[1] }, 4);
                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.15f));
                    g.fillPolygon(new int[]{ tx[0],tx[1],bx[1],bx[0] }, new int[]{ ty[0],ty[1],by[1],by[0] }, 4);
                    g.setComposite(oldComposite);
                }

                g.setColor(topColor);
                g.fillPolygon(tx, ty, 6);

                Composite topComp = g.getComposite();
                g.setColor(Color.WHITE);
                g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.04f));
                g.fillPolygon(tx, ty, 6);
                g.setComposite(topComp);

                g.setClip(new Polygon(silX, silY, silCount));
                int stoneLines = 140 + seedRand.nextInt(50);
                for (int i = 0; i < stoneLines; i++) {
                    int gray = 45 + seedRand.nextInt(35);
                    g.setColor(new Color(gray, gray, gray, 160));
                    int rx  = cx - hexSize * 2 + seedRand.nextInt(hexSize * 4);
                    int ry  = cy - z - hexSize + seedRand.nextInt(z + hexSize * 2 + 20);
                    int dist = Math.abs(rx - cx);
                    int rw  = (dist > hexSize * 0.5) ? (1 + seedRand.nextInt(2)) : (2 + seedRand.nextInt(3));
                    int rh  = 12 + seedRand.nextInt(40);
                    g.fillRect(rx, ry, rw, rh);
                }
                g.setClip(oldClip);

                if (z > 0) {
                    g.setColor(new Color(0, 0, 0, 45));
                    g.drawLine(tx[1], ty[1], bx[1], by[1]);
                    g.drawLine(tx[2], ty[2], bx[2], by[2]);
                    g.drawLine(tx[0], ty[0], tx[1], ty[1]);
                    g.drawLine(tx[1], ty[1], tx[2], ty[2]);
                    g.drawLine(tx[2], ty[2], tx[3], ty[3]);
                }
                break;
            }
            case RIVER: {
                g.setClip(new Polygon(tx, ty, 6));
                g.setColor(new Color(110, 180, 255));
                int animOffset    = (frameIdx % NUM_FRAMES) * 3;
                int particleCount = 15 + seedRand.nextInt(10);
                int[] pX = new int[4], pY = new int[4];
                for (int i = 0; i < particleCount; i++) {
                    int wy = (cy - Math.max(0, z)) - hexSize + seedRand.nextInt(hexSize * 2);
                    int wx = (cx - hexSize) + ((animOffset + (i * 15)) % (hexSize * 2));
                    pX[0] = wx; pX[1] = wx + 4; pX[2] = wx + 8; pX[3] = wx + 4;
                    pY[0] = wy; pY[1] = wy - 1; pY[2] = wy;     pY[3] = wy + 1;
                    g.fillPolygon(pX, pY, 4);
                }
                g.setClip(oldClip);
                break;
            }
            case SAND: {
                g.setColor(new Color(245, 222, 200));
                int sandCount = 10 + seedRand.nextInt(8);
                int[] sX = new int[4], sY = new int[4];
                for (int i = 0; i < sandCount; i++) {
                    int sx = cx + seedRand.nextInt(hexSize * 2) - hexSize;
                    int sy = (cy - Math.max(0, z)) + seedRand.nextInt(hexSize * 2) - hexSize;
                    sX[0] = sx; sX[1] = sx - 2; sX[2] = sx;     sX[3] = sx + 2;
                    sY[0] = sy - 2; sY[1] = sy; sY[2] = sy + 2; sY[3] = sy;
                    g.fillPolygon(sX, sY, 4);
                }
                break;
            }
        }

        g.setStroke(new BasicStroke(1.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        if (z > 0) {
            g.setColor(sideColor);
            g.drawLine(tx[1], ty[1], bx[1], by[1]);
            g.drawLine(tx[2], ty[2], bx[2], by[2]);
            g.drawLine(bx[1], by[1], bx[2], by[2]);
            g.drawLine(bx[2], by[2], bx[3], by[3]);
        }
        g.setColor(topColor);
        g.drawPolygon(tx, ty, 6);
        if (terrain != TerrainType.RIVER) {
            g.setColor(terrain == TerrainType.FOREST ? new Color(20, 50, 15, 180) : new Color(0, 0, 0, 15));
            g.setStroke(new BasicStroke(1.0f));
            g.drawPolygon(tx, ty, 6);
        }

        g.dispose();
        return img;
    }

    private void drawUnits(Graphics g, List<Unit> units) {
        Graphics2D g2d = (Graphics2D) g;
        for (Unit u : units) {
            int sx = (int) u.x;
            int sy = (int) u.y;

            // OPTIMIZATION: Use the Unit's pre-existing axial coordinates directly instead of constructing a new Point() every frame
            HexTile tile = GridManager.hexes.get(HexMath.key(u.q, u.r));
            int terrainZ = (tile != null) ? tile.getZ() : 0;

            if (u.isLeaping && u.leapZ > 0) {
                g2d.setColor(COLOR_UNIT_SHADOW);
                int r = (int)(20 - (u.leapZ * 0.2));
                double sunVecX = -1.3 + (GridManager.timeOfDay * 2.6);
                double sunVecY = -0.9 + (GridManager.timeOfDay * 1.8);
                int shadowX = sx + (int)(u.leapZ * (sunVecX * 0.25));
                int shadowY = sy - terrainZ + (int)(u.leapZ * (sunVecY * 0.5));
                drawHexShape(g2d, shadowX, shadowY, r / 2);
            }
            int renderY = sy - terrainZ - (int) u.leapZ;
            g2d.setColor(u.selected ? COLOR_UNIT_SELECTED : (u.isHoldingPosition ? COLOR_UNIT_HOLDING : COLOR_UNIT_DEFAULT));
            drawHexShape(g2d, sx, renderY, 10);
            g2d.setColor(COLOR_TEXT_WHITE);
            g2d.drawString(u.type.name(), sx - 15, renderY - 10);
        }
    }

    private void drawHexShape(Graphics2D g, int cx, int cy, int radius) {
        int[] hx = SCRATCH_X6.get();
        int[] hy = SCRATCH_Y6.get();
        for (int i = 0; i < 6; i++) {
            double a = Math.PI / 3 * i;
            hx[i] = cx + (int)(radius * Math.cos(a));
            hy[i] = cy + (int)(radius * Math.sin(a));
        }
        g.fillPolygon(hx, hy, 6);
    }

    private void drawSelectionBox(Graphics g, SelectionManager selection) {
        if (!selection.dragging) return;
        int x = Math.min(selection.dragStartX, selection.dragEndX);
        int y = Math.min(selection.dragStartY, selection.dragEndY);
        int w = Math.abs(selection.dragStartX - selection.dragEndX);
        int h = Math.abs(selection.dragStartY - selection.dragEndY);

        g.setColor(COLOR_SELECTION_BG);
        g.fillRect(x, y, w, h);
        g.setColor(COLOR_SELECTION_BRD);
        g.drawRect(x, y, w, h);
    }

    // ==========================================
    // HIGH-PERFORMANCE TOWNHALL TEXTURING CACHE
    // ==========================================

    public void drawTownHall(Graphics2D g2d, int centerQ, int centerR, int terrainZ,
                             int hexSize, Color factionColor) {
        // Track the current time frame to dynamically shift day/night representations
        if (GridManager.timeOfDay != lastTimeOfDay) {
            if (lastTimeOfDay != -1f) {
                isNight = (GridManager.timeOfDay < lastTimeOfDay);
            }
            lastTimeOfDay = GridManager.timeOfDay;
        }

        // OPTIMIZATION: Verify image state and construct detached textures lazily on environment modifications
        if (cachedTownHallDay == null || lastCachedHexSize != hexSize || lastTownHallHex == null || lastTownHallHex.x != centerQ || lastTownHallHex.y != centerR) {
            bakeTownHallTextures(centerQ, centerR, terrainZ, hexSize, factionColor);
        }

        Point centerP = CoordinateConverter.hexToPixel(centerQ, centerR);
        BufferedImage activeTexture = isNight ? cachedTownHallNight : cachedTownHallDay;

        // Blit the static image onto the graphics context with a single allocation-free call
        if (activeTexture != null) {
            g2d.drawImage(activeTexture, centerP.x - cachedImgCX, centerP.y - cachedImgCY, null);
        }
    }

    private void bakeTownHallTextures(int centerQ, int centerR, int terrainZ, int hexSize, Color factionColor) {
        invalidateTownHallCache();

        lastCachedHexSize = hexSize;
        lastTownHallHex = new Point(centerQ, centerR);

        // Canvas dimensions matching standard structure boundaries
        int imgW = hexSize * 22;
        int imgH = hexSize * 26;

        cachedImgCX = imgW / 2;
        cachedImgCY = imgH - (hexSize * 8);

        cachedTownHallDay = GFX_CONFIG.createCompatibleImage(imgW, imgH, Transparency.TRANSLUCENT);
        Graphics2D gDay = cachedTownHallDay.createGraphics();
        gDay.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        gDay.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        isNight = false; // Force day flag for this pass
        renderProceduralTownHall(gDay, centerQ, centerR, terrainZ, hexSize, factionColor, imgW, imgH);
        gDay.dispose();

        cachedTownHallNight = GFX_CONFIG.createCompatibleImage(imgW, imgH, Transparency.TRANSLUCENT);
        Graphics2D gNight = cachedTownHallNight.createGraphics();
        gNight.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        gNight.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        isNight = true; // Force night flag for this pass
        renderProceduralTownHall(gNight, centerQ, centerR, terrainZ, hexSize, factionColor, imgW, imgH);
        gNight.dispose();

        // Restore active configuration tracker
        isNight = (GridManager.timeOfDay < lastTimeOfDay);
    }

    private void renderProceduralTownHall(Graphics2D g2d, int centerQ, int centerR, int terrainZ,
                                          int hexSize, Color factionColor, int imgW, int imgH) {
        int cx = cachedImgCX;
        int cy = cachedImgCY;

        int rx       = (int)(hexSize * 5.8);
        int ryFront  = (int)(hexSize * 5.8);
        int ryBack   = (int)(hexSize * 2.9);

        Color stoneTop      = new Color(195, 185, 170);
        Color stoneSideL    = new Color(165, 155, 140);
        Color stoneSideR    = new Color(145, 135, 120);
        Color nobleGreenRoof    = new Color( 35, 110,  65);
        Color vibrantGreenFlag  = new Color( 25, 145,  55);

        int outerTowerRx       = (int)(hexSize * 1.2);
        int outerTowerRyFront  = (int)(hexSize * 1.2);
        int outerTowerRyBack   = (int)(hexSize * 0.6);
        int outerTowerH        = 45;

        // Render Ground Shadows relative to the local texture canvas
        Composite oldComp = g2d.getComposite();
        g2d.setColor(Color.BLACK);
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.35f));
        Point realCenterP = CoordinateConverter.hexToPixel(centerQ, centerR);

        for (int dq = -4; dq <= 4; dq++) {
            for (int dr = Math.max(-4, -dq - 4); dr <= Math.min(4, -dq + 4); dr++) {
                HexTile standingTile = GridManager.hexes.get(HexMath.key(centerQ + dq, centerR + dr));
                if (standingTile != null) {
                    Point tpp = CoordinateConverter.hexToPixel(centerQ + dq, centerR + dr);
                    int localShadowX = tpp.x - realCenterP.x + cx;
                    int localShadowY = tpp.y - realCenterP.y + cy;
                    drawFlatGroundHexShadow(g2d, localShadowX, localShadowY, standingTile.getZ(), hexSize);
                }
            }
        }
        g2d.setComposite(oldComp);

        drawSingleTower(g2d, cx, cy, terrainZ, rx, ryFront, ryBack,
                outerTowerRx, outerTowerRyFront, outerTowerRyBack, outerTowerH,
                3, stoneTop, stoneSideL, stoneSideR, nobleGreenRoof, vibrantGreenFlag);

        drawSingleTower(g2d, cx, cy, terrainZ, rx, ryFront, ryBack,
                outerTowerRx, outerTowerRyFront, outerTowerRyBack, outerTowerH,
                2, stoneTop, stoneSideL, stoneSideR, nobleGreenRoof, vibrantGreenFlag);
        drawSingleTower(g2d, cx, cy, terrainZ, rx, ryFront, ryBack,
                outerTowerRx, outerTowerRyFront, outerTowerRyBack, outerTowerH,
                4, stoneTop, stoneSideL, stoneSideR, nobleGreenRoof, vibrantGreenFlag);

        int currentZ = terrainZ;

        int foundationHeight = 35;
        drawTexturedIsoBlock(g2d, cx, cy, currentZ, rx, ryFront, ryBack,
                foundationHeight, stoneTop, stoneSideL, stoneSideR, true, false);
        currentZ += foundationHeight;

        int hallHeight = 65;
        int hallRx      = (int)(rx * 0.85);
        int hallRyFront = (int)(ryFront * 0.85);
        int hallRyBack  = (int)(ryBack  * 0.85);
        drawTexturedIsoBlock(g2d, cx, cy, currentZ, hallRx, hallRyFront, hallRyBack,
                hallHeight, stoneTop, stoneSideL, stoneSideR, true, true);
        currentZ += hallHeight;

        int lowerRoofHeight      = 40;
        int lowerRoofRx_Bot      = (int)(rx * 0.90);
        int lowerRoofRyFront_Bot = (int)(ryFront * 0.90);
        int lowerRoofRyBack_Bot  = (int)(ryBack  * 0.90);
        int lowerRoofRx_Top      = (int)(rx * 0.45);
        int lowerRoofRyFront_Top = (int)(ryFront * 0.45);
        int lowerRoofRyBack_Top  = (int)(ryBack  * 0.45);
        drawTexturedIsoRoofFrustum(g2d, cx, cy, currentZ,
                lowerRoofRx_Bot, lowerRoofRyFront_Bot, lowerRoofRyBack_Bot,
                lowerRoofRx_Top, lowerRoofRyFront_Top, lowerRoofRyBack_Top,
                lowerRoofHeight, nobleGreenRoof);
        currentZ += lowerRoofHeight;

        int keepHeight = 40;
        int keepRx      = (int)(rx * 0.45);
        int keepRyFront = (int)(ryFront * 0.45);
        int keepRyBack  = (int)(ryBack  * 0.45);
        drawTexturedIsoBlock(g2d, cx, cy, currentZ, keepRx, keepRyFront, keepRyBack,
                keepHeight, stoneTop, stoneSideL, stoneSideR, true, true);
        currentZ += keepHeight;

        int spireHeight = 85;
        int spireRx      = (int)(rx * 0.50);
        int spireRyFront = (int)(ryFront * 0.50);
        int spireRyBack  = (int)(ryBack  * 0.50);
        drawTexturedIsoSpire(g2d, cx, cy, currentZ, spireRx, spireRyFront, spireRyBack,
                spireHeight, nobleGreenRoof, vibrantGreenFlag, true);

        drawSingleTower(g2d, cx, cy, terrainZ, rx, ryFront, ryBack,
                outerTowerRx, outerTowerRyFront, outerTowerRyBack, outerTowerH,
                1, stoneTop, stoneSideL, stoneSideR, nobleGreenRoof, vibrantGreenFlag);
        drawSingleTower(g2d, cx, cy, terrainZ, rx, ryFront, ryBack,
                outerTowerRx, outerTowerRyFront, outerTowerRyBack, outerTowerH,
                5, stoneTop, stoneSideL, stoneSideR, nobleGreenRoof, vibrantGreenFlag);

        drawSingleTower(g2d, cx, cy, terrainZ, rx, ryFront, ryBack,
                outerTowerRx, outerTowerRyFront, outerTowerRyBack, outerTowerH,
                0, stoneTop, stoneSideL, stoneSideR, nobleGreenRoof, vibrantGreenFlag);
    }

    private void drawSingleTower(Graphics2D g2d, int cx, int cy, int terrainZ,
                                 int rx, int ryFront, int ryBack,
                                 int outerTowerRx, int outerTowerRyFront, int outerTowerRyBack,
                                 int outerTowerH, int i,
                                 Color stoneTop, Color stoneSideL, Color stoneSideR,
                                 Color nobleGreenRoof, Color vibrantGreenFlag) {
        double a    = Math.PI / 3 * i + Math.PI / 2;
        int    txX  = cx + (int)(rx * Math.cos(a));
        double sinA = Math.sin(a);
        int    txY  = cy + (int)((sinA >= 0 ? ryFront : ryBack) * sinA);

        drawTexturedIsoBlock(g2d, txX, txY, terrainZ,
                outerTowerRx, outerTowerRyFront, outerTowerRyBack, outerTowerH,
                stoneTop, stoneSideL, stoneSideR, true, true);
        drawTexturedIsoSpire(g2d, txX, txY, terrainZ + outerTowerH,
                outerTowerRx + 4, outerTowerRyFront + 4, outerTowerRyBack + 4,
                35, nobleGreenRoof, vibrantGreenFlag, false);
    }

    private void drawFlatGroundHexShadow(Graphics2D g, int x, int y, int z, int hexSize) {
        Path2D.Float hexShape = new Path2D.Float();
        for (int i = 0; i < 6; i++) {
            double angle = Math.PI / 3 * i;
            float hx = x + (float)(hexSize * Math.cos(angle));
            float hy = y + (float)(hexSize * Math.sin(angle)) - z;
            if (i == 0) hexShape.moveTo(hx, hy);
            else        hexShape.lineTo(hx, hy);
        }
        hexShape.closePath();
        g.fill(hexShape);
    }

    private void drawTexturedIsoBlock(Graphics2D g, int cx, int cy, int z,
                                      int rx, int ryFront, int ryBack, int h,
                                      Color top, Color left, Color right,
                                      boolean isStone, boolean drawWindows) {
        int[] tx = new int[6], ty = new int[6], bx = new int[6], by = new int[6];
        for (int i = 0; i < 6; i++) {
            double a    = Math.PI / 3 * i + Math.PI / 2;
            int    dx   = (int)(rx * Math.cos(a));
            double sinA = Math.sin(a);
            int    dy   = (int)((sinA >= 0 ? ryFront : ryBack) * sinA);
            tx[i] = cx + dx; ty[i] = cy + dy - z - h;
            bx[i] = cx + dx; by[i] = cy + dy - z;
        }

        Polygon faceLeft      = new Polygon(new int[]{ tx[2],tx[1],bx[1],bx[2] }, new int[]{ ty[2],ty[1],by[1],by[2] }, 4);
        Polygon faceFrontLeft  = new Polygon(new int[]{ tx[1],tx[0],bx[0],bx[1] }, new int[]{ ty[1],ty[0],by[0],by[1] }, 4);
        Polygon faceFrontRight = new Polygon(new int[]{ tx[0],tx[5],bx[5],bx[0] }, new int[]{ ty[0],ty[5],by[5],by[0] }, 4);
        Polygon faceRight      = new Polygon(new int[]{ tx[5],tx[4],bx[4],bx[5] }, new int[]{ ty[5],ty[4],by[4],by[5] }, 4);

        g.setColor(blendColor(left, Color.BLACK, 0.25f)); g.fillPolygon(faceLeft);
        g.setColor(left);                                  g.fillPolygon(faceFrontLeft);
        g.setColor(right);                                 g.fillPolygon(faceFrontRight);
        g.setColor(blendColor(right, Color.BLACK, 0.15f)); g.fillPolygon(faceRight);

        if (isStone) {
            applyVectorBrickTexture(g, 2, 1, h, bx, by, true);
            applyVectorBrickTexture(g, 1, 0, h, bx, by, false);
            applyVectorBrickTexture(g, 0, 5, h, bx, by, false);
            applyVectorBrickTexture(g, 5, 4, h, bx, by, true);
        }

        if (drawWindows) {
            drawIsometricWindow(g, 1, 0, bx, by, h);
            drawIsometricWindow(g, 0, 5, bx, by, h);
        }

        g.setColor(new Color(110, 100, 85));
        g.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawLine(tx[2], ty[2], bx[2], by[2]);
        g.drawLine(tx[1], ty[1], bx[1], by[1]);
        g.drawLine(tx[0], ty[0], bx[0], by[0]);
        g.drawLine(tx[5], ty[5], bx[5], by[5]);
        g.drawLine(tx[4], ty[4], bx[4], by[4]);

        g.setColor(top);
        g.fillPolygon(tx, ty, 6);
        g.setColor(new Color(80, 75, 65, 80));
        g.setStroke(new BasicStroke(1.0f));
        g.drawPolygon(tx, ty, 6);
    }

    private void applyVectorBrickTexture(Graphics2D g, int sIdx, int eIdx, int h,
                                         int[] bx, int[] by, boolean dark) {
        g.setColor(dark ? new Color(60, 55, 50, 45) : new Color(60, 55, 50, 25));
        g.setStroke(new BasicStroke(1.0f));

        int brickH = 8;
        int brickW = 16;

        int x1 = bx[sIdx], y1 = by[sIdx];
        int x2 = bx[eIdx], y2 = by[eIdx];
        double faceWidth = Math.abs(x2 - x1);
        if (faceWidth < 1) faceWidth = 1;

        int row = 0;
        for (int offset = 0; offset < h + brickH; offset += brickH) {
            g.drawLine(x1, y1 - offset, x2, y2 - offset);
            if (offset > 0) {
                int stagger = (row % 2 == 0) ? 0 : brickW / 2;
                double steps = faceWidth / brickW + 2;
                for (int k = -1; k < steps; k++) {
                    double currX = Math.min(x1, x2) + (k * brickW) + stagger;
                    double t = (currX - x1) / (x2 - x1);
                    if (t >= 0.0 && t <= 1.0) {
                        int xJoint  = (int) currX;
                        int yBottom = (int)(y1 - (offset - brickH) + t * (y2 - y1));
                        int yTop    = (int)(y1 - offset             + t * (y2 - y1));
                        g.drawLine(xJoint, yTop, xJoint, yBottom);
                    }
                }
            }
            row++;
        }
    }

    private void drawIsometricWindow(Graphics2D g, int sIdx, int eIdx,
                                     int[] bx, int[] by, int h) {
        int x1 = bx[sIdx], y1 = by[sIdx];
        int x2 = bx[eIdx], y2 = by[eIdx];

        int cxWin = (int)((x1 + x2) / 2.0);
        int cyWin = (int)(((y1 + y2) / 2.0) - h / 2.0);

        double ux      = (x2 - x1) * 0.14;
        double uy      = (y2 - y1) * 0.14;
        int    winHalfH = 12;

        int[] wx = { (int)(cxWin - ux), (int)(cxWin + ux), (int)(cxWin + ux), (int)(cxWin - ux) };
        int[] wy = { (int)(cyWin - uy - winHalfH), (int)(cyWin + uy - winHalfH),
                (int)(cyWin + uy + winHalfH), (int)(cyWin - uy + winHalfH) };
        Polygon winPoly = new Polygon(wx, wy, 4);

        g.setColor(new Color(218, 165, 32));
        g.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawPolygon(winPoly);

        g.setColor(isNight ? new Color(255, 235, 60) : new Color(180, 230, 255));
        g.fillPolygon(winPoly);

        g.setColor(isNight ? new Color(130, 90, 20, 160) : new Color(70, 120, 160, 120));
        g.setStroke(new BasicStroke(1.0f));
        g.drawLine(cxWin, cyWin - winHalfH, cxWin, cyWin + winHalfH);
        g.drawLine((int)(cxWin - ux), (int)(cyWin - uy), (int)(cxWin + ux), (int)(cyWin + uy));
    }

    private void drawTexturedIsoRoofFrustum(Graphics2D g, int cx, int cy, int z,
                                            int rxBot, int ryBotFront, int ryBotBack,
                                            int rxTop, int ryTopFront, int ryTopBack,
                                            int h, Color roofColor) {
        int[] tx = new int[6], ty = new int[6], bx = new int[6], by = new int[6];
        for (int i = 0; i < 6; i++) {
            double a    = Math.PI / 3 * i + Math.PI / 2;
            int    bdx  = (int)(rxBot * Math.cos(a));
            double sinA = Math.sin(a);
            int    bdy  = (int)((sinA >= 0 ? ryBotFront : ryBotBack) * sinA);
            int    tdx  = (int)(rxTop * Math.cos(a));
            int    tdy  = (int)((sinA >= 0 ? ryTopFront : ryTopBack) * sinA);
            tx[i] = cx + tdx; ty[i] = cy + tdy - z - h;
            bx[i] = cx + bdx; by[i] = cy + bdy - z;
        }

        Polygon pLeft       = new Polygon(new int[]{ tx[2],tx[1],bx[1],bx[2] }, new int[]{ ty[2],ty[1],by[1],by[2] }, 4);
        Polygon pFrontLeft  = new Polygon(new int[]{ tx[1],tx[0],bx[0],bx[1] }, new int[]{ ty[1],ty[0],by[0],by[1] }, 4);
        Polygon pFrontRight = new Polygon(new int[]{ tx[0],tx[5],bx[5],bx[0] }, new int[]{ ty[0],ty[5],by[5],by[0] }, 4);
        Polygon pRight      = new Polygon(new int[]{ tx[5],tx[4],bx[4],bx[5] }, new int[]{ ty[5],ty[4],by[4],by[5] }, 4);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.35f)); g.fillPolygon(pLeft);
        applyTiltedRoofTiles(g, 2, 1, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.10f)); g.fillPolygon(pFrontLeft);
        applyTiltedRoofTiles(g, 1, 0, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.WHITE, 0.05f)); g.fillPolygon(pFrontRight);
        applyTiltedRoofTiles(g, 0, 5, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.25f)); g.fillPolygon(pRight);
        applyTiltedRoofTiles(g, 5, 4, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.4f));
        g.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawPolygon(pLeft);
        g.drawPolygon(pFrontLeft);
        g.drawPolygon(pFrontRight);
        g.drawPolygon(pRight);
    }

    private void drawTexturedIsoSpire(Graphics2D g, int cx, int cy, int z,
                                      int rx, int ryFront, int ryBack, int h,
                                      Color roofColor, Color flagColor, boolean isMain) {
        int[] bx = new int[6], by = new int[6];
        for (int i = 0; i < 6; i++) {
            double a    = Math.PI / 3 * i + Math.PI / 2;
            int    dx   = (int)(rx * Math.cos(a));
            double sinA = Math.sin(a);
            int    dy   = (int)((sinA >= 0 ? ryFront : ryBack) * sinA);
            bx[i] = cx + dx; by[i] = cy + dy - z;
        }
        int peakX = cx, peakY = cy - z - h;

        int[] tx = { peakX, peakX, peakX, peakX, peakX, peakX };
        int[] ty = { peakY, peakY, peakY, peakY, peakY, peakY };

        Polygon pLeft       = new Polygon(new int[]{ peakX, bx[2], bx[1] }, new int[]{ peakY, by[2], by[1] }, 3);
        Polygon pFrontLeft  = new Polygon(new int[]{ peakX, bx[1], bx[0] }, new int[]{ peakY, by[1], by[0] }, 3);
        Polygon pFrontRight = new Polygon(new int[]{ peakX, bx[0], bx[5] }, new int[]{ peakY, by[0], by[5] }, 3);
        Polygon pRight      = new Polygon(new int[]{ peakX, bx[5], bx[4] }, new int[]{ peakY, by[5], by[4] }, 3);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.35f)); g.fillPolygon(pLeft);
        applyTiltedRoofTiles(g, 2, 1, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.10f)); g.fillPolygon(pFrontLeft);
        applyTiltedRoofTiles(g, 1, 0, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.WHITE, 0.05f)); g.fillPolygon(pFrontRight);
        applyTiltedRoofTiles(g, 0, 5, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.25f)); g.fillPolygon(pRight);
        applyTiltedRoofTiles(g, 5, 4, bx, by, tx, ty);

        g.setColor(blendColor(roofColor, Color.BLACK, 0.4f));
        g.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawLine(peakX, peakY, bx[2], by[2]); g.drawLine(peakX, peakY, bx[1], by[1]);
        g.drawLine(peakX, peakY, bx[0], by[0]); g.drawLine(peakX, peakY, bx[5], by[5]);
        g.drawLine(peakX, peakY, bx[4], by[4]);
        g.drawLine(bx[2], by[2], bx[1], by[1]); g.drawLine(bx[1], by[1], bx[0], by[0]);
        g.drawLine(bx[0], by[0], bx[5], by[5]); g.drawLine(bx[5], by[5], bx[4], by[4]);

        Color polishedGold = new Color(218, 165, 32);
        if (isMain) {
            g.setColor(polishedGold);
            g.fillPolygon(
                    new int[]{ peakX - 14, peakX, peakX + 14, peakX },
                    new int[]{ peakY,      peakY - 28, peakY,  peakY + 8 }, 4);
            drawHexShape(g, peakX, peakY - 14, 7);
        } else {
            g.setColor(new Color(110, 90, 70));
            g.fillRect(peakX - 1, peakY - 35, 2, 35);
            g.setColor(polishedGold);
            drawHexShape(g, peakX, peakY - 35, 4);
            g.setColor(flagColor);
            g.fillPolygon(
                    new int[]{ peakX,      peakX + 30, peakX + 20, peakX + 30, peakX      },
                    new int[]{ peakY - 35, peakY - 35, peakY - 24, peakY - 13, peakY - 13 }, 5);
        }
    }

    private void applyTiltedRoofTiles(Graphics2D g, int sIdx, int eIdx,
                                      int[] bx, int[] by, int[] tx, int[] ty) {
        Shape oldClip = g.getClip();
        Polygon segmentMask = new Polygon(
                new int[]{ bx[sIdx], bx[eIdx], tx[eIdx], tx[sIdx] },
                new int[]{ by[sIdx], by[eIdx], ty[eIdx], ty[sIdx] }, 4);
        g.setClip(segmentMask);

        g.setColor(new Color(15, 40, 25, 100));
        g.setStroke(new BasicStroke(1.2f));

        int tileH = 7;
        int tileW = 10;

        int minY = Math.min(Math.min(ty[sIdx], ty[eIdx]), Math.min(by[sIdx], by[eIdx]));
        int maxY = Math.max(Math.max(ty[sIdx], ty[eIdx]), Math.max(by[sIdx], by[eIdx]));
        int renderSpan = maxY - minY + tileH;

        int row = 0;
        for (int offset = 0; offset < renderSpan; offset += tileH) {
            int x1 = bx[sIdx], y1 = by[sIdx] - offset;
            int x2 = bx[eIdx], y2 = by[eIdx] - offset;
            g.drawLine(x1, y1, x2, y2);

            int stagger = (row % 2 == 0) ? 0 : tileW / 2;
            int boundL = Math.min(x1, x2) - tileW;
            int boundR = Math.max(x1, x2) + tileW;
            for (int sx = boundL; sx < boundR; sx += tileW) {
                int    currX   = sx + stagger;
                double t       = (double)(currX - x1) / (x2 - x1);
                int    yBottom = (int)(y1 + t * (y2 - y1));
                g.drawLine(currX, yBottom, currX, yBottom - tileH);
            }
            row++;
        }
        g.setClip(oldClip);
    }

    private Color blendColor(Color base, Color mix, float ratio) {
        int r = (int)(base.getRed()   * (1 - ratio) + mix.getRed()   * ratio);
        int g = (int)(base.getGreen() * (1 - ratio) + mix.getGreen() * ratio);
        int b = (int)(base.getBlue()  * (1 - ratio) + mix.getBlue()  * ratio);
        return new Color(r, g, b);
    }
}